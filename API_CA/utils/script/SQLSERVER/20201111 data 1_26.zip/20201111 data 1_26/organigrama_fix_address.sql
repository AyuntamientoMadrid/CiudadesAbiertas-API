-- *********************************************************************
-- Update Database Script
-- *********************************************************************
-- Change Log: liquibase/db-changelog-master.xml
-- Ran at: 18/11/20 13:42
-- Against: login_ciudadesAbiertas@jdbc:sqlserver://localhost:1433;useBulkCopyForBatchInsert=false;cancelQueryTimeout=-1;sslProtocol=TLS;jaasConfigurationName=SQLJDBCDriver;statementPoolingCacheSize=0;serverPreparedStatementDiscardThreshold=10;enablePrepareOnFirstPreparedStatementCall=false;fips=false;socketTimeout=0;authentication=NotSpecified;authenticationScheme=nativeAuthentication;xopenStates=false;sendTimeAsDatetime=true;trustStoreType=JKS;trustServerCertificate=false;TransparentNetworkIPResolution=true;serverNameAsACE=false;sendStringParametersAsUnicode=true;selectMethod=direct;responseBuffering=adaptive;queryTimeout=-1;packetSize=8000;multiSubnetFailover=false;loginTimeout=15;lockTimeout=-1;lastUpdateCount=true;encrypt=false;disableStatementPooling=true;databaseName=bbdd_ciudadesAbiertas;columnEncryptionSetting=Disabled;applicationName=Microsoft JDBC Driver for SQL Server;applicationIntent=readwrite;
-- Liquibase version: 3.4.2
-- *********************************************************************
USE [bbdd_ciudadesAbiertas];
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674456.74194,  y_etrs89= 4614129.57874 WHERE id = '61326';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '23831';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '23829';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '61632';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '23830';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675772.72811,  y_etrs89= 4614357.32503 WHERE id = '61633';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 683188.86682,  y_etrs89= 4625428.39143 WHERE id = '25111';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20823';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20254';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20800';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20805';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20836';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20806';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61664';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674739.65849,  y_etrs89= 4614346.34635 WHERE id = '25207';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674740.77021,  y_etrs89= 4614382.10059 WHERE id = '61307';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61318';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25118';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 680601.16252,  y_etrs89= 4615051.40101 WHERE id = '61322';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 680601.16252,  y_etrs89= 4615051.40101 WHERE id = '25112';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61313';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675783.16079,  y_etrs89= 4615509.16137 WHERE id = '61299';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677310.39785,  y_etrs89= 4613304.69061 WHERE id = '60142';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 672480.00493,  y_etrs89= 4613157.75924 WHERE id = '25208';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25203';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676060.50556,  y_etrs89= 4613818.33316 WHERE id = '61321';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681309.25453,  y_etrs89= 4608341.08128 WHERE id = '61308';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681309.25453,  y_etrs89= 4608341.08128 WHERE id = '25102';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61303';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60263';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23839';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23940';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60269';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60238';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23835';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23955';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60056';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23978';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60257';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60216';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23969';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23946';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60262';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61487';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60166';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60128';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61488';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '20265';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23989';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23956';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61585';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23828';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61489';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676427.17355,  y_etrs89= 4610737.65869 WHERE id = '25101';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676571.28922,  y_etrs89= 4613292.99832 WHERE id = '25020';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '61363';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '20818';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '20844';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '20843';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '21245';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '60221';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '21244';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '61365';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674848.45868,  y_etrs89= 4611952.68218 WHERE id = '21243';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674848.45868,  y_etrs89= 4611952.68218 WHERE id = '21242';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674848.45868,  y_etrs89= 4611952.68218 WHERE id = '25204';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676853.64669,  y_etrs89= 4613526.95205 WHERE id = '61609';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676853.64669,  y_etrs89= 4613526.95205 WHERE id = '61611';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675553.18841,  y_etrs89= 4614039.58798 WHERE id = '60191';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675553.18841,  y_etrs89= 4614039.58798 WHERE id = '61117';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675553.18841,  y_etrs89= 4614039.58798 WHERE id = '60157';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674666.17312,  y_etrs89= 4611717.91885 WHERE id = '25030';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677462.05289,  y_etrs89= 4612629.91028 WHERE id = '25206';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675694.66041,  y_etrs89= 4612820.00101 WHERE id = '25202';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677051.82088,  y_etrs89= 4613223.93785 WHERE id = '61310';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60099';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20557';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60167';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60110';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60148';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20119';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61165';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60150';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60129';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60121';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60162';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60132';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60075';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61617';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60151';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60138';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60145';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60130';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60115';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60074';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60124';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60001';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60119';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26057';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674290.41810,  y_etrs89= 4610815.89193 WHERE id = '25117';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61316';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20231';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678185.38293,  y_etrs89= 4614444.69305 WHERE id = '61309';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675709.12652,  y_etrs89= 4615868.05000 WHERE id = '25211';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677537.45369,  y_etrs89= 4614614.73837 WHERE id = '25010';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677537.45369,  y_etrs89= 4614614.73837 WHERE id = '61382';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681064.18322,  y_etrs89= 4617130.66068 WHERE id = '25107';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '20235';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '60283';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '20217';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '61311';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676258.66143,  y_etrs89= 4610808.60062 WHERE id = '25209';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676258.66143,  y_etrs89= 4610808.60062 WHERE id = '61323';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 679064.80677,  y_etrs89= 4596766.26689 WHERE id = '25114';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677170.94516,  y_etrs89= 4614164.52103 WHERE id = '25212';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 664775.33244,  y_etrs89= 4617548.51453 WHERE id = '60230';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '20236';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61208';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61634';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61681';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61592';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61472';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '60189';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '61143';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '61142';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '20516';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '61140';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25116';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677097.25530,  y_etrs89= 4611317.22890 WHERE id = '60193';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 671189.60772,  y_etrs89= 4613933.77215 WHERE id = '61312';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 671189.60772,  y_etrs89= 4613933.77215 WHERE id = '25108';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678133.17982,  y_etrs89= 4615425.79934 WHERE id = '23811';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678133.17982,  y_etrs89= 4615425.79934 WHERE id = '61624';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678597.24447,  y_etrs89= 4616279.91171 WHERE id = '23968';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60028';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60016';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60097';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60171';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60002';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60017';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60043';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '20247';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '23846';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61670';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '20333';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '20331';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '60293';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '60242';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681391.11541,  y_etrs89= 4613171.28462 WHERE id = '25113';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681391.11541,  y_etrs89= 4613171.28462 WHERE id = '61320';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61325';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60013';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60085';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60011';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61615';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60052';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60067';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61613';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60104';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61608';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60183';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60185';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61612';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60140';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60108';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60177';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60010';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60111';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 664051.42771,  y_etrs89= 4620479.28716 WHERE id = '25103';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 664051.42771,  y_etrs89= 4620479.28716 WHERE id = '61302';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25105';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61305';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674617.28711,  y_etrs89= 4617994.03830 WHERE id = '61315';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674617.28711,  y_etrs89= 4617994.03830 WHERE id = '25109';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674621.55512,  y_etrs89= 4617990.94218 WHERE id = '61306';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674621.55512,  y_etrs89= 4617990.94218 WHERE id = '25205';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674621.55512,  y_etrs89= 4617990.94218 WHERE id = '61319';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674662.11302,  y_etrs89= 4617968.65932 WHERE id = '25106';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61586';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60303';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61677';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60295';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60306';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61583';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26050';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60165';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61581';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61665';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60022';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60299';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60237';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60298';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61580';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20298';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61223';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61225';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '24110';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26027';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61587';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61591';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26019';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60090';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60173';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60314';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60030';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26042';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61584';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60073';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60047';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26037';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10951';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20104';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60240';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61590';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60180';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26051';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61578';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26020';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60048';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60181';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60082';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26052';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60305';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60078';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61530';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60300';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60184';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10953';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10100';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60220';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60006';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '21251';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60211';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60246';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60222';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60324';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60330';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10950';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60076';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20422';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60318';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60164';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60107';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60174';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60226';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676775.93344,  y_etrs89= 4614306.32691 WHERE id = '61300';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676063.38654,  y_etrs89= 4613713.35468 WHERE id = '25201';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675950.94205,  y_etrs89= 4613736.62826 WHERE id = '61631';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675950.94205,  y_etrs89= 4613736.62826 WHERE id = '70001';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25110';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61314';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 682899.44260,  y_etrs89= 4625531.79551 WHERE id = '20206';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 682899.44260,  y_etrs89= 4625531.79551 WHERE id = '61705';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 682899.44260,  y_etrs89= 4625531.79551 WHERE id = '60285';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26015';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61621';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60254';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60192';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60137';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60084';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60057';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23300';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23900';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23333';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20259';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60275';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23252';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23270';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60247';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23310';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60236';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60033';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23497';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60169';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61215';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26031';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60172';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60079';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61622';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60105';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23318';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26043';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23496';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61437';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26017';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60096';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61589';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23565';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23610';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60077';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61742';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60032';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60215';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23515';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23503';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61201';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23615';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61603';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61774';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60288';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61627';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23344';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23593';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23542';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23467';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '24100';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60065';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60304';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20337';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61571';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '24105';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26035';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23965';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60127';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60309';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23776';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61378';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60227';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23575';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61246';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23510';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23535';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60217';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20213';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23517';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60063';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23827';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23578';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60244';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23660';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26040';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23537';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23460';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23960';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23498';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61294';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23340';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23581';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61743';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26028';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23587';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20350';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61773';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61200';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60343';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60290';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23650';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23627';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23251';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23636';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60015';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60178';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '21220';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23342';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61433';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60278';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23771';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20200';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23747';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23616';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23766';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60274';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23797';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61765';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23740';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23767';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23768';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61438';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23789';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23788';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23721';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674256.33189,  y_etrs89= 4612526.08004 WHERE id = '61304';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60093';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60214';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60235';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60106';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673972.77796,  y_etrs89= 4611025.21561 WHERE id = '61301';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673972.77796,  y_etrs89= 4611025.21561 WHERE id = '25104';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674843.85163,  y_etrs89= 4611874.66082 WHERE id = '61324';
GO



UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA AUTONOMIA 14' WHERE id = '61326';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '23831';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '23829';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '61632';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '23830';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA DE RANILLAS 1' WHERE id = '61633';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA PEÑAFLOR 71' WHERE id = '25111';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20823';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20254';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20800';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20805';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20836';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20806';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '61664';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA PUERTA DE SANCHO 28' WHERE id = '25207';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA PUERTA DE SANCHO 30' WHERE id = '61307';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SAN GREGORIO 14' WHERE id = '61318';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SAN GREGORIO 14' WHERE id = '25118';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SANTA ISABEL 100' WHERE id = '61322';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SANTA ISABEL 100' WHERE id = '25112';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDADE  MNT MONTAÑANA 374' WHERE id = '61313';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ALBERTO DUCE 2' WHERE id = '61299';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ALONSO V 30' WHERE id = '60142';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ANTONIO DE LEYVA 87' WHERE id = '25208';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ANTONIO MOMPEON MOTOS 12' WHERE id = '25203';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ARMAS 61' WHERE id = '61321';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE AUTONOMIA DE ARAGÓN 21' WHERE id = '61308';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE AUTONOMIA DE ARAGÓN 21' WHERE id = '25102';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61303';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60263';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23839';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23940';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60269';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60238';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23835';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23955';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60056';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23978';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60257';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60216';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23969';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23946';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60262';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61487';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60166';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60128';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61488';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '20265';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23989';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23956';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61585';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23828';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61489';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASTELLAR 23' WHERE id = '25101';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE COSO 57' WHERE id = '25020';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '61363';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '20818';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '20844';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '20843';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '21245';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '60221';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '21244';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '61365';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 5' WHERE id = '21243';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 5' WHERE id = '21242';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 5' WHERE id = '25204';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DON JUAN DE ARAGON 2' WHERE id = '61609';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DON JUAN DE ARAGON 2' WHERE id = '61611';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ECHEGARAY Y CABALLERO 2' WHERE id = '60191';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ECHEGARAY Y CABALLERO 2' WHERE id = '61117';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ECHEGARAY Y CABALLERO 2' WHERE id = '60157';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE EDUARDO IBARRA 6' WHERE id = '25030';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE FLORENTINO BALLESTEROS' WHERE id = '25206';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE HERNAN CORTES 31' WHERE id = '25202';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE HEROISMO 5' WHERE id = '61310';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60099';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '20557';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60167';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60110';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60148';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '20119';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '61165';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60150';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60129';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60121';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60162';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60132';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60075';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '61617';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60151';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60138';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60145';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60130';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60115';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60074';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60124';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60001';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60119';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE PALAFOX 29' WHERE id = '26057';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE LAS ESCUELAS 7' WHERE id = '25117';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE LUCIO ANNEO SENECA 78' WHERE id = '61316';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE LUIS LEGAZ LACAMBRA 34' WHERE id = '20231';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MARIA VIRTO' WHERE id = '61309';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MARIA ZAMBRANO 56' WHERE id = '25211';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MAS DE LAS MATAS 20' WHERE id = '25010';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MAS DE LAS MATAS 20' WHERE id = '61382';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MAYOR 115' WHERE id = '25107';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '20235';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '60283';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '20217';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '61311';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MONZON' WHERE id = '25209';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MONZON' WHERE id = '61323';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE PARADERO 1,' WHERE id = '25114';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE PERDIGUERA 7' WHERE id = '25212';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE DEL PINAR' WHERE id = '60230';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '20236';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61208';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61634';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61681';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61592';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61472';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '60189';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '61143';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '61142';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '20516';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '61140';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO  VNO TOMILLAR 1' WHERE id = '25116';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO DE MIRAFLORES 11' WHERE id = '60193';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO DEL PILON 147' WHERE id = '61312';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO DEL PILON 147' WHERE id = '25108';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CARRETERA COGULLADA' WHERE id = '23811';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CARRETERA COGULLADA' WHERE id = '61624';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CARRETERA COGULLADA 51' WHERE id = '23968';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60028';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60016';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60097';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60171';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60002';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60017';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60043';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '20247';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO SAN SEBASTIAN' WHERE id = '23846';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO SAN SEBASTIAN' WHERE id = '61670';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '20333';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '20331';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '60293';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '60242';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE ESPAÑA 9' WHERE id = '25113';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE ESPAÑA 9' WHERE id = '61320';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE INMACULADA S/N' WHERE id = '61325';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60013';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60085';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60011';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61615';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60052';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60067';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61613';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60104';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61608';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60183';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60185';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61612';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60140';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60108';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60177';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60010';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60111';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DEL CASTILLO 7' WHERE id = '25103';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DEL CASTILLO 7' WHERE id = '61302';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA JOSÉ RAMÓN ARANA' WHERE id = '25105';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA JOSÉ RAMÓN ARANA' WHERE id = '61305';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 1' WHERE id = '61315';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 1' WHERE id = '25109';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 2' WHERE id = '61306';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 2' WHERE id = '25205';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 2' WHERE id = '61319';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 7' WHERE id = '25106';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61586';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60303';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61677';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60295';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60306';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61583';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26050';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60165';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61581';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61665';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60022';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60299';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60237';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60298';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61580';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '20298';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61223';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61225';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '24110';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26027';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61587';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61591';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26019';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60090';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60173';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60314';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60030';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26042';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61584';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60073';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60047';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26037';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '10951';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '20104';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60240';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61590';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60180';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26051';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61578';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26020';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60048';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60181';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60082';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '26052';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60305';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60078';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '61530';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60300';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60184';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '10953';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '10100';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60220';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60006';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '21251';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60211';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60246';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60222';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60324';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60330';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '10950';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60076';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '20422';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60318';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60164';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60107';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60174';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SEÑORA DEL PILAR 18' WHERE id = '60226';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA SAN GREGORIO' WHERE id = '61300';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SAN PABLO 37' WHERE id = '25201';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SAN PABLO 61' WHERE id = '61631';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SAN PABLO 61' WHERE id = '70001';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTA ANA 34' WHERE id = '25110';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTA ANA 34' WHERE id = '61314';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTIAGO 34' WHERE id = '20206';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTIAGO 34' WHERE id = '61705';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTIAGO 34' WHERE id = '60285';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26015';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61621';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60254';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60192';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60137';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60084';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60057';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23300';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23900';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23333';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20259';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60275';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23252';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23270';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60247';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23310';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60236';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60033';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23497';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60169';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61215';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26031';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60172';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60079';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61622';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60105';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23318';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26043';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23496';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61437';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26017';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60096';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61589';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23565';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23610';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60077';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61742';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60032';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60215';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23515';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23503';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61201';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23615';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61603';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61774';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60288';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61627';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23344';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23593';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23542';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23467';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '24100';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60065';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60304';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20337';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61571';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '24105';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26035';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23965';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60127';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60309';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23776';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61378';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60227';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23575';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61246';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23510';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23535';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60217';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20213';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23517';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60063';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23827';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23578';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60244';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23660';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26040';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23537';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23460';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23960';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23498';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61294';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23340';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23581';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61743';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26028';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23587';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20350';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61773';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61200';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60343';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60290';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23650';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23627';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23251';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23636';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60015';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60178';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '21220';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23342';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61433';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60278';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23771';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20200';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23747';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23616';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23766';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60274';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23797';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61765';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23740';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23767';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23768';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61438';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23789';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23788';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23721';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA UNIVERSITAS 28' WHERE id = '61304';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60093';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60214';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60235';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60106';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIÑEDO VIEJO 1' WHERE id = '61301';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIÑEDO VIEJO 1' WHERE id = '25104';
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIOLANTE DE HUNGRIA 4' WHERE id = '61324';
GO

