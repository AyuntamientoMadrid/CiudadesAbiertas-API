-- *********************************************************************
-- Update Database Script
-- *********************************************************************
-- Change Log: liquibase/db-changelog-master.xml
-- Ran at: 11/11/20 8:21
-- Against: login_ciudadesAbiertas@jdbc:sqlserver://localhost:1433;useBulkCopyForBatchInsert=false;cancelQueryTimeout=-1;sslProtocol=TLS;jaasConfigurationName=SQLJDBCDriver;statementPoolingCacheSize=0;serverPreparedStatementDiscardThreshold=10;enablePrepareOnFirstPreparedStatementCall=false;fips=false;socketTimeout=0;authentication=NotSpecified;authenticationScheme=nativeAuthentication;xopenStates=false;sendTimeAsDatetime=true;trustStoreType=JKS;trustServerCertificate=false;TransparentNetworkIPResolution=true;serverNameAsACE=false;sendStringParametersAsUnicode=true;selectMethod=direct;responseBuffering=adaptive;queryTimeout=-1;packetSize=8000;multiSubnetFailover=false;loginTimeout=15;lockTimeout=-1;lastUpdateCount=true;encrypt=false;disableStatementPooling=true;databaseName=bbdd_ciudadesAbiertas;columnEncryptionSetting=Disabled;applicationName=Microsoft JDBC Driver for SQL Server;applicationIntent=readwrite;
-- Liquibase version: 3.4.2
-- *********************************************************************

USE [bbdd_ciudadesAbiertas];
GO

-- Lock Database
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 1, [LOCKEDBY] = 'CarlosM (192.168.56.1)', [LOCKGRANTED] = '2020-11-11T08:21:18.929' WHERE [ID] = 1 AND [LOCKED] = 0
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_auth::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_authority] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [telephone] [varchar](200) NULL, [email] [varchar](200) NULL, [url] [varchar](400) NULL, [legal_name] [varchar](200) NULL, [alternate_name] [varchar](200) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_auth', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 578, '7:a51ad9c7c77de202e69172c17ca71a1d', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_daytype::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_daytype] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [title] [varchar](200) NULL, [description] [varchar](4000) NULL, [short_name] [varchar](200) NULL, [earliest_time] [varchar](8) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_daytype', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 579, '7:101f8468528930b9aa893097f49f8543', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_daytypeassi::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [date_assignment] [datetime] NULL, [is_available] [bit] NULL, [specifying] [varchar](50) NULL, [for_the_definition_of] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_daytypeassi', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 580, '7:95af633cce896e5730aae87efe99cadf', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_headinte::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [minimum_headway_interval] [varchar](50) NULL, [maximum_headway_interval] [varchar](50) NULL, [scheduled_headway_interval] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_headinte', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 581, '7:4da8c1f4120331019c9e93097f5a8a05', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_headjourgrou::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [first_departure_time] [varchar](8) NULL, [last_departure_time] [varchar](8) NULL, [determined_by] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_headjourgrou', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 582, '7:5acec004421abeff9778d20561270b5a', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_inci::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_incidencia] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [tipo_incidencia] [varchar](50) NULL, [date_posted] [datetime] NULL, [num_sentidos] [int] NULL, [num_carriles] [int] NULL, [es_recurrente] [bit] NULL, [fecha_fin_prevista] [datetime] NULL, [x_etrs89] [decimal](13, 5) NULL, [y_etrs89] [decimal](13, 5) NULL, [incidencia_tramo_id] [varchar](50) NULL, [incidencia_tramo_description] [varchar](4000) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_inci', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 583, '7:8f99334466277505f9323fea16885d44', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_jourpatt::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [title] [varchar](200) NULL, [distance] [float](53) NULL, [on_id] [varchar](50) NULL, [generado_por_incidencia] [varchar](50) NULL, [front_text] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_jourpatt', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 584, '7:fddc2498c73a4b7915415c432ab9bf4f', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_linea::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_linea] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [title] [varchar](200) NULL, [url] [varchar](400) NULL, [short_name] [varchar](200) NULL, [cabecera_linea] [varchar](50) NULL, [final_linea] [varchar](50) NULL, [distance] [decimal](12, 2) NULL, [operating] [varchar](50) NULL, [colour] [varchar](200) NULL, [text_colour] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_linea', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 585, '7:7ab9a0a3e7cae11c1d84a72ee1352597', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_oper::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_operator] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [serving_pt_for] [varchar](50) NULL, [telephone] [varchar](200) NULL, [email] [varchar](200) NULL, [url] [varchar](400) NULL, [legal_name] [varchar](200) NULL, [alternate_name] [varchar](200) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_oper', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 586, '7:6dd657418fa2d85243d785fdfdbb34c6', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_parada::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_parada] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [title] [varchar](200) NULL, [url] [varchar](400) NULL, [wifi] [bit] NULL, [panel_electronico] [bit] NULL, [zona] [varchar](10) NULL, [x_etrs89] [decimal](13, 5) NULL, [y_etrs89] [decimal](13, 5) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_parada', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 587, '7:970cd5a239e83700d3b264f5d7f99654', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_poinonrout::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [order_point] [int] NULL, [distance_from_start] [decimal](12, 2) NULL, [in_id] [varchar](50) NULL, [functional_centroid_for] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_poinonrout', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 588, '7:70efb2433b25ec0feaf201047e4f350b', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_realtimepass::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [result_time] [datetime] NULL, [expected_arrival_time] [varchar](50) NULL, [has_feature_of_interest] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_realtimepass', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 589, '7:e3c13be83d9a494ecaaa4575ff224d41', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_rel_line_inci::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [linea] [varchar](50) NOT NULL, [afectada_incidencia] [varchar](50) NOT NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_rel_line_inci', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 590, '7:8633f6e5532726135914aac483a3ab6a', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_route::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_route] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [direction_type] [varchar](200) NULL, [on_id] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_route', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 591, '7:b62f8dc704a78447e35e1f885c918ecf', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_servcale::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_servicecalendar] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [title] [varchar](200) NULL, [description] [varchar](4000) NULL, [short_name] [varchar](200) NULL, [from_day] [datetime] NULL, [to_day] [datetime] NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_servcale', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 592, '7:5e3e19877977b949fb1aeb1156a41f54', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_stoppoinjourpatt::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [order_stop] [int] NULL, [stop_use] [varchar](200) NULL, [in_id] [varchar](50) NULL, [viewed_as] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_stoppoinjourpatt', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 593, '7:b6440d06ae89ee8094ea3c237e358f57', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_schestoppoin::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [functional_centroid_for] [varchar](50) NULL, [alighting] [bit] NULL, [boarding] [bit] NULL, [title_stop_area] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_schestoppoin', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 594, '7:b89d3b22a3ef211e4bc9be4d101c9486', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_vehijour::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [journey_duration] [varchar](50) NULL, [departure_time] [varchar](8) NULL, [made_using] [varchar](50) NULL, [worked_on] [varchar](50) NULL, [composed_of] [varchar](50) NULL, [direction_type] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_vehijour', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 595, '7:b5817de1dc28a2c1fc374a4f181fc988', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_authority] ADD CONSTRAINT [PK_bus_auth] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-01', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 596, '7:81cbee2608da67a8b84a4d1982098060', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytype] ADD CONSTRAINT [PK_bus_daytype] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-02', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 597, '7:982ebc00d80b0076d30460f5b0f65ca5', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [PK_bus_daytypassi] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-03', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 598, '7:3f719cda5e7c498f3fa81f0601f1bb9b', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayinterval] ADD CONSTRAINT [PK_bus_headinte] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-04', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 599, '7:0f4307b1beebf1bbab7f5d90b4da6f0a', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ADD CONSTRAINT [PK_bus_headjourgrou] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-05', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 600, '7:28cc9d07ce40221d59714991418b16b6', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_incidencia] ADD CONSTRAINT [PK_bus_incidencia] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-06', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 601, '7:11d47be8bf3b8e9385119a8f09141982', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [PK_bus_jourpatt] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-07', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 602, '7:a34c23f11ad2ac3e59801a0362b5d445', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [PK_bus_linea] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-08', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 603, '7:cc9f8dc81b50981c7c68c16c656ed043', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] ADD CONSTRAINT [PK_bus_operator] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-09', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 604, '7:9785843081084bcdb7f537d266c2f25d', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_parada] ADD CONSTRAINT [PK_bus_parada] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-10', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 605, '7:a443e1e8dfebd0570fcc0e300cf22e8b', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-11::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [PK_bus_poinonrout] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-11', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 606, '7:94e78aba45da9c8b89ef4c5e7da71bf2', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-12::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ADD CONSTRAINT [PK_bus_realtimepasstime] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-12', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 607, '7:00d3cbda3a1f0467d5af6fc4ebdc1a46', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-13::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ADD CONSTRAINT [PK_bus_rel_line_inci] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-13', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 608, '7:bed7f4c70e5ca81aab11dee43b6249de', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-14::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] ADD CONSTRAINT [PK_bus_route] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-14', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 609, '7:c0569fd22681166ad1783d9ba7116379', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-15::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_servicecalendar] ADD CONSTRAINT [PK_bus_servcale] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-15', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 610, '7:7b49c53b2c3c69a80cdd390694ba15eb', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-16::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [PK_bus_stoppoininjourpatt] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-16', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 611, '7:ed9a95d0439d73b9a9c6a3331d26140f', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-17::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [PK_bus_vehijour] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-17', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 612, '7:fd65b6ec0017d77145a89e6bac7dd61f', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-18::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ADD CONSTRAINT [PK_bus_schestop_point] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-18', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 613, '7:d11cf0063793814dd802556ccb693a27', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_authority] ADD CONSTRAINT [unique-id-bus_authority] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-01', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 614, '7:d6981f9a44f039dedc174f8d158528c8', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] ADD CONSTRAINT [unique-id-bus_operator] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-02', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 615, '7:2f780e54a8c405c842095800faa2d447', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [unique-id-bus_linea] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-03', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 616, '7:10f9dd9a98b8c7a4140611d7c54c8d3d', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ADD CONSTRAINT [unique-id-bus_rel_line_inci] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-04', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 617, '7:fa32fc4ac2c01c4e42344e2635751e5e', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] ADD CONSTRAINT [unique-id-bus_route] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-05', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 618, '7:95d9fed6f557ff4a79995b4fc502b5d3', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_incidencia] ADD CONSTRAINT [unique-id-bus_incidencia] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-06', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 619, '7:7e34ac2baaaa1c5686296323e59fba60', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [unique-id-bus_poinonrout] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-07', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 620, '7:0ca080ea62850f2d5acf20a9d7a6e461', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [unique-id-bus_jourpatt] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-08', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 621, '7:1732c70c36257ec33137ee7ee9c00919', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [unique-id-bus_stopoiinjoupat] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-09', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 622, '7:d582b09ecaf69c66fdc260f8853d4dc6', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_parada] ADD CONSTRAINT [unique-id-bus_parada] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-10', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 623, '7:46be4fc4dabee1807cc7cd03d4efd210', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-11::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [unique-id-bus_vehijour] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-11', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 624, '7:310314d4a5e645bb912188f6c735c1d2', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-12::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ADD CONSTRAINT [unique-id-bus_realpasstime] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-12', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 625, '7:60bbaed82c86a6d5bc7216ace0a1a53a', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-13::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ADD CONSTRAINT [unique-id-bus_headjourgroup] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-13', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 626, '7:ca9af7a3e057dcbd943a416add1791dc', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-14::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayinterval] ADD CONSTRAINT [unique-id-bus_headinte] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-14', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 627, '7:b8a320dc73a095379aebb2ed9a30e52a', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-15::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_servicecalendar] ADD CONSTRAINT [unique-id-bus_servicale] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-15', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 628, '7:8e0d18ea5822ba6e699f65e28279491d', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-16::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [unique-id-bus_daytypeassi] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-16', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 629, '7:c0e9abb52b6007a20f47d3964b1ed4a3', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-17::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytype] ADD CONSTRAINT [unique-id-bus_daytype] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-17', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 630, '7:da62bef29d1cc40cf18e433f37d981f3', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-18::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ADD CONSTRAINT [unique-id-bus_schestoppoin] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-18', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 631, '7:5aede46fbb92c517f002024ee0600cee', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-1::Localidata
CREATE NONCLUSTERED INDEX [index_bus_afectada_incidencia] ON [schema_ciudadesAbiertas].[bus_rel_linea_incidencia]([afectada_incidencia])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-1', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 632, '7:713c424068bb0352155f650c6d7ee4ef', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-2::Localidata
CREATE NONCLUSTERED INDEX [index_bus_cabecera_linea] ON [schema_ciudadesAbiertas].[bus_linea]([cabecera_linea])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-2', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 633, '7:f572c5ac2fe77131b847137ff03737dc', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-3::Localidata
CREATE NONCLUSTERED INDEX [index_bus_composed_of] ON [schema_ciudadesAbiertas].[bus_vehiclejourney]([composed_of])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-3', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 634, '7:3bf460c87c2847ba8fef84f0fa6bde71', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-4::Localidata
CREATE NONCLUSTERED INDEX [index_bus_determined_by] ON [schema_ciudadesAbiertas].[bus_headwayjourneygroup]([determined_by])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-4', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 635, '7:5f4f1d911d2009d56bb747a8a64c4b0d', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-5::Localidata
CREATE NONCLUSTERED INDEX [index_bus_final_linea] ON [schema_ciudadesAbiertas].[bus_linea]([final_linea])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-5', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 636, '7:caf9a9f7e4f172ae9b231f60396681fb', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-6::Localidata
CREATE NONCLUSTERED INDEX [index_bus_for_the_defi_of] ON [schema_ciudadesAbiertas].[bus_daytypeassignment]([for_the_definition_of])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-6', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 637, '7:14f2e5787969d813fb29395fc6374c07', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-7::Localidata
CREATE NONCLUSTERED INDEX [index_bus_func_cent_for_1] ON [schema_ciudadesAbiertas].[bus_pointonroute]([functional_centroid_for])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-7', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 638, '7:42dd956691c847fa7a4037bdff5a2410', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-9::Localidata
CREATE NONCLUSTERED INDEX [index_bus_gene_por_inci] ON [schema_ciudadesAbiertas].[bus_journeypattern]([generado_por_incidencia])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-9', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 639, '7:653bddd1643a284300e7c5f47f10c5c5', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-10::Localidata
CREATE NONCLUSTERED INDEX [index_bus_has_feat_of_inte] ON [schema_ciudadesAbiertas].[bus_realtime_passing_time]([has_feature_of_interest])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-10', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 640, '7:429085cc9bfad9019905fe07ab7b6203', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-12::Localidata
CREATE NONCLUSTERED INDEX [index_bus_in_1] ON [schema_ciudadesAbiertas].[bus_pointonroute]([in_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-12', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 641, '7:9c962195cacb4772a1f70d6931015c6c', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-13::Localidata
CREATE NONCLUSTERED INDEX [index_bus_in_2] ON [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern]([in_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-13', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 642, '7:35067b410b19361f0ba4882584548b24', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-14::Localidata
CREATE NONCLUSTERED INDEX [index_bus_made_using] ON [schema_ciudadesAbiertas].[bus_vehiclejourney]([made_using])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-14', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 643, '7:166c40ba7e173c08e60ee22018e3cf54', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-15::Localidata
CREATE NONCLUSTERED INDEX [index_bus_on_1] ON [schema_ciudadesAbiertas].[bus_journeypattern]([on_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-15', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 644, '7:c9caadc8036dc9ba0c476af753918030', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-16::Localidata
CREATE NONCLUSTERED INDEX [index_bus_on_id_2] ON [schema_ciudadesAbiertas].[bus_route]([on_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-16', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 645, '7:980ff21ccc57d46f1475af331bc6d720', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-17::Localidata
CREATE NONCLUSTERED INDEX [index_bus_operating] ON [schema_ciudadesAbiertas].[bus_linea]([operating])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-17', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 646, '7:69453e2236eca60fc07cd3cf20b51d04', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-18::Localidata
CREATE NONCLUSTERED INDEX [index_bus_serving_pt_for] ON [schema_ciudadesAbiertas].[bus_operator]([serving_pt_for])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-18', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 647, '7:f3780871a2f15ac40ab711668e2536b6', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-19::Localidata
CREATE NONCLUSTERED INDEX [index_bus_specifying] ON [schema_ciudadesAbiertas].[bus_daytypeassignment]([specifying])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-19', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 648, '7:d08ddea724a8add8a2631794718be63c', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-20::Localidata
CREATE NONCLUSTERED INDEX [index_bus_worked_on] ON [schema_ciudadesAbiertas].[bus_vehiclejourney]([worked_on])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-20', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 649, '7:e91de6bde9ded22e6ce91ed1d127f0e5', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-21::Localidata
CREATE NONCLUSTERED INDEX [index_bus_centroid_route] ON [schema_ciudadesAbiertas].[bus_scheduled_stop_point]([functional_centroid_for])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-21', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 650, '7:4bae1fe487730736ebfc12ef8fabd1c5', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-22::Localidata
CREATE NONCLUSTERED INDEX [index_bus_journew_viewed] ON [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern]([viewed_as])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-22', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 651, '7:820d84e3be19d3acba5742b347349935', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_authority::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_authority] ([ikey], [id], [telephone], [email], [url], [legal_name], [alternate_name], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSAUTH01', 'crtm', '+34 91 406 88 10', 'info@crtm.es', 'https://www.crtm.es', 'Consorcio de transportes de Madrid', 'CRTM', 'PORTAL000119', 'Calle Cerro de la Plata, 4', '28007', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_authority', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 652, '7:0794feb59250db60bc837ec0e3002a6d', 'insert', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_daytype::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_daytype] ([ikey], [id], [title], [description], [short_name], [earliest_time]) VALUES ('BUSDAYTYP01', 'laborable', N'D�a laborable', N'Horario general para el servicio de EMT en d�a laborable.', 'Laborables', '05:30:00')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_daytype] ([ikey], [id], [title], [description], [short_name], [earliest_time]) VALUES ('BUSDAYTYP02', 'festivo', N'D�a festivo', N'Horario general para el servicio de EMT en d�a festivo.', 'Festivos', '06:30:00')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_daytype', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 653, '7:ae9f357fdbbdeaa801f9aef594418cf6', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_daytypeassignment::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_daytypeassignment] ([ikey], [id], [date_assignment], [is_available], [specifying], [for_the_definition_of]) VALUES ('BUSDAYASS01', '2020-01-02-CAL01-laborable', '2020-01-02T00:00:00.000', 1, 'laborable', '2020')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_daytypeassignment] ([ikey], [id], [date_assignment], [is_available], [specifying], [for_the_definition_of]) VALUES ('BUSDAYASS02', '2020-02-02-CAL01-laborable', '2020-02-02T00:00:00.000', 1, 'laborable', '2020')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_daytypeassignment', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 654, '7:2c18fa71a0776e79041567a178ffc733', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_headwayinterval::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey], [id], [minimum_headway_interval], [maximum_headway_interval], [scheduled_headway_interval]) VALUES ('BUSHEAINT01', '6-laborable', 'P7M', 'P20M', 'Cada 7 - 20 min.')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey], [id], [minimum_headway_interval], [maximum_headway_interval], [scheduled_headway_interval]) VALUES ('BUSHEAINT02', '66-laborable', 'P5M', 'P15M', 'Cada 5 - 15 min.')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey], [id], [minimum_headway_interval], [maximum_headway_interval], [scheduled_headway_interval]) VALUES ('BUSHEAINT03', '138-laborable', 'P10M', 'P30M', 'Cada 10 - 30 min.')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_headwayinterval', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 655, '7:9f8962f4d0417ec73b786df1de7afdf9', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_headwayjourneygroup::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey], [id], [first_departure_time], [last_departure_time], [determined_by]) VALUES ('BUSHEAJOU01', '6a1-laborable', '06:15:00', '23:30:00', '6-laborable')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey], [id], [first_departure_time], [last_departure_time], [determined_by]) VALUES ('BUSHEAJOU02', '66a1-laborable', '06:15:00', '23:30:00', '66-laborable')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey], [id], [first_departure_time], [last_departure_time], [determined_by]) VALUES ('BUSHEAJOU03', '138a1-laborable', '06:15:00', '23:30:00', '138-laborable')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_headwayjourneygroup', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 656, '7:a561d4a34505630b6c928205076a88be', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_incidencia::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [x_etrs89], [y_etrs89], [incidencia_tramo_id], [incidencia_tramo_description], [street_address], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('29059944-382A-49AA-A068-B55BF2FAC51F', 'BUSINC01', N'Corte de calles entre el cruce de Alcal� con Gran V�a y la Plaza de la Independencia', 'obras', '2020-03-31T08:00:00.000', 2, 8, 0, '2020-05-03T23:59:00.000', 440124.33000, 4474637.17000, 'TRAFTRAM01', N'Calles entre el cruce de Alcal� con Gran V�a y la Plaza de la Independencia', 'Calle Pruebas, 4', '28006', 'PORTAL000119', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [x_etrs89], [y_etrs89], [incidencia_tramo_id], [incidencia_tramo_description], [street_address], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('30059944-382A-49AA-A068-B55BF2FAC51F', 'BUSINC02', N'Corte de calles entre Gran V�a y la Plaza de Callao', 'obras', '2020-04-30T08:00:00.000', 4, 6, 0, '2020-06-03T23:59:00.000', 440124.33000, 4474637.17000, 'TRAFTRAM01', N'Calles entre el cruce de Alcal� con Gran V�a y la Plaza de la Independencia', 'Calle Pruebas, 64', '28006', 'PORTAL000117', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [x_etrs89], [y_etrs89], [incidencia_tramo_id], [incidencia_tramo_description], [street_address], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('18059944-382A-49AA-A068-B55BF2FAC51F', 'BUSINC03', N'Corte de calles entre el cruce de Alcal� y  la Plaza de Sol', 'obras', '2020-02-28T08:00:00.000', 2, 8, 0, '2020-07-03T23:59:00.000', 440124.33000, 4474637.17000, 'TRAFTRAM01', N'Calles entre el cruce de Alcal� con Gran V�a y la Plaza de la Independencia', 'Calle Pruebas, xx', '28006', 'PORTAL000121', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_incidencia', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 657, '7:c33d5f66f0b41b2831174274c659f798', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_journeypattern::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey], [id], [title], [distance], [on_id], [generado_por_incidencia], [front_text]) VALUES ('BUSJOUPAT01', '6a2', '6a2', 11.19, '6a', 'BUSINC01', 'Benavente')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey], [id], [title], [distance], [on_id], [generado_por_incidencia], [front_text]) VALUES ('BUSJOUPAT02', '66a2', '66a2', 12.14, '66a', 'BUSINC02', 'Cuatro Caminos')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey], [id], [title], [distance], [on_id], [generado_por_incidencia], [front_text]) VALUES ('BUSJOUPAT03', '138a2', '138a2', 14.94, '138a', 'BUSINC03', 'San Ignacio de Loyola')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_journeypattern', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 658, '7:bb3024c9dd0d9c58a128748e70b0324f', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_linea::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_linea] ([ikey], [id], [description], [title], [url], [short_name], [cabecera_linea], [final_linea], [distance], [operating], [colour], [text_colour]) VALUES ('BUSLIN01', '6', N'La l�nea 6 de la EMT de Madrid une la plaza de Jacinto Benavente con el barrio de Orcasitas, en el distrito de Usera.', N'L�nea 6', 'https://www.emtmadrid.es/Bloques-EMT/EMT-BUS/Mi-linea-(1).aspx?linea=6&lang=es-ES', '6', '1918', '5359', 51, 'emt', 'Azul', 'Negro')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_linea] ([ikey], [id], [description], [title], [url], [short_name], [cabecera_linea], [final_linea], [distance], [operating], [colour], [text_colour]) VALUES ('BUSLIN02', '138', N'La l�nea 138 de la EMT de Madrid une el Hospital Cl�nico San Carlos con la Colonia San Ignacio de Loyola, atravesando el eje Valmojado-Sep�lveda-Caramuel y el intercambiador de Aluche.', N'L�nea 138', 'https://www.emtmadrid.es/Bloques-EMT/EMT-BUS/Mi-linea-(1).aspx?linea=138&lang=es-ES', '138', '4608', '5481', 58.34, 'emt', 'Azul', 'Negro')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_linea] ([ikey], [id], [description], [title], [url], [short_name], [cabecera_linea], [final_linea], [distance], [operating], [colour], [text_colour]) VALUES ('BUSLIN03', '66', N'La l�nea 66 de la EMT de Madrid une la Glorieta de Cuatro Caminos con Fuencarral.', N'L�nea 66', 'https://www.emtmadrid.es/Bloques-EMT/EMT-BUS/Mi-linea-(1).aspx?linea=66&lang=es-ES', '66', '3219', '5105', 44.4, 'emt', 'Azul', 'Negro')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_linea', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 659, '7:514bb1ee8a4b525a3862eedb7307fb09', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_operator::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_operator] ([ikey], [id], [serving_pt_for], [telephone], [email], [url], [legal_name], [alternate_name], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSOPE01', 'emt', 'crtm', '+34 91 406 88 10', 'info@emt.es', 'https://www.emtmadrid.es/AtencionAlCliente/Agradecimientos', 'Empresa Municipal de Transportes', 'EMT', 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_operator', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 660, '7:b78f0e34e85296a469b6ba4fee51b970', 'insert', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_parada::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR1', '3219', 'Cuatro Caminos', 'Cuatro Caminos', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28079', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR2', '1918', 'Benavente', 'Benavente', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR3', '5359', 'Orcasitas', 'Orcasitas', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR4', '4608', 'Cristo Rey', 'Cristo Rey', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR5', '5481', 'San Ignacio', 'San Ignacio', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR6', '5105', 'Fuencarral', 'Fuencarral', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_parada', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 661, '7:fb88fe9acbee576fc690aa4265f6233b', 'insert (x6)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_pointonroute::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIROU01', '6a-1918', 1, 0.0, '6a', '1918')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIROU02', '66a-3219', 1, 0.0, '66a', '3219')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIROU03', '138a-4608', 1, 0.0, '138a', '4608')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_pointonroute', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 662, '7:19932abdc212f8e45f4281551516f8f3', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_realtimepassingtime::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey], [id], [result_time], [expected_arrival_time], [has_feature_of_interest]) VALUES ('BUSREATIM01', '6a2-1918', '2020-05-13T12:45:05.000', 'PT15M', '6a2-1918')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey], [id], [result_time], [expected_arrival_time], [has_feature_of_interest]) VALUES ('BUSREATIM02', '66a2-3219', '2020-05-13T12:35:05.000', 'PT10M', '66a2-3219')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey], [id], [result_time], [expected_arrival_time], [has_feature_of_interest]) VALUES ('BUSREATIM03', '138a2-4608', '2020-05-13T12:25:05.000', 'PT20M', '138a2-4608')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_realtimepassingtime', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 663, '7:2573a42b89b53914e36b852d38c75dd2', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_rel_linea_incidencia::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey], [id], [linea], [afectada_incidencia]) VALUES ('18059944-382A-49AA-A068-B55BF2FAC51F', 'BUSRELLININC01', '6', 'BUSINC01')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey], [id], [linea], [afectada_incidencia]) VALUES ('29059944-382A-49AA-A068-B55BF2FAC51F', 'BUSRELLININC02', '66', 'BUSINC02')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey], [id], [linea], [afectada_incidencia]) VALUES ('30059944-382A-49AA-A068-B55BF2FAC51F', 'BUSRELLININC03', '138', 'BUSINC03')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_rel_linea_incidencia', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 664, '7:4d19c18187767ed467ac03de8aadf0fa', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_route::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU01', '6a', N'L�nea 6, comienzo en plaza de Jacinto Benavente y final en Orcasitas', 'outbound', '6')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU02', '66a', N'L�nea 6, comienzo en Glorieta de Cuatro Caminos y final en Fuencarral', 'outbound', '66')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU03', '138a', N'L�nea 138, comienzo en Cristo Rey y final en San Ignacio de Loyola', 'outbound', '138')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_route', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 665, '7:4484b7a95736a9c501641bf1097e4fc0', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_servicecalendar::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_servicecalendar] ([ikey], [id], [title], [description], [short_name], [from_day], [to_day]) VALUES ('BUSSERCAL01', '2020', 'Calendario de servicio de la EMT Madrid para 2020', 'Calendario de servicio de la EMT Madrid para 2020', 'Calendario Servicio EMT Madrid 2020', '2020-01-01T00:00:00.000', '2020-12-31T00:00:00.000')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_servicecalendar] ([ikey], [id], [title], [description], [short_name], [from_day], [to_day]) VALUES ('BUSSERCAL02', '2021', 'Calendario de servicio de la EMT Madrid para 2021', 'Calendario de servicio de la EMT Madrid para 2021', 'Calendario Servicio EMT Madrid 2021', '2021-01-01T00:00:00.000', '2021-12-31T00:00:00.000')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_servicecalendar', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 666, '7:3efa3259c661cb07def6c06987bcd5e0', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_stoppointinjourneypattern::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey], [id], [order_stop], [stop_use], [in_id], [viewed_as]) VALUES ('BUSSTOPOI01', '6a2-1918', 1, 'pass-through', '6a2', '138a1-4608')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey], [id], [order_stop], [stop_use], [in_id], [viewed_as]) VALUES ('BUSSTOPOI02', '66a2-3219', 1, 'pass-through', '66a2', '138a1-4618')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey], [id], [order_stop], [stop_use], [in_id], [viewed_as]) VALUES ('BUSSTOPOI03', '138a2-4608', 1, 'pass-through', '138a2', '138a1-4628')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_stoppointinjourneypattern', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 667, '7:d9ececf7fdcd3963b545a4f5605c3308', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_routePoint::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey], [id], [functional_centroid_for], [alighting], [boarding], [title_stop_area]) VALUES ('RPOINT01', '138a1-4608', '1918', 1, 0, 'Benavente')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey], [id], [functional_centroid_for], [alighting], [boarding], [title_stop_area]) VALUES ('RPOINT02', '138a1-4618', '3219', 1, 0, 'Cuatro Caminos')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey], [id], [functional_centroid_for], [alighting], [boarding], [title_stop_area]) VALUES ('RPOINT03', '138a1-4628', '4608', 1, 0, 'Cristo Rey')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_routePoint', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 668, '7:91466fa3533b978edb640916f9669196', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_vehiclejourney::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey], [id], [journey_duration], [departure_time], [made_using], [worked_on], [composed_of], [direction_type]) VALUES ('BUSVEHJOU01', '6a1', 'P1D', '09:00:00', '6a2', 'laborable', '6a1-laborable', 'outbound')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey], [id], [journey_duration], [departure_time], [made_using], [worked_on], [composed_of], [direction_type]) VALUES ('BUSVEHJOU02', '66a1', 'P1D', '09:00:00', '66a2', 'laborable', '66a1-laborable', 'outbound')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey], [id], [journey_duration], [departure_time], [made_using], [worked_on], [composed_of], [direction_type]) VALUES ('BUSVEHJOU03', '138a1', 'P1D', '09:00:00', '138a2', 'laborable', '138a1-laborable', 'outbound')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_vehiclejourney', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 669, '7:026d4b444ac5172ffbf92f616600cae2', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::DATA-AUTOBUS-tag-1.26::Localidata
INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [TAG]) VALUES ('DATA-AUTOBUS-tag-1.26', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 670, '7:054fad0894de536b5d021fba56482848', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.4.2', '1.26')
GO

-- Changeset liquibase/db-changelog-script-1.98.2-ORGANIGRAMA-data.xml::organigramaFixLatLong::Localidata
UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674456.74194,  y_etrs89= 4614129.57874 WHERE id = '61326'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '23831'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '23829'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '61632'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677755.36471,  y_etrs89= 4611562.71288 WHERE id = '23830'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675772.72811,  y_etrs89= 4614357.32503 WHERE id = '61633'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 683188.86682,  y_etrs89= 4625428.39143 WHERE id = '25111'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20823'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20254'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20800'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20805'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20836'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20806'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61664'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674739.65849,  y_etrs89= 4614346.34635 WHERE id = '25207'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674740.77021,  y_etrs89= 4614382.10059 WHERE id = '61307'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61318'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25118'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 680601.16252,  y_etrs89= 4615051.40101 WHERE id = '61322'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 680601.16252,  y_etrs89= 4615051.40101 WHERE id = '25112'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61313'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675783.16079,  y_etrs89= 4615509.16137 WHERE id = '61299'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677310.39785,  y_etrs89= 4613304.69061 WHERE id = '60142'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 672480.00493,  y_etrs89= 4613157.75924 WHERE id = '25208'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25203'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676060.50556,  y_etrs89= 4613818.33316 WHERE id = '61321'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681309.25453,  y_etrs89= 4608341.08128 WHERE id = '61308'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681309.25453,  y_etrs89= 4608341.08128 WHERE id = '25102'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61303'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60263'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23839'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23940'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60269'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60238'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23835'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23955'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60056'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23978'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60257'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60216'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23969'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23946'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60262'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61487'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60166'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '60128'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61488'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '20265'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23989'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23956'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61585'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '23828'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676154.00922,  y_etrs89= 4613078.95944 WHERE id = '61489'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676427.17355,  y_etrs89= 4610737.65869 WHERE id = '25101'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676571.28922,  y_etrs89= 4613292.99832 WHERE id = '25020'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '61363'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '20818'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '20844'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '20843'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '21245'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '60221'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '21244'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674880.52134,  y_etrs89= 4611935.80128 WHERE id = '61365'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674848.45868,  y_etrs89= 4611952.68218 WHERE id = '21243'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674848.45868,  y_etrs89= 4611952.68218 WHERE id = '21242'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674848.45868,  y_etrs89= 4611952.68218 WHERE id = '25204'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676853.64669,  y_etrs89= 4613526.95205 WHERE id = '61609'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676853.64669,  y_etrs89= 4613526.95205 WHERE id = '61611'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675553.18841,  y_etrs89= 4614039.58798 WHERE id = '60191'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675553.18841,  y_etrs89= 4614039.58798 WHERE id = '61117'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675553.18841,  y_etrs89= 4614039.58798 WHERE id = '60157'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674666.17312,  y_etrs89= 4611717.91885 WHERE id = '25030'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677462.05289,  y_etrs89= 4612629.91028 WHERE id = '25206'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675694.66041,  y_etrs89= 4612820.00101 WHERE id = '25202'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677051.82088,  y_etrs89= 4613223.93785 WHERE id = '61310'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60099'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20557'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60167'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60110'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60148'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20119'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61165'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60150'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60129'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60121'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60162'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60132'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60075'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61617'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60151'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60138'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60145'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60130'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60115'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60074'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60124'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60001'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60119'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26057'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674290.41810,  y_etrs89= 4610815.89193 WHERE id = '25117'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61316'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20231'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678185.38293,  y_etrs89= 4614444.69305 WHERE id = '61309'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675709.12652,  y_etrs89= 4615868.05000 WHERE id = '25211'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677537.45369,  y_etrs89= 4614614.73837 WHERE id = '25010'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677537.45369,  y_etrs89= 4614614.73837 WHERE id = '61382'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681064.18322,  y_etrs89= 4617130.66068 WHERE id = '25107'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '20235'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '60283'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '20217'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677348.35220,  y_etrs89= 4612518.36553 WHERE id = '61311'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676258.66143,  y_etrs89= 4610808.60062 WHERE id = '25209'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676258.66143,  y_etrs89= 4610808.60062 WHERE id = '61323'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 679064.80677,  y_etrs89= 4596766.26689 WHERE id = '25114'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677170.94516,  y_etrs89= 4614164.52103 WHERE id = '25212'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 664775.33244,  y_etrs89= 4617548.51453 WHERE id = '60230'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '20236'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61208'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61634'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61681'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61592'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676358.42538,  y_etrs89= 4613620.43877 WHERE id = '61472'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '60189'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '61143'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '61142'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '20516'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676875.91456,  y_etrs89= 4614981.19995 WHERE id = '61140'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25116'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677097.25530,  y_etrs89= 4611317.22890 WHERE id = '60193'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 671189.60772,  y_etrs89= 4613933.77215 WHERE id = '61312'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 671189.60772,  y_etrs89= 4613933.77215 WHERE id = '25108'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678133.17982,  y_etrs89= 4615425.79934 WHERE id = '23811'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678133.17982,  y_etrs89= 4615425.79934 WHERE id = '61624'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 678597.24447,  y_etrs89= 4616279.91171 WHERE id = '23968'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60028'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60016'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60097'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60171'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60002'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60017'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '60043'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676658.10762,  y_etrs89= 4612800.17719 WHERE id = '20247'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '23846'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61670'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '20333'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '20331'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '60293'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 677423.64602,  y_etrs89= 4613236.83001 WHERE id = '60242'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681391.11541,  y_etrs89= 4613171.28462 WHERE id = '25113'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 681391.11541,  y_etrs89= 4613171.28462 WHERE id = '61320'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61325'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60013'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60085'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60011'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61615'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60052'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60067'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61613'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60104'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61608'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60183'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60185'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '61612'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60140'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60108'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60177'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60010'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676892.32526,  y_etrs89= 4613279.67654 WHERE id = '60111'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 664051.42771,  y_etrs89= 4620479.28716 WHERE id = '25103'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 664051.42771,  y_etrs89= 4620479.28716 WHERE id = '61302'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25105'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61305'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674617.28711,  y_etrs89= 4617994.03830 WHERE id = '61315'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674617.28711,  y_etrs89= 4617994.03830 WHERE id = '25109'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674621.55512,  y_etrs89= 4617990.94218 WHERE id = '61306'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674621.55512,  y_etrs89= 4617990.94218 WHERE id = '25205'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674621.55512,  y_etrs89= 4617990.94218 WHERE id = '61319'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674662.11302,  y_etrs89= 4617968.65932 WHERE id = '25106'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61586'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60303'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61677'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60295'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60306'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61583'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26050'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60165'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61581'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61665'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60022'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60299'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60237'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60298'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61580'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20298'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61223'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61225'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '24110'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26027'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61587'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61591'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26019'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60090'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60173'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60314'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60030'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26042'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61584'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60073'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60047'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26037'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10951'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20104'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60240'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61590'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60180'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26051'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61578'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26020'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60048'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60181'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60082'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '26052'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60305'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60078'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61530'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60300'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60184'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10953'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10100'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60220'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60006'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '21251'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60211'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60246'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60222'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60324'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60330'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '10950'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60076'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '20422'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60318'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60164'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60107'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60174'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '60226'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676775.93344,  y_etrs89= 4614306.32691 WHERE id = '61300'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676063.38654,  y_etrs89= 4613713.35468 WHERE id = '25201'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675950.94205,  y_etrs89= 4613736.62826 WHERE id = '61631'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675950.94205,  y_etrs89= 4613736.62826 WHERE id = '70001'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '25110'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 676578.72520,  y_etrs89= 4613806.70869 WHERE id = '61314'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 682899.44260,  y_etrs89= 4625531.79551 WHERE id = '20206'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 682899.44260,  y_etrs89= 4625531.79551 WHERE id = '61705'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 682899.44260,  y_etrs89= 4625531.79551 WHERE id = '60285'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26015'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61621'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60254'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60192'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60137'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60084'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60057'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23300'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23900'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23333'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20259'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60275'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23252'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23270'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60247'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23310'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60236'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60033'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23497'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60169'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61215'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26031'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60172'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60079'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61622'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60105'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23318'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26043'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23496'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61437'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26017'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60096'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61589'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23565'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23610'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60077'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61742'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60032'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60215'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23515'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23503'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61201'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23615'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61603'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61774'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60288'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61627'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23344'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23593'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23542'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23467'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '24100'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60065'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60304'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20337'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61571'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '24105'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26035'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23965'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60127'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60309'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23776'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61378'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60227'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23575'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61246'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23510'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23535'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60217'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20213'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23517'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60063'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23827'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23578'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60244'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23660'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26040'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23537'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23460'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23960'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23498'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61294'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23340'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23581'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61743'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '26028'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23587'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20350'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61773'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61200'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60343'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60290'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23650'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23627'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23251'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23636'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60015'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60178'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '21220'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23342'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61433'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60278'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23771'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '20200'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23747'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23616'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23766'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '60274'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23797'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61765'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23740'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23767'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23768'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '61438'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23789'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23788'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673986.54037,  y_etrs89= 4611397.00594 WHERE id = '23721'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674256.33189,  y_etrs89= 4612526.08004 WHERE id = '61304'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60093'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60214'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60235'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 675026.62302,  y_etrs89= 4613452.89399 WHERE id = '60106'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673972.77796,  y_etrs89= 4611025.21561 WHERE id = '61301'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 673972.77796,  y_etrs89= 4611025.21561 WHERE id = '25104'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  x_etrs89 = 674843.85163,  y_etrs89= 4611874.66082 WHERE id = '61324'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA AUTONOMIA 14' WHERE id = '61326'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '23831'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '23829'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '61632'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA CESAREO ALIERTA 120' WHERE id = '23830'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA DE RANILLAS 1' WHERE id = '61633'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA PE�AFLOR 71' WHERE id = '25111'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20823'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20254'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20800'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20805'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20836'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '20806'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA POLICIA LOCAL' WHERE id = '61664'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA PUERTA DE SANCHO 28' WHERE id = '25207'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA PUERTA DE SANCHO 30' WHERE id = '61307'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SAN GREGORIO 14' WHERE id = '61318'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SAN GREGORIO 14' WHERE id = '25118'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SANTA ISABEL 100' WHERE id = '61322'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDA SANTA ISABEL 100' WHERE id = '25112'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'AVENIDADE  MNT MONTA�ANA 374' WHERE id = '61313'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ALBERTO DUCE 2' WHERE id = '61299'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ALONSO V 30' WHERE id = '60142'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ANTONIO DE LEYVA 87' WHERE id = '25208'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ANTONIO MOMPEON MOTOS 12' WHERE id = '25203'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ARMAS 61' WHERE id = '61321'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE AUTONOMIA DE ARAG�N 21' WHERE id = '61308'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE AUTONOMIA DE ARAG�N 21' WHERE id = '25102'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61303'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60263'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23839'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23940'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60269'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60238'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23835'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23955'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60056'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23978'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60257'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60216'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23969'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23946'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60262'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61487'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60166'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '60128'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61488'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '20265'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23989'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23956'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61585'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '23828'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASA JIMENEZ 5' WHERE id = '61489'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE CASTELLAR 23' WHERE id = '25101'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE COSO 57' WHERE id = '25020'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '61363'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '20818'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '20844'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 1' WHERE id = '20843'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '21245'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '60221'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '21244'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 3' WHERE id = '61365'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 5' WHERE id = '21243'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 5' WHERE id = '21242'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DOMINGO MIRAL 5' WHERE id = '25204'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DON JUAN DE ARAGON 2' WHERE id = '61609'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE DON JUAN DE ARAGON 2' WHERE id = '61611'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ECHEGARAY Y CABALLERO 2' WHERE id = '60191'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ECHEGARAY Y CABALLERO 2' WHERE id = '61117'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE ECHEGARAY Y CABALLERO 2' WHERE id = '60157'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE EDUARDO IBARRA 6' WHERE id = '25030'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE FLORENTINO BALLESTEROS' WHERE id = '25206'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE HERNAN CORTES 31' WHERE id = '25202'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE HEROISMO 5' WHERE id = '61310'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60099'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '20557'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60167'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60110'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60148'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '20119'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '61165'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60150'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60129'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60121'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60162'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60132'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60075'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '61617'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60151'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60138'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60145'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60130'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60115'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60074'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60124'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60001'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE LUIS ALBAREDA 4' WHERE id = '60119'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE JOSE PALAFOX 29' WHERE id = '26057'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE LAS ESCUELAS 7' WHERE id = '25117'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE LUCIO ANNEO SENECA 78' WHERE id = '61316'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE LUIS LEGAZ LACAMBRA 34' WHERE id = '20231'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MARIA VIRTO' WHERE id = '61309'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MARIA ZAMBRANO 56' WHERE id = '25211'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MAS DE LAS MATAS 20' WHERE id = '25010'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MAS DE LAS MATAS 20' WHERE id = '61382'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MAYOR 115' WHERE id = '25107'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '20235'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '60283'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '20217'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MIGUEL SERVET 57' WHERE id = '61311'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MONZON' WHERE id = '25209'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE MONZON' WHERE id = '61323'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE PARADERO 1,' WHERE id = '25114'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE PERDIGUERA 7' WHERE id = '25212'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE DEL PINAR' WHERE id = '60230'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '20236'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61208'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61634'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61681'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61592'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE TORRE NUEVA 25' WHERE id = '61472'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '60189'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '61143'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '61142'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '20516'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CALLE VALLE DE BROTO 16' WHERE id = '61140'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO  VNO TOMILLAR 1' WHERE id = '25116'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO DE MIRAFLORES 11' WHERE id = '60193'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO DEL PILON 147' WHERE id = '61312'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CAMINO DEL PILON 147' WHERE id = '25108'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CARRETERA COGULLADA' WHERE id = '23811'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CARRETERA COGULLADA' WHERE id = '61624'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'CARRETERA COGULLADA 51' WHERE id = '23968'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60028'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60016'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60097'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60171'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60002'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60017'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '60043'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO DE LA MINA 9' WHERE id = '20247'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO SAN SEBASTIAN' WHERE id = '23846'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PASEO SAN SEBASTIAN' WHERE id = '61670'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '20333'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '20331'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '60293'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA BELTRAN MARTINEZ' WHERE id = '60242'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE ESPA�A 9' WHERE id = '25113'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE ESPA�A 9' WHERE id = '61320'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE INMACULADA S/N' WHERE id = '61325'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60013'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60085'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60011'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61615'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60052'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60067'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61613'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60104'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61608'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60183'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60185'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '61612'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60140'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60108'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60177'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60010'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DE SAN CARLOS 4' WHERE id = '60111'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DEL CASTILLO 7' WHERE id = '25103'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA DEL CASTILLO 7' WHERE id = '61302'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA JOS� RAM�N ARANA' WHERE id = '25105'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA JOS� RAM�N ARANA' WHERE id = '61305'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 1' WHERE id = '61315'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 1' WHERE id = '25109'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 2' WHERE id = '61306'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 2' WHERE id = '25205'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 2' WHERE id = '61319'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA MAYOR 7' WHERE id = '25106'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61586'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60303'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61677'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60295'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60306'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61583'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26050'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60165'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61581'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61665'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60022'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60299'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60237'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60298'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61580'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '20298'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61223'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61225'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '24110'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26027'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61587'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61591'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26019'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60090'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60173'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60314'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60030'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26042'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61584'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60073'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60047'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26037'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '10951'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '20104'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60240'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61590'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60180'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26051'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61578'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26020'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60048'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60181'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60082'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '26052'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60305'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60078'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '61530'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60300'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60184'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '10953'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '10100'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60220'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60006'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '21251'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60211'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60246'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60222'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60324'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60330'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '10950'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60076'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '20422'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60318'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60164'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60107'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60174'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA NUESTRA SE�ORA DEL PILAR 18' WHERE id = '60226'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'PLAZA SAN GREGORIO' WHERE id = '61300'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SAN PABLO 37' WHERE id = '25201'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SAN PABLO 61' WHERE id = '61631'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SAN PABLO 61' WHERE id = '70001'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTA ANA 34' WHERE id = '25110'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTA ANA 34' WHERE id = '61314'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTIAGO 34' WHERE id = '20206'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTIAGO 34' WHERE id = '61705'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'SANTIAGO 34' WHERE id = '60285'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26015'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61621'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60254'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60192'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60137'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60084'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60057'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23300'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23900'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23333'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20259'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60275'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23252'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23270'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60247'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23310'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60236'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60033'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23497'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60169'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61215'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26031'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60172'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60079'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61622'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60105'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23318'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26043'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23496'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61437'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26017'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60096'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61589'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23565'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23610'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60077'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61742'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60032'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60215'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23515'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23503'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61201'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23615'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61603'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61774'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60288'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61627'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23344'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23593'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23542'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23467'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '24100'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60065'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60304'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20337'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61571'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '24105'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26035'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23965'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60127'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60309'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23776'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61378'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60227'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23575'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61246'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23510'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23535'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60217'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20213'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23517'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60063'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23827'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23578'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60244'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23660'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26040'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23537'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23460'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23960'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23498'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61294'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23340'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23581'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61743'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '26028'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23587'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20350'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61773'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61200'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60343'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60290'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23650'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23627'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23251'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23636'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60015'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60178'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '21220'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23342'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61433'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60278'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23771'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '20200'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23747'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23616'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23766'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '60274'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23797'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61765'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23740'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23767'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23768'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '61438'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23789'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23788'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA HISPANIDAD 20' WHERE id = '23721'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIA UNIVERSITAS 28' WHERE id = '61304'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60093'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60214'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60235'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VICENTE BERDUSAN' WHERE id = '60106'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VI�EDO VIEJO 1' WHERE id = '61301'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VI�EDO VIEJO 1' WHERE id = '25104'
GO

UPDATE [schema_ciudadesAbiertas].[organigrama] SET  street_address = 'VIOLANTE DE HUNGRIA 4' WHERE id = '61324'
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('organigramaFixLatLong', 'Localidata', 'liquibase/db-changelog-script-1.98.2-ORGANIGRAMA-data.xml', GETDATE(), 671, '7:312fbd3e57aeda87a91c66d1e60fa898', 'sqlFile', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [bus_daytypassi_ibfk_1] FOREIGN KEY ([specifying]) REFERENCES [schema_ciudadesAbiertas].[bus_daytype] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-1', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 672, '7:69e34376045d65365eb3fdbfc52ef69a', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [bus_daytypeassi_ibfk_2] FOREIGN KEY ([for_the_definition_of]) REFERENCES [schema_ciudadesAbiertas].[bus_servicecalendar] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-2', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 673, '7:01675d9ccb07f36a2749353ffb827269', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ADD CONSTRAINT [bus_headjourgrou_ibfk_1] FOREIGN KEY ([determined_by]) REFERENCES [schema_ciudadesAbiertas].[bus_headwayinterval] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-3', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 674, '7:c29acdfce291840933335d39943e593b', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [bus_jourpatt_ibfk_1] FOREIGN KEY ([on_id]) REFERENCES [schema_ciudadesAbiertas].[bus_route] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-4', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 675, '7:0f13737ed84f4d349ced99307292f83f', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [bus_jourpatt_ibfk_2] FOREIGN KEY ([generado_por_incidencia]) REFERENCES [schema_ciudadesAbiertas].[bus_incidencia] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-5', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 676, '7:833509d71eae8265a8af5715b65f5ad2', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [bus_linea_ibfk_1] FOREIGN KEY ([operating]) REFERENCES [schema_ciudadesAbiertas].[bus_operator] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-6', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 677, '7:969639a99feb72475bb1bf32a6e722d5', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-7::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [bus_linea_ibfk_2] FOREIGN KEY ([cabecera_linea]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-7', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 678, '7:2633c5ed353f45b91cb3ac6bfee860e1', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-8::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [bus_linea_ibfk_3] FOREIGN KEY ([final_linea]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-8', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 679, '7:c76a3cabce9182f5c9a076c33f8c3177', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-9::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [bus_poinonrout_ibfk_1] FOREIGN KEY ([in_id]) REFERENCES [schema_ciudadesAbiertas].[bus_route] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-9', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 680, '7:4f75db24a45601fb7fce78f156a5a57b', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [bus_poinonrout_ibfk_2] FOREIGN KEY ([functional_centroid_for]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-10', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 681, '7:a62fa6bae106f171fe1b166eac1aa033', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-11::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ADD CONSTRAINT [bus_realpasstime_ibfk_1] FOREIGN KEY ([has_feature_of_interest]) REFERENCES [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-11', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 682, '7:2db5bc6c85fc6204c34e77c7102349ba', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-12::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ADD CONSTRAINT [bus_rel_line_inci_ibfk_1] FOREIGN KEY ([linea]) REFERENCES [schema_ciudadesAbiertas].[bus_linea] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-12', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 683, '7:0b5a2e117f79125b92a2b9624ad5d27f', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-13::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ADD CONSTRAINT [bus_rel_line_inci_ibfk_2] FOREIGN KEY ([afectada_incidencia]) REFERENCES [schema_ciudadesAbiertas].[bus_incidencia] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-13', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 684, '7:2390acbe81581d53f111bb16ffc25930', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-14::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] ADD CONSTRAINT [bus_route_ibfk_1] FOREIGN KEY ([on_id]) REFERENCES [schema_ciudadesAbiertas].[bus_linea] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-14', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 685, '7:dd810168471fb1beb5b344e03b640261', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-15::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [bus_stoppoinjourpatt_ibfk_1] FOREIGN KEY ([in_id]) REFERENCES [schema_ciudadesAbiertas].[bus_journeypattern] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-15', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 686, '7:54d750ed28423c24e8660da5e2dd111d', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-16::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ADD CONSTRAINT [bus_stoppoinjourpatt_ibfk_2] FOREIGN KEY ([functional_centroid_for]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-16', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 687, '7:787710659c1157da832f2f0a4bbe1b4a', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-17::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [bus_vehijour_ibfk_1] FOREIGN KEY ([made_using]) REFERENCES [schema_ciudadesAbiertas].[bus_journeypattern] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-17', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 688, '7:bd0a634855adb7148cb5314aa8c7f733', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-18::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [bus_vehijour_ibfk_2] FOREIGN KEY ([worked_on]) REFERENCES [schema_ciudadesAbiertas].[bus_daytype] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-18', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 689, '7:5d840a289d91a8a288180f2b6d460a06', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-19::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [bus_vehijour_ibfk_3] FOREIGN KEY ([composed_of]) REFERENCES [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-19', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 690, '7:d7a2cb23ffaeaea1d822f78dc0da346f', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-20::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] ADD CONSTRAINT [bus_ope_ibfk_1] FOREIGN KEY ([serving_pt_for]) REFERENCES [schema_ciudadesAbiertas].[bus_authority] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-20', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 691, '7:977392c964835683788e57b141b8e109', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-21::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [bus_route_p_ibfk_1] FOREIGN KEY ([viewed_as]) REFERENCES [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-21', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 692, '7:b1556e49cfbf362a4b0f321e7ce8d6d2', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Release Database Lock
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 0, [LOCKEDBY] = NULL, [LOCKGRANTED] = NULL WHERE [ID] = 1
GO

