-- *********************************************************************
-- Update Database Script
-- *********************************************************************
-- Change Log: liquibase/db-changelog-master.xml
-- Ran at: 18/11/20 13:42
-- Against: login_ciudadesAbiertas@jdbc:sqlserver://localhost:1433;useBulkCopyForBatchInsert=false;cancelQueryTimeout=-1;sslProtocol=TLS;jaasConfigurationName=SQLJDBCDriver;statementPoolingCacheSize=0;serverPreparedStatementDiscardThreshold=10;enablePrepareOnFirstPreparedStatementCall=false;fips=false;socketTimeout=0;authentication=NotSpecified;authenticationScheme=nativeAuthentication;xopenStates=false;sendTimeAsDatetime=true;trustStoreType=JKS;trustServerCertificate=false;TransparentNetworkIPResolution=true;serverNameAsACE=false;sendStringParametersAsUnicode=true;selectMethod=direct;responseBuffering=adaptive;queryTimeout=-1;packetSize=8000;multiSubnetFailover=false;loginTimeout=15;lockTimeout=-1;lastUpdateCount=true;encrypt=false;disableStatementPooling=true;databaseName=bbdd_ciudadesAbiertas;columnEncryptionSetting=Disabled;applicationName=Microsoft JDBC Driver for SQL Server;applicationIntent=readwrite;
-- Liquibase version: 3.4.2
-- *********************************************************************

USE [bbdd_ciudadesAbiertas];
GO

-- Lock Database
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 1, [LOCKEDBY] = 'CarlosM (192.168.56.1)', [LOCKGRANTED] = '2020-11-18T13:42:59.395' WHERE [ID] = 1 AND [LOCKED] = 0
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bbfce268af0d2d9b0cd2a79fb056cd15' WHERE [ID] = 'empty-ciudades-abiertas' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-0.0-EMPTY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:45840426b11d0e7a7c685c84fc636342' WHERE [ID] = 'table-ciudad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:163da683a506b391626e94588381e711' WHERE [ID] = 'table-estadistica' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b193f221ba44f8eb280b29fd59d4bd9' WHERE [ID] = 'table-oauth-access-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:62688a22372dd8f7c8eb59d9b73e5367' WHERE [ID] = 'table-oauth-approvals' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c97e2436866044a413f80a52588f6ec' WHERE [ID] = 'table-oauth-client-details' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9f9984fff938a4d5116ef6eceef4b01a' WHERE [ID] = 'table-oauth-client-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4c9bea4afc85cd184227f460427a2a36' WHERE [ID] = 'table-oauth-code' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e3ff3683926345e15d014b7a28cc0854' WHERE [ID] = 'table-oauth-refresh-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f97726314258c37899248c395df39665' WHERE [ID] = 'table-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e652fd1e9b69e8738bf20613721ffd39' WHERE [ID] = 'table-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c9f4157fb185eb137532c79cc89c175d' WHERE [ID] = 'table-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b116abd678e2679558ff6031f31802de' WHERE [ID] = 'table-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a1332aa076e0b118d770d2bae9b42838' WHERE [ID] = 'table-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b453c375749daad569e497b42ace2283' WHERE [ID] = 'PK-table-ciudad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cf7262df414fc451d07c883ea8427f7d' WHERE [ID] = 'PK-table-estadistica' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:991ead7eb536d8f74a80d5b90d218f04' WHERE [ID] = 'PK-table-oauth-access-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:886facdc9619f43493dd0a19e244603c' WHERE [ID] = 'PK-table-oauth-client-details' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:52ec1ab295b5e32febc60b64be33e9c3' WHERE [ID] = 'PK-table-oauth-client-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7332d9c46f9bb3dbeeee064f3ccfd49c' WHERE [ID] = 'PK-table-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:01de5d6fb10427b23ef21c9989e6d46b' WHERE [ID] = 'PK-table-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:96f86e27cdb2422b854506bb1fa4c84a' WHERE [ID] = 'Unique-field-user_roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fbac76edc3b9fbfbe0d64e954e5335e6' WHERE [ID] = 'Indice-username-table-user_roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cac64f75dd0e532ddf7ae8abde9b4618' WHERE [ID] = 'function-TRANSLAT' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-SQLSERVER-FUNCIONES.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8df17fcf0caad4e587f0ccd282497beb' WHERE [ID] = 'table-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:02c1162b6e60b4fa0ee9a779830f3e63' WHERE [ID] = 'PK-table-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1642ec6a87abb8d01df12019defa0e76' WHERE [ID] = 'Index-equipamiento-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5e349bb7313f1ff8aba39f3744c71d75' WHERE [ID] = 'table-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-PUNTO-INTERES-TURISTICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f9f67dbcbda6aec528c0e5f4de697ec2' WHERE [ID] = 'PK-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-PUNTO-INTERES-TURISTICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e1e42b952adaee61f6be271310dbb05b' WHERE [ID] = 'Index-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-PUNTO-INTERES-TURISTICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26162a03d12e0f90391fdc928c72c356' WHERE [ID] = 'data-ciudad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ac1092dcc0f09000fcf50228877d4e5a' WHERE [ID] = 'data-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:510f8602fefea9b6edb555dafb672949' WHERE [ID] = 'data-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ca7bbea357ee7c45482cc9354d94296' WHERE [ID] = 'data-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3f8747c4c08ac9ea4ed9ccc39fc62093' WHERE [ID] = 'data-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c641227f106de85fffe90f7a50316206' WHERE [ID] = 'data-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e1e0ad7e580044e3f6f7629dbee76df0' WHERE [ID] = 'PK-table-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:565c0dfcc407b9e477d41bc6ffd558af' WHERE [ID] = 'PK-table-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d17293c9f0aacd1f652b0d5b64ec81d1' WHERE [ID] = 'PK-table-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:76bd6afc490b2fed2aff27036df3791b' WHERE [ID] = 'FK-USER-ROLE-USERNAME' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:34873c68b5f685c58167c1cd4650afaf' WHERE [ID] = 'FK-GROUP-MEMBERS-USERS' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8dcbba0717c053e81702277e406a4c9d' WHERE [ID] = 'FK-GROUP-MEMBERS-GROUP' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:553a44914ab92b994237f8e1b522c9da' WHERE [ID] = 'FK-GROUP-AUTHORI-GROUP' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5560655641c5ef77bca6b90c5b234724' WHERE [ID] = 'DATA-CORE-tag-1.0' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d094637aa50c90ec47cc3906c198d909' WHERE [ID] = 'TablasTerritorio-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:735e42ea8c1ed0145a6320bdc6cda1eb' WHERE [ID] = 'TablasTerritorio-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:11409df443a7a2042bc215286fbb14e5' WHERE [ID] = 'TablasTerritorio-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:357a149ef3f495c47f2b093023ddc8bb' WHERE [ID] = 'TablasTerritorio-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2a64201eefcae189d10e6984ba813064' WHERE [ID] = 'TablasTerritorio-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d51893da23232a65fbb15abd96d4eca' WHERE [ID] = 'TablasTerritorio-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d7ab69b91b90fb84265377a380c11851' WHERE [ID] = 'TablasTerritorio-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fd5d3e2d67eac1e5217b0cc254c7b800' WHERE [ID] = 'TablasTerritorio-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e73e44f8b234311533a5ecf27abdf234' WHERE [ID] = 'TablasTerritorio-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c4dfb8f27667a149a03125b45013c45' WHERE [ID] = 'TablasTerritorio-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1a5c7be2fde8bc356850d9c4cdcf817c' WHERE [ID] = 'TablasTerritorio-11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ce7ba7ac0e430a91fe41c8c616070643' WHERE [ID] = 'TablasTerritorio-12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:07375c695904e230938b38a8651bb940' WHERE [ID] = 'TablasTerritorio-13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6707ece4250de63048ff1a268a1d5833' WHERE [ID] = 'TablasTerritorio-14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:63f31fb200acd7de4b8c6814007524ec' WHERE [ID] = 'TablasTerritorio-15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1126e3db326ffd6ad0fc677b1ee861b4' WHERE [ID] = 'TablasTerritorio-16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:63ac47bb8c80ef5edaf6ef8358013343' WHERE [ID] = 'TablasTerritorio-17' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8352d3abf82670b77b73ab9f798cf7b8' WHERE [ID] = 'TablasTerritorio-18' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:12334f0a8d4e640acfa92deee1abfa78' WHERE [ID] = 'TablasTerritorio-19' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:119fd680d6f50c44374d354669d5c9fd' WHERE [ID] = 'TablasTerritorio-20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d92381b81717eb0922396b3e57c94d0' WHERE [ID] = 'TablasTerritorio-21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c74b5db43e36c6ac8e0e54d94d037401' WHERE [ID] = 'TablasTerritorio-22' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b61bc8bcc6e413ce4ca4ef2b78d83630' WHERE [ID] = 'TablasTerritorio-23' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ffd09ab3b9e78c8dedf8464e31be677' WHERE [ID] = 'TablasTerritorio-24' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d2aa67c39c2ce13448adc7a5187f17f6' WHERE [ID] = 'TablasTerritorio-25' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e8fed14156a649bfb6b9aba119dad77b' WHERE [ID] = 'TablasTerritorio-26' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:18db541dcf85c4a95ff92c3e5b268b85' WHERE [ID] = 'TablasTerritorio-27' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6d99c5b3e03d778c265aafe4969af20b' WHERE [ID] = 'TablasTerritorio-28' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:59bbfa933fa49633e31344609571ad25' WHERE [ID] = 'TablasTerritorio-29' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0ca7b478d16d60ff0f7c7355ee78c73c' WHERE [ID] = 'TablasTerritorio-30' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:70744f741c651b2932d4d9b84a04f77c' WHERE [ID] = 'TablasTerritorio-31' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c30fab0edae14c4b35683b49180d57b' WHERE [ID] = 'TablasTerritorio-32' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:01db0597b50d2ef8db8b83b8e426fd15' WHERE [ID] = 'TablasTerritorio-33' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:407613f9165370442e57a179e0e2ad90' WHERE [ID] = 'TablasTerritorio-34' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:69d7f703b0fa1aab0e5c5d2b6dfb1c1f' WHERE [ID] = 'TablasTerritorio-35' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9d0849414f48ea4b01dfae42863d1172' WHERE [ID] = 'TablasTerritorio-36' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:31be6b90be21dbc81f858e3f3830ad95' WHERE [ID] = 'TablasTerritorio-37' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d601ce16eded90acfca4e5a43e23d650' WHERE [ID] = 'TablasTerritorio-38' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7e842552d49f8fe114aa199ab29bac7e' WHERE [ID] = 'TablasTerritorio-39' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f453da82f8d003686bcc35948bc3e77a' WHERE [ID] = 'TablasTerritorio-40' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:aacef3960d9c8164d8f801a9fd3b4670' WHERE [ID] = 'TablasTerritorio-41' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:edece915c0f36581ec54f3d78e2ea8d1' WHERE [ID] = 'territorio_data-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fe9a2f82d471d699959bbf91d11961bf' WHERE [ID] = 'territorio_data-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ed819677dd669ede1f38073211bc5a21' WHERE [ID] = 'territorio_data-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:df60bdb4d216d597bd905da4485aa2ad' WHERE [ID] = 'territorio_data-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b38f1c4c8f499d5f798e959cc5e7627b' WHERE [ID] = 'territorio_data-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c52294c9f612421c0fc66bc14fb9c956' WHERE [ID] = 'territorio_data-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:165b5ed5300f0364e99037603d195b00' WHERE [ID] = 'territorio_data-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f949a2af30a38ea0fc448b5cfe82e09f' WHERE [ID] = 'DATA-CORE-tag-1.0.1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1ee5fe055425e60003a0f98f0c4e0ead' WHERE [ID] = 'DSD_Tables-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b7d57e4e06cccce35542de4ce0b18d5' WHERE [ID] = 'DSD_Tables-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3f45b243d751468248b83b927f76b87a' WHERE [ID] = 'DSD_Tables-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ae7737c73810829c0003bda3fb79b9a1' WHERE [ID] = 'DSD_Tables-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:68a420bf442467a49133eff632b55fd7' WHERE [ID] = 'DSD_Tables-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a1bd32046c72f1517a51531add24a493' WHERE [ID] = 'DSD_Tables-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:102d3ebabce4637d5f8f5d9d297e67a7' WHERE [ID] = 'DSD_Tables-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:841bd08b39b8e8d934c040c9040ad991' WHERE [ID] = 'DSD_Tables-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:16a0a8aa7ab00b32e3dd117b988f66a9' WHERE [ID] = 'DSD_Tables-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cd54a5083a081e3030f2c79f655cda43' WHERE [ID] = 'DSD_Tables-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6812fb7adecb13206e08db144b5ee8f6' WHERE [ID] = 'DSD_Tables-11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3526f2b3760938e90ffca163e61ba5be' WHERE [ID] = 'DSD_Tables-12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:92090b8c5d459eb9b6f7c02f13c9f8e3' WHERE [ID] = 'DSD_Tables-13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:742f481ea9c18f9f812afc1b26d5bbdc' WHERE [ID] = 'DSD_Tables-14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c0dc9f4ae053860592ad95a7bf11bca7' WHERE [ID] = 'DSD_Tables-15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2cb54905633a411df635b69bd115afd2' WHERE [ID] = 'DSD_Tables-16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a65aa2b976d121400e7eb72fc8a12230' WHERE [ID] = 'DSD_Tables-17' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1991dbb5be3bf6a6fb2ed973fdeea158' WHERE [ID] = 'DSD_Tables-18' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bb4f45ca282dc1b3050d60b762d9d3ca' WHERE [ID] = 'DSD_Tables-19' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:86b17fa71eb7c3d3cab3b75331b1b220' WHERE [ID] = 'dsdDatos-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fa190ce11d65915155098ae2283d6a89' WHERE [ID] = 'dsdDatos-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5803fa8ab7c4b8d37b980ee08af91ccd' WHERE [ID] = 'dsdDatos-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d3883e5a2be5c9025ce7c707dd55d7e8' WHERE [ID] = 'dsdDatos-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:43245629a6bb49d702250dffc36f0681' WHERE [ID] = 'dsdDatos-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a17385b812b4eec36691ff761517ea0' WHERE [ID] = 'dsdDatos-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:54b38c99607de1d2388004a3c2e7c6bb' WHERE [ID] = 'TABLE-dsdDatos-1-tag-1.0.2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e5685f4ec490308877695c57fd3f8dd3' WHERE [ID] = 'table-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d7fe923c9d768f86d6a0187fe32e247' WHERE [ID] = 'PK-table-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b3b76691e1516ec4c31c243e8716f18' WHERE [ID] = 'Index-on-id-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6af91eaef29568c2e5dd2200262f55fe' WHERE [ID] = 'data-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3c9d75423dcefb5f40dd0886b1066474' WHERE [ID] = 'DATA-SUBVENCION-tag-1.1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f334338408df0e5f910127cac7f173fc' WHERE [ID] = 'data-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.02-EQUIPAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:10c09d49819760e13e95af97a3d117a1' WHERE [ID] = 'DATA-EQUIPAMIENTO-tag-1.02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.02-EQUIPAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d73febe0f09fa26618e4bfd04e1b617a' WHERE [ID] = 'table-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c1d7de402693e62fbd780560766d7fe' WHERE [ID] = 'PK-table-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:610fe113e456058d5d5676cf7e78f02a' WHERE [ID] = 'Index-agenda-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6800114a8e47593dca10ed512bdb3f43' WHERE [ID] = 'data-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ef1f9097da7e88e9fdfd110b58eb77e5' WHERE [ID] = 'DATA-AGENDA-tag-1.03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:81bb281e6a596117f7ef0b5213b18c31' WHERE [ID] = 'Tabla-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d4b7895859b9866f6c7c45f1219bf8de' WHERE [ID] = 'Tabla-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e6fb2557bfbf6c1fe666771a6e1fe1e9' WHERE [ID] = 'Tabla-local-comercial-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:80d3691d2a8c361f279a939aea90cbad' WHERE [ID] = 'tabla-local-comercial-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ba427ae5beef06794503073a3a835f1f' WHERE [ID] = 'pk-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6657a49580a89645f54239257875f13b' WHERE [ID] = 'pk-local-comercial-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:834900d6d4ca6e0f5d211e83f1e526bf' WHERE [ID] = 'pk-local-comercial-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:61d0249bdece35745f85bc36b6afc561' WHERE [ID] = 'pk-local-comercial-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:eeb0feff7faf9462006a18d1be86b61b' WHERE [ID] = 'index-id-on-local-comercial-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1fdfc867e10c928b5476f8524d95e5bf' WHERE [ID] = 'index-id-on-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f2cb7f3279991ad845a6af9a8434692a' WHERE [ID] = 'index-id-on-local-comercial-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6576e4fc437ef0a6f319c06dfc9b7b1b' WHERE [ID] = 'index-id-on-local-comercial-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f5e3310c93f3f44a27a7d1859aa961f3' WHERE [ID] = 'Datos-tabla-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:19e1c0eed092ad3aa27d6b82e28e1adb' WHERE [ID] = 'Datos-tabla-local-comercial-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0ef977c68ac114e51e1cdf776e7ac8c6' WHERE [ID] = 'Datos-tabla-local-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e63063faa8d6ea2609771875a2ea0c32' WHERE [ID] = 'Datos-tabla-local-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26d68f691d261f9ac8169e04cc10d800' WHERE [ID] = 'DATA-LOCALCOMERCIAL-tag-1.04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:536b96a62fc6f6e872115b2b9ddd93da' WHERE [ID] = 'data-equipamiento-punto-wifi' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.05-EQUIPAMIENTO-PUNTOWIFI-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c94c88a1d45b9101883b0ad3a25bd382' WHERE [ID] = 'DATA-EQUIPAMIENTO-PUNTO-WIFI-tag-1.05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.05-EQUIPAMIENTO-PUNTOWIFI-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b03f70f7b18f589e3d48c04318261d33' WHERE [ID] = 'data-equipamiento-aparcamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.06-EQUIPAMIENTO-APARCAMIENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dce8024a65fed855c0ba2797715f9ed5' WHERE [ID] = 'DATA-EQUIPAMIENTO-APARCAMIENTO-tag-1.06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.06-EQUIPAMIENTO-APARCAMIENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:11e66f35abdcf9f9006420de286d83e1' WHERE [ID] = 'data-equipamiento-instalaciones-deportivas' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.07-EQUIPAMIENTO-INSTAL-DEPORTIVAS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ff0f1614f516286bfd49eef15bf8093b' WHERE [ID] = 'DATA-EQUIPAMIENTO-INSTALACIONES-DEPORTIVAS-tag-1.07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.07-EQUIPAMIENTO-INSTAL-DEPORTIVAS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1269456364eaf42198b04396bd87a748' WHERE [ID] = 'table-aviso_queja_sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d64007ebd75da01b5c9b525fc2b68c30' WHERE [ID] = 'PK-table-aviso_queja_sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a6d1590717c0f84b7f3806f086ac704c' WHERE [ID] = 'Index-aviso_queja_sug-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0a811d1d8f0a0ce1b0f1aae481eb8da1' WHERE [ID] = 'data-aviso-queja-sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9ab4089fb176a2df9cf00cc49a2de7e4' WHERE [ID] = 'DATA-AVISO-QUEJA-SUG-tag-1.08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ac504f75a15bbb45ed30e3a1e50f1a53' WHERE [ID] = 'tabla-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6a4faa90075ae003011f3cc596329a49' WHERE [ID] = 'tabla-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:74fddda694c544bb9a1a70afc2433eff' WHERE [ID] = 'tabla-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6290c2f4bcd8fd89e09a8b2429712507' WHERE [ID] = 'PK-table-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4b5f13ab8c573e4dbc8560d58eb2c324' WHERE [ID] = 'PK-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3da69a34d17606d7fecb2ffe0a344662' WHERE [ID] = 'PK-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:127313673c18c0340b86f444a74c6927' WHERE [ID] = 'index-id-table-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4eec50a28e974a65813bda79b9c002f1' WHERE [ID] = 'index-id-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:053512f9ae2b82ae7d5d3f3070e6d28b' WHERE [ID] = 'index-id-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c2cf4cf570722401809657b20c25c057' WHERE [ID] = 'index-made-by-sensor-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bc1ace949eb665a295eced3516b7a013' WHERE [ID] = 'index-is_hosted_by-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c6e15fa0c1d6c19084e9fc8b91c00835' WHERE [ID] = 'data-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1a32ecec85c3f7ad3cb2605cb0dafd7f' WHERE [ID] = 'data-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:20d914740a09b39b7dbb029b98b2faf5' WHERE [ID] = 'data-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b84dcf622628d171750e4421405f5c58' WHERE [ID] = 'DATA-CALIDAD-AIRE-tag-1.09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:28b365eade44e169aebd1773d56d4b19' WHERE [ID] = 'table-organigrama' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f40597dc24112fbeaff92f3db27a070f' WHERE [ID] = 'PK-table-organigrama' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6a94e789c5d4601dfdb58bb80805721c' WHERE [ID] = 'Unique-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0142c1ba020173f5cd3f93d0a39d842e' WHERE [ID] = 'Index_unidad_raiz' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5926a732c91755efa216a0de9524ef2f' WHERE [ID] = 'Index_unit_of' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ab1a1fbf3c8cd1a084d88d4ec85abfa8' WHERE [ID] = 'data-organigrama' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:073d706d8d6fe12b0b2a377c0bd141ab' WHERE [ID] = 'DATA-ORGANIGRAMA-tag-1.10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7cd4b1312ac0705514934eb341f79b2a' WHERE [ID] = 'data-punto-interes-turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.11-PUNTO-INTERES-TURISTICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5e30253cf00736b1d22dc76e27b3f2a1' WHERE [ID] = 'DATA-PUNTO-INTERES-TURISTICO-tag-1.11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.11-PUNTO-INTERES-TURISTICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0d7b4cbdf27166d3d1931c51755c5ed9' WHERE [ID] = 'data-punto-interes-turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.12-MONUMENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:add34b971a32e69118b85a0b1914da81' WHERE [ID] = 'DATA-PUNTO-MONUMENTOS-tag-1.12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.12-MONUMENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:96595cd1a484685bcdbb5725afc19b4e' WHERE [ID] = 'table-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:875acd0bd9d7f575a34eadc61a4bf6c7' WHERE [ID] = 'PK-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:aacccdcff3d4f17dfb2b08fb22565999' WHERE [ID] = 'Index-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:469317830363ea41e8049519d9415494' WHERE [ID] = 'data-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:364f472b52b49f328b83858c6af92857' WHERE [ID] = 'DATA-ALOJAMIENTO-tag-1.13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0fb0301fba8779a2086511ebc922584f' WHERE [ID] = 'table-callejero_portal' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7f97bb945be3a8250acce91b2d51c55f' WHERE [ID] = 'table-callejero_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9e6ebcc263a1b0d9e0341ac77c524e74' WHERE [ID] = 'table-callejero_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:df31bfadc2ffa417fe53cf54ea13e55d' WHERE [ID] = 'PK-table-callejero_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a8328497e024e4b59aa17186a856d859' WHERE [ID] = 'Index-callejero_via-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f934e37ac50f6b22d20a3abd246bc756' WHERE [ID] = 'PK-table-callejero_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cbea775454d5a115198911ab5924be49' WHERE [ID] = 'Index-table-callejero_tramo_via-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d7073be5952b1ebb53f5c1e1a78e820' WHERE [ID] = 'Index-table-callejero_tramo_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5a68fa1b29a3219097670c3f51e069a8' WHERE [ID] = 'PK-table-callejero_portal' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e9add8a6330ed278179297d601095913' WHERE [ID] = 'Index-table-callejero_portal-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7e35e20e09e5a5ef3ae7d6a7aa3a619b' WHERE [ID] = 'Index-table-callejero_portal-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fa6566f01af63754622f7884074e0606' WHERE [ID] = 'datos-callejero-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:63fbd8187670f27cc9ea8ce3561fadfb' WHERE [ID] = 'datos-callejero-portal' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:928efb3421ddd31b68916ee460a68eb3' WHERE [ID] = 'datos-callejero-tramo-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c4e84fa48cbd45b82c70997b5c129583' WHERE [ID] = 'DATA-CALIDAD-AIRE-tag-1.14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ccb80c5629422a781d67cea6b6df0eb2' WHERE [ID] = 'table-tramite' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e5e12ec32286e215c964af004b6d7d9a' WHERE [ID] = 'PK-table-tramite' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:34051762bca0062942f221c896827768' WHERE [ID] = 'Index-table-tramite_portal-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:103b8092b2d08251d6fca8c6eb2d0346' WHERE [ID] = 'datos-tramite' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:45cdb6296b6a1bca9feb8674b16b9d4d' WHERE [ID] = 'TABLE-TRAMITE-tag-1.15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d7c94fc924fd09e0b6a89b2e144c9fc9' WHERE [ID] = 'Tabla-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c5613a9073c8b416a7e75f0d4c46c47c' WHERE [ID] = 'pk-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a99a00cd381df6d28282ade4b8839ba3' WHERE [ID] = 'index-id-on-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c95e6a1c3a32c712d4270faed5271036' WHERE [ID] = 'data-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ce22ff48a9fef39bb1c11b668c3c9b58' WHERE [ID] = 'DATA-PLANTILLA-tag-1.16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ba3e0b695b29bd8134f1bdbd8a4f7b4' WHERE [ID] = 'table_padron_cube1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3c11abb3da40a44cb96310401e9e5f03' WHERE [ID] = 'PK-table-padron_cube_edad_g_q' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f6c948e0b46847e387ffaeb611fdde2d' WHERE [ID] = 'INDEX-table-padron_cube_edad_g_q' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a99d5612282ffe4d5c798d1a9a7d1a9e' WHERE [ID] = 'table_padron_cube2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:aec18f3807ee8b1c9b03d91471bf77f5' WHERE [ID] = 'PK-table-padron_cube_estudios' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:844018616f66ef4fe62a2ab8899245b4' WHERE [ID] = 'INDEX-table-padron_cube_estudios' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dd90eef84ee62d5a98ecabd419b681bf' WHERE [ID] = 'table_padron_cube3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:45fd1107dccbc551020143306f5ce8fc' WHERE [ID] = 'PK-table-padron_cube_nacionalidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:81bb539e55f13b8807e2603c6072090d' WHERE [ID] = 'INDEX-table-padron_cube_nacionalidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:815bcd2a55d92ee63643ec6a3d589f6f' WHERE [ID] = 'table_padron_cube4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:439ddf5cc0a1a6030f6e47b6ec48f589' WHERE [ID] = 'PK-table-padron_cube_procedencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:888518384e289207ef2cda46fb368788' WHERE [ID] = 'INDEX-table-padron_cube_procedencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cceaf56510373e415278f5f09596a251' WHERE [ID] = 'table_padron_cube5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5f9976ff2559ee094158cace1293fa21' WHERE [ID] = 'PK-table-padron_cube_indicadores' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26a189c825b87c40e995f300297e9c47' WHERE [ID] = 'INDEX-table-padron_cube_indicadores' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b1426a972532f0c422fe57641a0da35b' WHERE [ID] = 'table_padron_cube6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:39fd68718b7c37b54c5b0f46db37ff06' WHERE [ID] = 'PK-table-padron_cube_edad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:140c9677a335866b5f7f633a89f9ed57' WHERE [ID] = 'INDEX-table-padron_cube_edad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:86a47a919bcd30ef2c082b84d2ed7d71' WHERE [ID] = 'table_padron_cube7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bbe5890fdb1548be66759e952f116af7' WHERE [ID] = 'PK-table-padron_cube_pais_n' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:eb83df13b9fae438621860c484f767a6' WHERE [ID] = 'INDEX-table-padron_cube_pais_n' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:238f72b3ca8d679fc3f43503d24731bc' WHERE [ID] = 'data-cube-padron1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c63919e44390504d7b313e47b69a6b75' WHERE [ID] = 'data-cube-padron2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a27f4fe7e4600ec99e266cbd0b3c7e06' WHERE [ID] = 'data-cube-padron3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26208dc33dcdd3c1a12606c236648dd0' WHERE [ID] = 'data-cube-padron4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ee8219b33950d77ef1535c3dfcfbc416' WHERE [ID] = 'data-cube-padron5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a11fc5e681015fac4039a42cb749e349' WHERE [ID] = 'data-cube-padro6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c3d4cbdf322a9600ececfd7fe190ac43' WHERE [ID] = 'data-cube-padron7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:67e609eff096c78328916aa9760fc2c3' WHERE [ID] = 'TablesPadron-tag-1.17' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:57e91edafca6b5e288cdc5fb4394cccf' WHERE [ID] = 'integraciones-entre-modelos-addColumn' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2956f148f9700308d1be6daf8d571060' WHERE [ID] = 'update-example' AND [AUTHOR] = 'liquibase-docs' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2956f148f9700308d1be6daf8d571060' WHERE [ID] = 'sql-update-alojamiento' AND [AUTHOR] = 'liquibase-docs' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:37f6b74c552cb1dc284dad95e2d45905' WHERE [ID] = 'sql-update-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9ec1e9d0d6ac4dc1bf079d119732884c' WHERE [ID] = 'sql-update-aviso_queja_sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b0e3d56d739c943eb6e6c4eb31e812f' WHERE [ID] = 'sql-update-calidad_aire_estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bbf5441d3a7fc9aab283cd8facecd183' WHERE [ID] = 'sql-update-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a9bf565f82074e379159effd6dd70a6' WHERE [ID] = 'sql-update-local_comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:03ee908b581e925c19079c66ab3755ab' WHERE [ID] = 'sql-update-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4410b7f23e7759b13d8f98f86fa89fde' WHERE [ID] = 'addColumn-portal_id-tag-1.18' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d3d0335a1843424f8a20db8b4e4003d0' WHERE [ID] = 'table-agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7b3b819e8749cd61e49a917251d1d713' WHERE [ID] = 'table-agenda_m_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:27894f40c334688d8a41849503d56d79' WHERE [ID] = 'table-agenda_m_rolintegranteevento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:71effd5cccdc0144cbee5dfac0d7e9a0' WHERE [ID] = 'PK-table-agenda_m_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1a2ad34118fde402d7bd94afa8d75d6b' WHERE [ID] = 'PK-table-agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b34bccb646a0676d2d475f01cbf4d0cf' WHERE [ID] = 'PK-table-agenda_m_rolintegranteevento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8a538ce331610a1eb94e5e5cbf7e4193' WHERE [ID] = 'INDEX-table-agenda_m_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d0092fe8ed1f90654e99cded50df0ab8' WHERE [ID] = 'INDEX-table-agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9f358ca892fcd5598f2ba8cb140fe686' WHERE [ID] = 'INDEX-table-agenda_m_rolintegranteevento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:61d65656500be3978521feb066857823' WHERE [ID] = 'INDEX-table-agenda_m_documentacion_event' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8958871b98221654eda626321e82ac61' WHERE [ID] = 'INDEX-table-agenda_m_rol_i_evento_event' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0f9a67227dae95247e3d702cac6785a5' WHERE [ID] = 'INDEX-table-index_super_event_id_agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bfcc76b591b3af87f6fc68de7fb264fe' WHERE [ID] = 'data-agenda_municipal_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:439d27a51cfdab1c9c87beff9d5b6678' WHERE [ID] = 'data-agenda_municipal_documento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:daa49e58ec1c17a62fcb27b74cae9d3a' WHERE [ID] = 'data-agenda_municipal_rol' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ebc966c2cc2c3b8a08f38f55bfca61c7' WHERE [ID] = 'DATA-AGENDA-MUNICIPAL-tag-1.19' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7f31069289254bf70d989162b5ddecb2' WHERE [ID] = 'tabla-contratos_award' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:18cbb58f2f0328a0e7f50a6359309604' WHERE [ID] = 'tabla-contratos_item' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4be17f070d515aa91970a819bb5de331' WHERE [ID] = 'tabla-contratos_lot' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7b0f709401a232eff7ff8d4614a74432' WHERE [ID] = 'tabla-contratos_lot_rel_item' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:790b8b409f6c0de43756163b15e42584' WHERE [ID] = 'tabla-contratos_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:394818e25b678b576c97888bb34190b4' WHERE [ID] = 'tabla-contratos_process' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a71e51bf321cc2a4b96715b270b23214' WHERE [ID] = 'tabla-contratos_tender' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3ebf5e7ba4dcd259c4ebad51d87c34e4' WHERE [ID] = 'tabla-contratos_tender_rel_item' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:13b8d0945de9e7bba51b693d71f99363' WHERE [ID] = 'pk-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7632b0f4b6c539e0942ac14ede186e61' WHERE [ID] = 'pk-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3cafa3c91d3b3d660ac9d6af1bdd992d' WHERE [ID] = 'pk-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3c3a2424dd6b07a93c0c195e032f568c' WHERE [ID] = 'pk-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:086f8d2587beee49d61ec43cb08829f1' WHERE [ID] = 'pk-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f79871a3435076b63f82bfd6ff250770' WHERE [ID] = 'pk-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:194d9fe065d1d77fb94ea156903d8b3a' WHERE [ID] = 'pk-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:48ddec26ddbf7346b9c7e8c703f80854' WHERE [ID] = 'pk-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f2d45430d1ba8dc13644c55503026514' WHERE [ID] = 'index-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b52e7533dfafe9b637ff80607550aecc' WHERE [ID] = 'index-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8535ae5e2360ee678c0859829559e048' WHERE [ID] = 'index-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:28a8b89135777ae66d0c3db9eef02279' WHERE [ID] = 'index-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a5e600936ef0c6e353f12391309774fe' WHERE [ID] = 'index-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6dae2dd40fb757660182885fc43d0b02' WHERE [ID] = 'index-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:af93c83dcb8d0c25bf4d6f2a196369fb' WHERE [ID] = 'index-extra-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1f821d39f3b4d4e88cff1183b9425c5f' WHERE [ID] = 'index-extra-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:324b4049c78a73581957c4898e97f46f' WHERE [ID] = 'index-extra-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:16ea636f90a06fb61d067276f21cac10' WHERE [ID] = 'index-extra-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4a421be912ebc4f12bac271aa73654c0' WHERE [ID] = 'index-extra-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b010fd8b7682958f803891cabf6097a' WHERE [ID] = 'index-extra-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:42fb7580cba2277603da453a582848af' WHERE [ID] = 'index-extra-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e893c62d47d225f016d9f9a0a711d8f2' WHERE [ID] = 'index-extra-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:643e3595c24515d1635c20eb8ac80de2' WHERE [ID] = 'index-extra-09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9eefedc8612b068ace4bedbd0db7eb6c' WHERE [ID] = 'index-extra-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0b7d5a2e3d2adbd0ba46c90314b9bcc6' WHERE [ID] = 'datos-award-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4d4a032e8fa49226d022147de7679a39' WHERE [ID] = 'datos-item-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d042b4484feb2b181800692066dd194b' WHERE [ID] = 'datos-lot-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:17b785887ef42845a0b2243c319a206b' WHERE [ID] = 'datos-lot-rel-item-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:14832048085ad42759029650567a7ba8' WHERE [ID] = 'datos-organization-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7007c15389c3e92c0a50af0515dbadd0' WHERE [ID] = 'datos-process-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:243ae65019576547a32157731faf0688' WHERE [ID] = 'datos-tender-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5d50f0657ec3fc0805ebb281534454fd' WHERE [ID] = 'datos-tender-rel-item-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bb7bf2689ec786f5bf92377f9e7b4438' WHERE [ID] = 'DATA-CONTRATOS-tag-1.20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d88b5f371f951a8e156550932ccd6bea' WHERE [ID] = 'table-bici_bicicleta' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e1682b260d68fa1dd8188b28f1848e93' WHERE [ID] = 'table-bici_estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7727189e8aa2ab7f6dac6438022d4972' WHERE [ID] = 'table-bici_anclaje' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0fede01a7f67325dcd405675866b1c71' WHERE [ID] = 'table-bici_usuario' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7110ff0a116ef4460404f238c9d1c8d6' WHERE [ID] = 'table-bici_trayecto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e2023c80ae8717097132107dae8a69f7' WHERE [ID] = 'table-bici_punto_paso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b91426017547f86ca40e5a2a933c2889' WHERE [ID] = 'table-bici_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:599327cc3995800b94633db922bd58ea' WHERE [ID] = 'pk-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6a342facc98e237da9a1fa23359f159c' WHERE [ID] = 'pk-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7950d9cc6bb26fb3fb19a6e4e87e388d' WHERE [ID] = 'pk-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8c5715734c7aab422a342bddd92dd423' WHERE [ID] = 'pk-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2209d37e51727d48efd0dd83de29f960' WHERE [ID] = 'pk-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e774e482191a8ee635ff3edad649a925' WHERE [ID] = 'pk-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:47acedcc1c8c6563244067a5e2a9503b' WHERE [ID] = 'pk-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:153d0cbbe252924c94107495dc607a45' WHERE [ID] = 'index-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7fcabab133a1708e69ea16f930aa2d25' WHERE [ID] = 'index-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3d674d34eaedab7357ea667441e7a783' WHERE [ID] = 'index-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:142558cf5ed6f53ced425215e67b4cfc' WHERE [ID] = 'index-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bd77b4128518902ce50acf55a7c699c4' WHERE [ID] = 'index-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b2ed880cf562a1e2fa7b0ae3a8cff960' WHERE [ID] = 'index-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2418dafe7d7c8d014f13e99b407dbd73' WHERE [ID] = 'index-id-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b9aac3bd4b3606317ad5f998391b9384' WHERE [ID] = 'data-bici_bicicleta' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ccb38677090c8d7dc83186db08a83682' WHERE [ID] = 'data-bici_estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:95318554c3de9e0f9a80dd9d94d30023' WHERE [ID] = 'data-bici_anclaje' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:02f7d8375a42cfd306f4bea73f251a8e' WHERE [ID] = 'data-bici_usuario' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0e5f39218e5f8ecc11717ae0171520fb' WHERE [ID] = 'data-bici_trayecto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5df79ab910b70df38624953c4ee3aab4' WHERE [ID] = 'data-bici_punto_paso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:91a8802966bfc9b7459924bdf49f2cf3' WHERE [ID] = 'data-bici_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dea3d4b6e323a2d3be72f101990e30d4' WHERE [ID] = 'DATA-ORGANIGRAMA-tag-1.21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:33d7d1b7844888812b76d0b03edeefb8' WHERE [ID] = 'table-convenio' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c4f504ddc5022b5d3a73a30f061e55e5' WHERE [ID] = 'table-convenio_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1eb31fccb5714ba9f21ae4b0004abf66' WHERE [ID] = 'table-convenio_susc_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3e6b4cf1616ba99264cdc0dc7ed2c0af' WHERE [ID] = 'table-convenio_rel_firmante_ayto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:10195803476de7715b7fd1aedf9a40a4' WHERE [ID] = 'table-convenio_rel_firmante_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b3d93815b7216be1563a4cbd7febf0d7' WHERE [ID] = 'tabla-convenio_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a2f5f4ce7b85da592eefedc0d814e96' WHERE [ID] = 'PK-table-convenio' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8f6ee774ea524f50e6b40aeb0c764c7e' WHERE [ID] = 'PK-table-convenio_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a48f03ecb258f6bcc18c7062d3743c59' WHERE [ID] = 'PK-table-convenio_susc_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9be2899f759df34b7ba17e554e6e8162' WHERE [ID] = 'PK-table-conv_rel_firmante_ayto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:50abb8cf0f7d7addf22cd8d18605a9eb' WHERE [ID] = 'PK-table-conv_rel_firmante_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:42a4024b689881a7b32b9ce4bc2fb2fe' WHERE [ID] = 'PK-table-convenio_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cfb067b32518f75d2f31788b587f3738' WHERE [ID] = 'unique-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:42fd3cda2259175d949ade5f37e87add' WHERE [ID] = 'unique-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c6c0252746dea2c743c59c9109fab6a0' WHERE [ID] = 'unique-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:23ad4c146255c4481c0a2ecaf62ef4fb' WHERE [ID] = 'unique-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fcbbc74e15f2fa5ecc816b857c71400a' WHERE [ID] = 'unique-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:681e695380ffe9f72b4858e793aa5a05' WHERE [ID] = 'unique-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a398b2832454c9d7f4ab896b1467ec78' WHERE [ID] = 'INDEX-convenio-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7cd05647f10ebe0c0fbfd788a8a98e49' WHERE [ID] = 'INDEX-convenio-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cacd89c29c2856e042d96c0250709d21' WHERE [ID] = 'INDEX-convenio-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fdd6cd5084631cc4f12b3949ab1b523f' WHERE [ID] = 'INDEX-convenio-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:87b1482711d1a03ede1aba34d52e22a8' WHERE [ID] = 'INDEX-convenio-16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5fa28f06b68ce5be7402d60f82f3e178' WHERE [ID] = 'INDEX-convenio-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7bfa4983508754c89f53e450dd066e30' WHERE [ID] = 'INDEX-convenio-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d4faf5ee40e579ea895547bef32950f1' WHERE [ID] = 'INDEX-convenio-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d27b6d7031df0519df383ed62ce73db0' WHERE [ID] = 'INDEX-convenio-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:682068a4d9e1f5497615b908410284eb' WHERE [ID] = 'INDEX-convenio-11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:164718261930aa8c9f152506fd16f3e6' WHERE [ID] = 'INDEX-convenio-12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c8d4a0cc734861aae73f7019307d87d6' WHERE [ID] = 'INDEX-convenio-13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6134d1fca0dc8512b84837f8ae64f5d0' WHERE [ID] = 'INDEX-convenio-14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:181a3163f4acdfc1dc860ab895a6f83a' WHERE [ID] = 'INDEX-convenio-15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b7f36b5fce8d005ef0fda63acdff8188' WHERE [ID] = 'data-convenio' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:60465b4bc045901b030de5d170c65308' WHERE [ID] = 'data-convenio_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4a2abc8ccbabe9d4a81abb54aa0b04dd' WHERE [ID] = 'data-convenio_susc_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:261f2989c04f40f56bcc35dc574f21b8' WHERE [ID] = 'data-conv_rel_firmante_ayto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d4ef274285690a807198e0fe1758d4a' WHERE [ID] = 'data-conv_rel_firmante_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1fb1fd370977403166176af209664c9b' WHERE [ID] = 'datos-convenio_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d2f9947790497dbd7e09de1df5751b34' WHERE [ID] = 'DATA-CONVENIO-tag-1.22' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5a70847b6e6e5a14a2f5c4bcce0b3b4f' WHERE [ID] = 'table-presupuesto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9ef97309ae3f96ba971816054eaac28e' WHERE [ID] = 'table-presupuesto_liquidacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6e46992a812f463d9e53dcbeb7dd2b77' WHERE [ID] = 'table-presupuesto_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cec9ac4641833e6ba2d0acb98413b907' WHERE [ID] = 'table-presupuesto_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:11d73e59b6d9004621e726080352ca93' WHERE [ID] = 'table-presupuesto_ejecucion_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4e4200904f3864c3587b06f60540d2f9' WHERE [ID] = 'table-presupuesto_ejecucion_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e93fb503c7a44519844a375e624787cb' WHERE [ID] = 'PK-table-presupuesto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:46c2762a82935660a86f2c2928afd0f4' WHERE [ID] = 'PK-table-presupuesto_liquidacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dad239fd939369c519d45f5009b91151' WHERE [ID] = 'PK-table-presupuesto_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:10a508b99e0297174f4367bd595cb792' WHERE [ID] = 'PK-table-presupuesto_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5dbd74c2e01a26c8bc8142453fa8a8dc' WHERE [ID] = 'PK-table-presupuesto_ejecucion_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6e9d1f4213977dd3ddf00119995ffd92' WHERE [ID] = 'PK-table-presupuesto_ejecucion_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f2cdbb642a3ff896b1cd93fd861872ba' WHERE [ID] = 'unique-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3ac3af4143a22964ca90c0ed0a816b8c' WHERE [ID] = 'unique-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:763b77459b0d856adba15316c92fa9a3' WHERE [ID] = 'unique-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b799363fa56bc9c6a11834162ff6d991' WHERE [ID] = 'unique-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5464cb77c400cd6f8d1d353858a9e577' WHERE [ID] = 'unique-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8426e1b4e1920302a6d4a996eba579aa' WHERE [ID] = 'unique-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6ee972624113f1de05ee00d523f8b0ea' WHERE [ID] = 'INDEX-presupuesto-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d0f7017e66ec43eff9e20197eb5978be' WHERE [ID] = 'INDEX-presupuesto-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b20eee4a14850a49c173ef662678cbd5' WHERE [ID] = 'INDEX-presupuesto-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:715ec0b89635b2c0cff27ba80e7eff25' WHERE [ID] = 'INDEX-presupuesto-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c6c515535b68b4575955509f4c867d44' WHERE [ID] = 'INDEX-presupuesto-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ecffce130b2b2a8d720604265535cb06' WHERE [ID] = 'data-presupuesto_liquidacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b0cdef79776d19443a8471d99a40447' WHERE [ID] = 'data-presupuesto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:78c9571c2cd09a318f7c3e6592d21b75' WHERE [ID] = 'presupuesto-pres_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7f0fb9080cc98e9c0fd556affd0592ee' WHERE [ID] = 'presupuesto-pres_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8ddd3a6e138a012de7687c48e100e857' WHERE [ID] = 'presupuesto-ejec_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a3b4e9088b0b62a02a107c0fbef280b' WHERE [ID] = 'presupuesto-ejec_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4d5397b9d366725d955af3b84cbf5a16' WHERE [ID] = 'DATA-CONVENIO-tag-1.23' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:20ee9f1e2a5797bf226dc7be382cfdbf' WHERE [ID] = 'table-trafico_dispositivo_medicion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8f4d3243dcd82b6dba9bd92c06c40da8' WHERE [ID] = 'table-trafico_incidencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:153ff2c977073c9936ee4de56e15eda3' WHERE [ID] = 'table-trafico_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b28742da7b0bc37f771ff182225283e' WHERE [ID] = 'table-trafico_observacion_dispostivo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9f65a9f4c3f82863fc905412d55ba532' WHERE [ID] = 'table-trafico_tramo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bfad8147c02d6029b19e6c3efc28b4d4' WHERE [ID] = 'table-trafico_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a6301aa724258852b121044e2a284599' WHERE [ID] = 'PK-table-trafico_dispositivo_medicion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:52e802f8d9670a11538fae12f21fc231' WHERE [ID] = 'PK-table-trafico_incidencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8cdbde3bdb7a31361be9e0111fcd4dcf' WHERE [ID] = 'PK-table-trafico_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a2899200709e8f2d11e4c788f627854f' WHERE [ID] = 'PK-table-trafico_observacion_dispostivo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:61a559c1bcdc6cb4aaf8619bd051c046' WHERE [ID] = 'PK-table-trafico_tramo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:35db62c26253b46a0d89bd8512f41b05' WHERE [ID] = 'PK-table-trafico_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:933cdb85dac550354ee3d64a556419b0' WHERE [ID] = 'unique-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b3607735bfb34cb974f62b4a9172fe76' WHERE [ID] = 'unique-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b3fb6365f231cb8daac67d8b7996fe1e' WHERE [ID] = 'unique-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3e13dcd6d8ec33d13bbda8e3152a8c35' WHERE [ID] = 'unique-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:45fc4c7182f1a1a4e600bb1d420519bd' WHERE [ID] = 'unique-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:96ae3bdb82c5ede9b60c11ce692436a1' WHERE [ID] = 'unique-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:71e866e68caa2c8777417663b80de969' WHERE [ID] = 'INDEX-trafico-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6b03ed7c7f1ab392870bd7a7fbc08019' WHERE [ID] = 'INDEX-trafico-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b380e5384b6f1fd8ce51a1610e59c192' WHERE [ID] = 'INDEX-trafico-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:68efb73cd5bf848f816de8d9fcf8d0b2' WHERE [ID] = 'INDEX-trafico-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9be8148ead54249ae7b31de0d6ec3dc9' WHERE [ID] = 'INDEX-trafico-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e506eaa1e031482e2a4e125e711fc741' WHERE [ID] = 'INDEX-trafico-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3292e7c7d0b859292ae62c2196c3b475' WHERE [ID] = 'data-trafico_dispositivo_medicion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ddadef23b3443d322d7c06516cb701df' WHERE [ID] = 'data-trafico_incidencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7248755b19075b5aac8c710ec88eb395' WHERE [ID] = 'data-trafico_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5cacfe9350a8517051b04cf2fa84380f' WHERE [ID] = 'data-trafico_observacion_dispostivo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ef24c609eb6b0ad672549692351462ca' WHERE [ID] = 'data-trafico_tramo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d6c52c60f14123bb59face5a7ba22449' WHERE [ID] = 'data-trafico_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4c263b7c16889b04cd18eb319fc0c9fb' WHERE [ID] = 'DATA-TRAFICO-tag-1.24' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:79b2b40cbcba5bf17ec1fb27f3024987' WHERE [ID] = 'mod-1-tra_obs' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2c8017f08ac6f13007ca3caf82d9384e' WHERE [ID] = 'mod-2-tra_obs' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e3f42ee941b3fabf08644a78092928e1' WHERE [ID] = 'mod-3-tra_obs' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:29738e8ccc6832536a402495ef4c0f0d' WHERE [ID] = 'mod-4-tra_obs' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:617a4771e37f8e0fbce4718c125ae121' WHERE [ID] = 'mod-tra_obs_disp' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f8f84127ec8a5917e7d7abbfca1ba4c4' WHERE [ID] = 'table-tra_equipo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:596055a6a242146bf1c3c15eb5d620d5' WHERE [ID] = 'table-tra_propiedad_med' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:92be9918b1a699e4fb3815d5b1638baa' WHERE [ID] = 'table-tra_prop_inte' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5802879aafe988aa1a70c4ff7da48aa1' WHERE [ID] = 'mod-2-tra_inc' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cebed69c58779f606d9629fcf48ffde6' WHERE [ID] = 'mod-3-tra_inc' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e6e7a667d03a74bf9eeb62e34671fbce' WHERE [ID] = 'inte_terr_dispo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0289ac285636d9fff8bc9591451c8c85' WHERE [ID] = 'inte_terr_inci' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:603eae52087fb9f2350c5f4e3f4876a3' WHERE [ID] = 'inte_terr_tramo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:74f55cf59fc4e070d3fda809eaa65aad' WHERE [ID] = 'inte_terr_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f5daaefd9679a28419717229ccbff1b0' WHERE [ID] = 'bor-tra_obs' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e29ec2be3cb34bd9450b99e9edbf7d6e' WHERE [ID] = 'mod-5-tra_obs' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a794fc6ba62d402f6f80bd817596d1b' WHERE [ID] = 'bor-tra_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:99d59158886b1c46d958246744a32c9a' WHERE [ID] = 'mod-3-tra_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7975711492b37cf7ab5aded69ff5354b' WHERE [ID] = 'bor-tra_disp_med' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:51d62d9570d56241b5e0cb8ecfb83404' WHERE [ID] = 'mod-tra_disp_med' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d3eb70e607ceca12547971f435265fed' WHERE [ID] = 'data-trafico_equipo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:863be3429a6529a1b6cc6dc85e477bd4' WHERE [ID] = 'PK-table-trafico_equipo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:70102c5cafd5463800d579ccac19bf73' WHERE [ID] = 'unique-id-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b771a4db81e9c07f7803833556544e5d' WHERE [ID] = 'INDEX-trafico-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:83b0d8fab7f108773f07ba8e2374663b' WHERE [ID] = 'fk-trafico-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:506d2c630af0b8dba8cfd9d742148ffb' WHERE [ID] = 'data-tra_propiedad_med' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:91704d1377775688a5e11533477157ba' WHERE [ID] = 'PK-table-tra_propiedad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:671e4e66f2dec79eb1c93334d67c3781' WHERE [ID] = 'unique-id-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4822b25f6ece41a8636394ff78215e2b' WHERE [ID] = 'data-tra_prop_inte' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6112d8d15bdfd89fd2276a5c9fed47fb' WHERE [ID] = 'PK-table-tra_prop_inte' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f15c6f9a194b1f9b5d61a4d58aff1af1' WHERE [ID] = 'unique-id-09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:67fb4cd75e6eeec12733b4653623eddf' WHERE [ID] = 'data-inci_terri' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:71e374858c1cf1bb7ba39faafa78732b' WHERE [ID] = 'data-tramo_terri' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0a699f63d6cba4a25754cacd222bc3b8' WHERE [ID] = 'DATA-TRAFICO-tag-1.24.1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:53242cb534fb4e146ea9b8f79197e293' WHERE [ID] = 'table-cont_acus_estacion_medida' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:389aa76b79c4b88da3a8ddf577839eae' WHERE [ID] = 'table-cont_acus_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:00f0adf469fb93c7405af8175e01818d' WHERE [ID] = 'table-cont_acus_propiedad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7b76d0dad44261faa12235026f738447' WHERE [ID] = 'PK-table-cont_acus_estacion_medida' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4e21f4b7cab435aa0538d6b01a1a017d' WHERE [ID] = 'PK-table-cont_acus_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f1cc8ee512ce6cafcd9fc88f69bdc686' WHERE [ID] = 'PK-table-cont_acus_propiedad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6f326fb8f1b1cf39f50da561f5796ebb' WHERE [ID] = 'unique-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4e647c3579fd75ebc4648a04ea795a3a' WHERE [ID] = 'unique-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:590df6dfdd690d2fed305c502ec2abcf' WHERE [ID] = 'unique-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c05f9461439406f3e24d3e1a0bb6486a' WHERE [ID] = 'INDEX-contaminacion-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6b3a63e1ab0a8fbdc17dd8598e5edd23' WHERE [ID] = 'INDEX-contaminacion-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:51f141adefe8b49cfbaf08f98896dfc1' WHERE [ID] = 'data-cont_acus_estacion_medida' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ae7a0f81d99b376a723664a1795bfb87' WHERE [ID] = 'data-cont_acus_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4d66820ecf153537e8511ece176d80dc' WHERE [ID] = 'data-cont_acus_propiedad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:95e43b2b39432caaf2b329da8b0ca822' WHERE [ID] = 'DATA-CONT_ACUSTICA-tag-1.25' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f9184e4509e7801abb84f47e273f4116' WHERE [ID] = 'bici_estacion_table_2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5683a84f6e5e8cfb2511c8e42be79052' WHERE [ID] = 'bici_punto_paso_table_2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0de7eb652bb8ae893acc9632f4405905' WHERE [ID] = 'bici_estacion_data_1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d514611a432740263bc806133cbf34f0' WHERE [ID] = 'bici_estacion_data_2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:93406f320aeb9248e9542a5b833d2fce' WHERE [ID] = 'bici_punto_paso_data_1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3dcd6657a88bc39d7bac2da472be54f8' WHERE [ID] = 'bici_punto_paso_data_2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b6989454c74b80ab03c10d10417144a8' WHERE [ID] = 'DATA-ORGANIGRAMA-tag-1.98.1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ecf08d83bed863aed57e49364d7cb23e' WHERE [ID] = 'FK-agrupacion_comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f40d67b5f7f63cf8bdc3847c5122051e' WHERE [ID] = 'FK-tiene_terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:15683817f79d73268482b34b13cc31fc' WHERE [ID] = 'FK-tiene_licencia_apertura' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:be8d7e6e7bbbdb469265c8faac4335c1' WHERE [ID] = 'FK-made-by-sensor-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c665b65078dde4c75d1555164717c771' WHERE [ID] = 'FK-made-by-sensor-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b481b7381c5d9707290dc07aa22cccfb' WHERE [ID] = 'FK-UNIDAD-RAIZ' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:245b341c9fa1a8b5fbd8321d25262151' WHERE [ID] = 'FK-UNIT-Of' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ef681e174646c53b771b5e356c83c459' WHERE [ID] = 'FK-Index-table-callejero_tramo_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1aa1af180196093a47ae9b7f9cbb5a06' WHERE [ID] = 'FK-Index-table-portal_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:71b016597c44ff71e9c125be2be1dadb' WHERE [ID] = 'FK-documento-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1159d22a81998f6fbc4770f4c7166e04' WHERE [ID] = 'FK-rolEvento-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a1323ec77a041c4e72259e2582edd73d' WHERE [ID] = 'FK-eveto-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8e709547aeb2009b439922f246f1b506' WHERE [ID] = 'fk-con-33' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e7e023fdd55f34bb5f1b4d308757652a' WHERE [ID] = 'fk-con-34' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6bafd84560a77e7d3634cf71b42bc49c' WHERE [ID] = 'fk-con-35' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9fda8dbb3ad43161c3169483fe95e5d0' WHERE [ID] = 'fk-con-36' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:97b7828df064323c492aeee2d514dd82' WHERE [ID] = 'fk-con-37' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4959bd937415c79971966e890381124c' WHERE [ID] = 'fk-con-38' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:34e2b7c6b8187843857238f35a9d4b39' WHERE [ID] = 'fk-con-39' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6c293557a276c19d7b9df8bb59c9ce84' WHERE [ID] = 'fk-con-40' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:df697caf25c3802fa9e895ec23a8dc62' WHERE [ID] = 'fk-con-41' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6e1f223eded203448b0886ac77de5bc3' WHERE [ID] = 'fk-con-42' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:006da3ca9143796bbca437279710342e' WHERE [ID] = 'DSD_Tables-20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:446a9c2b1733811cbdd76d841db7fbea' WHERE [ID] = 'DSD_Tables-21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:06d8158696ea74b0d02ba83b2114e5e9' WHERE [ID] = 'DSD_Tables-22' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f79e77fc8ebdab233ed4d0b08d9564e8' WHERE [ID] = 'DSD_Tables-23' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fad3832a6e2b68ee36488a1ea1421928' WHERE [ID] = 'DSD_Tables-24' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:25938f44c39ab00e358fef8d0cd37ca7' WHERE [ID] = 'TablasTerritorio-42' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c2fdc3ccb37477017ace3d0dedf40507' WHERE [ID] = 'TablasTerritorio-43' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fd7ed26ffbd2d49ff6e78b1ee9a4635e' WHERE [ID] = 'TablasTerritorio-44' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7beb3305830d2586b87a1b75a4c26539' WHERE [ID] = 'TablasTerritorio-45' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d9556cfd972c80b03dabae4557cd3c8f' WHERE [ID] = 'TablasTerritorio-46' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5351d8a537e2899d70e454e46a3aa514' WHERE [ID] = 'TablasTerritorio-47' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2ae8f1a6fcb266bb13721389372ad566' WHERE [ID] = 'TablasTerritorio-48' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b6632b17913e4074a36a859be33ae7d' WHERE [ID] = 'TablasTerritorio-49' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c997e9f709fb28463fc47f9a474c45df' WHERE [ID] = 'TablasTerritorio-50' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:739b5ad40d4cf32c0b7bb02f4826f7f6' WHERE [ID] = 'TablasTerritorio-51' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ea7d3f2ea76f5cce7a9967850f9d45c' WHERE [ID] = 'TablasTerritorio-52' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ca6f03e5e55024c2500c2d5ce00f1147' WHERE [ID] = 'TablasTerritorio-53' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:edb5699fb673140d15ee0860a78be7db' WHERE [ID] = 'TablasTerritorio-54' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0e686c2dcbb45d2d0ca68b0d8afc4b00' WHERE [ID] = 'TablasTerritorio-55' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ba49ecaa43a8bc34c2113f7b1147458e' WHERE [ID] = 'TablasTerritorio-56' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6fb1150ea9182e1bcc06850b574623b3' WHERE [ID] = 'TablasTerritorio-57' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4ceca60fdce40e0b8abaf6f3a0b1d77d' WHERE [ID] = 'TablasTerritorio-58' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d1433cdae4ffb93e206ebd489153c8d5' WHERE [ID] = 'TablasTerritorio-59' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f52856b73874c8ff66b70f5f49b58bf2' WHERE [ID] = 'TablasTerritorio-60' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9f698b3e1da0ef17d20de77596dcad10' WHERE [ID] = 'TablasTerritorio-61' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7efba45c780332dff2987f7a6e955001' WHERE [ID] = 'fk-bicicleta-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a71c590bcc12d8c5cd7f2d0eb7a8242a' WHERE [ID] = 'fk-bicicleta-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:250c7ef618e3deff314b94ba98cfadaf' WHERE [ID] = 'fk-bicicleta-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d285abad83b28eca286f8dc956216c15' WHERE [ID] = 'fk-bicicleta-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e4636e13e1f82ee88d6b27be872f9fae' WHERE [ID] = 'fk-bicicleta-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:acc44c55d6586bb872ce4e522277473f' WHERE [ID] = 'fk-bicicleta-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b3385ca302afcadc9468ec15ff835dd' WHERE [ID] = 'fk-bicicleta-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d6d96fb8109a6fc0c820455bec28e004' WHERE [ID] = 'fk-bicicleta-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a55bc8011283402a86d05a172b37d5f1' WHERE [ID] = 'fk-bicicleta-09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ce21375ee8bb8916595521cf704dab5c' WHERE [ID] = 'fk-convenio-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6f30e305a2bdb6f5e9ffb5ab66fb1f90' WHERE [ID] = 'fk-convenio-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:234f54bd2cb98f39dc4290288edbfaba' WHERE [ID] = 'fk-convenio-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8932ffa9237dd68e146426c9bc466ad4' WHERE [ID] = 'fk-convenio-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2bac324a501d8b4e1261b5cd1f10b09d' WHERE [ID] = 'fk-convenio-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:60fe7cb89708349809ad32897f228966' WHERE [ID] = 'fk-convenio-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ed21230355f258c48f830784ae1f8b78' WHERE [ID] = 'fk-convenio-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d5fa3e3665436958e4c2fbb78969cbfc' WHERE [ID] = 'fk-convenio-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:66102e756b18c44b86addfb06c64dcf0' WHERE [ID] = 'fk-convenio-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7f0d6ab2d96d05bfcc11297683697ca4' WHERE [ID] = 'fk-convenio-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4494ae6017a41da56b2c78742ba5d7f9' WHERE [ID] = 'fk-presupuesto-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9fa3f1a657fbd8bc203e1c5b9f67c10c' WHERE [ID] = 'fk-presupuesto-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3d5b47a4abf3ee9c44fe1ea5e9804af4' WHERE [ID] = 'fk-presupuesto-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:222e1a8029197b5327fdb893d54a92e2' WHERE [ID] = 'fk-presupuesto-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4c18ff3fbade86cf97feb350cd404e91' WHERE [ID] = 'fk-presupuesto-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7a1cb913eb2e9451a5cb784f5bf7c579' WHERE [ID] = 'fk-trafico-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:df7f18d125f6c67160a5ec7e5d98769a' WHERE [ID] = 'fk-trafico-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:660a13feb5e688cf2df5a60f61da5e83' WHERE [ID] = 'fk-trafico-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4a4e8ce3f6467ff01f38c626ebf57a5b' WHERE [ID] = 'fk-trafico-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a5a54b43c37ff3a5074afaa74a77735d' WHERE [ID] = 'fk-trafico-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0cbadb331a2aab2199f8f54e1573a0f0' WHERE [ID] = 'fk-trafico-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1ae48e8d650a03dedc110baadd43f819' WHERE [ID] = 'fk-cont_acustica-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:729d3b35064107f88dd49edc6b028653' WHERE [ID] = 'fk-cont_acustica-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b324f93b62749bfcddf1a433a0854bf1' WHERE [ID] = 'fk-cont_acustica-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_auth::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_authority] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [telephone] [varchar](200) NULL, [email] [varchar](200) NULL, [url] [varchar](400) NULL, [legal_name] [varchar](200) NULL, [alternate_name] [varchar](200) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_auth', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 577, '7:a51ad9c7c77de202e69172c17ca71a1d', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_daytype::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_daytype] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [title] [varchar](200) NULL, [description] [varchar](4000) NULL, [short_name] [varchar](200) NULL, [earliest_time] [varchar](8) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_daytype', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 578, '7:101f8468528930b9aa893097f49f8543', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_daytypeassi::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [date_assignment] [datetime] NULL, [is_available] [bit] NULL, [specifying] [varchar](50) NULL, [for_the_definition_of] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_daytypeassi', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 579, '7:95af633cce896e5730aae87efe99cadf', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_headinte::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [minimum_headway_interval] [varchar](50) NULL, [maximum_headway_interval] [varchar](50) NULL, [scheduled_headway_interval] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_headinte', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 580, '7:4da8c1f4120331019c9e93097f5a8a05', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_headjourgrou::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [first_departure_time] [varchar](8) NULL, [last_departure_time] [varchar](8) NULL, [determined_by] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_headjourgrou', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 581, '7:5acec004421abeff9778d20561270b5a', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_inci::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_incidencia] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [tipo_incidencia] [varchar](50) NULL, [date_posted] [datetime] NULL, [num_sentidos] [int] NULL, [num_carriles] [int] NULL, [es_recurrente] [bit] NULL, [fecha_fin_prevista] [datetime] NULL, [x_etrs89] [decimal](13, 5) NULL, [y_etrs89] [decimal](13, 5) NULL, [incidencia_tramo_id] [varchar](50) NULL, [incidencia_tramo_description] [varchar](4000) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_inci', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 582, '7:8f99334466277505f9323fea16885d44', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_jourpatt::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [title] [varchar](200) NULL, [distance] [float](53) NULL, [on_id] [varchar](50) NULL, [generado_por_incidencia] [varchar](50) NULL, [front_text] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_jourpatt', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 583, '7:fddc2498c73a4b7915415c432ab9bf4f', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_linea::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_linea] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [title] [varchar](200) NULL, [url] [varchar](400) NULL, [short_name] [varchar](200) NULL, [cabecera_linea] [varchar](50) NULL, [final_linea] [varchar](50) NULL, [distance] [decimal](12, 2) NULL, [operating] [varchar](50) NULL, [colour] [varchar](200) NULL, [text_colour] [varchar](200) NULL, [geometry] [varchar](MAX) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_linea', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 584, '7:3146c2bed8f170f1e289b3388bec6925', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_oper::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_operator] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [serving_pt_for] [varchar](50) NULL, [telephone] [varchar](200) NULL, [email] [varchar](200) NULL, [url] [varchar](400) NULL, [legal_name] [varchar](200) NULL, [alternate_name] [varchar](200) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_oper', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 585, '7:6dd657418fa2d85243d785fdfdbb34c6', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_parada::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_parada] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [title] [varchar](200) NULL, [url] [varchar](400) NULL, [wifi] [bit] NULL, [panel_electronico] [bit] NULL, [zona] [varchar](10) NULL, [x_etrs89] [decimal](13, 5) NULL, [y_etrs89] [decimal](13, 5) NULL, [portal_id] [varchar](50) NULL, [street_address] [varchar](200) NULL, [postal_code] [varchar](10) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_parada', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 586, '7:970cd5a239e83700d3b264f5d7f99654', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_poinonrout::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [order_point] [int] NULL, [distance_from_start] [decimal](12, 2) NULL, [in_id] [varchar](50) NULL, [functional_centroid_for] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_poinonrout', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 587, '7:70efb2433b25ec0feaf201047e4f350b', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_realtimepass::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [result_time] [datetime] NULL, [expected_arrival_time] [varchar](50) NULL, [has_feature_of_interest] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_realtimepass', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 588, '7:e3c13be83d9a494ecaaa4575ff224d41', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_rel_line_inci::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [linea] [varchar](50) NOT NULL, [afectada_incidencia] [varchar](50) NOT NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_rel_line_inci', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 589, '7:8633f6e5532726135914aac483a3ab6a', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_route::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_route] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [direction_type] [varchar](200) NULL, [on_id] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_route', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 590, '7:b62f8dc704a78447e35e1f885c918ecf', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_servcale::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_servicecalendar] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [title] [varchar](200) NULL, [description] [varchar](4000) NULL, [short_name] [varchar](200) NULL, [from_day] [datetime] NULL, [to_day] [datetime] NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_servcale', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 591, '7:5e3e19877977b949fb1aeb1156a41f54', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_stoppoinjourpatt::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [order_stop] [int] NULL, [stop_use] [varchar](200) NULL, [in_id] [varchar](50) NULL, [viewed_as] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_stoppoinjourpatt', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 592, '7:b6440d06ae89ee8094ea3c237e358f57', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_schestoppoin::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [functional_centroid_for] [varchar](50) NULL, [alighting] [bit] NULL, [boarding] [bit] NULL, [title_stop_area] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_schestoppoin', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 593, '7:b89d3b22a3ef211e4bc9be4d101c9486', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::table-bus_vehijour::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [journey_duration] [varchar](50) NULL, [departure_time] [varchar](8) NULL, [made_using] [varchar](50) NULL, [worked_on] [varchar](50) NULL, [composed_of] [varchar](50) NULL, [direction_type] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-bus_vehijour', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 594, '7:b5817de1dc28a2c1fc374a4f181fc988', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_authority] ADD CONSTRAINT [PK_bus_auth] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-01', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 595, '7:81cbee2608da67a8b84a4d1982098060', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytype] ADD CONSTRAINT [PK_bus_daytype] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-02', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 596, '7:982ebc00d80b0076d30460f5b0f65ca5', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [PK_bus_daytypassi] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-03', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 597, '7:3f719cda5e7c498f3fa81f0601f1bb9b', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayinterval] ADD CONSTRAINT [PK_bus_headinte] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-04', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 598, '7:0f4307b1beebf1bbab7f5d90b4da6f0a', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ADD CONSTRAINT [PK_bus_headjourgrou] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-05', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 599, '7:28cc9d07ce40221d59714991418b16b6', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_incidencia] ADD CONSTRAINT [PK_bus_incidencia] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-06', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 600, '7:11d47be8bf3b8e9385119a8f09141982', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [PK_bus_jourpatt] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-07', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 601, '7:a34c23f11ad2ac3e59801a0362b5d445', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [PK_bus_linea] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-08', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 602, '7:cc9f8dc81b50981c7c68c16c656ed043', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] ADD CONSTRAINT [PK_bus_operator] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-09', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 603, '7:9785843081084bcdb7f537d266c2f25d', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_parada] ADD CONSTRAINT [PK_bus_parada] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-10', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 604, '7:a443e1e8dfebd0570fcc0e300cf22e8b', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-11::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [PK_bus_poinonrout] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-11', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 605, '7:94e78aba45da9c8b89ef4c5e7da71bf2', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-12::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ADD CONSTRAINT [PK_bus_realtimepasstime] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-12', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 606, '7:00d3cbda3a1f0467d5af6fc4ebdc1a46', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-13::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ADD CONSTRAINT [PK_bus_rel_line_inci] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-13', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 607, '7:bed7f4c70e5ca81aab11dee43b6249de', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-14::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] ADD CONSTRAINT [PK_bus_route] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-14', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 608, '7:c0569fd22681166ad1783d9ba7116379', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-15::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_servicecalendar] ADD CONSTRAINT [PK_bus_servcale] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-15', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 609, '7:7b49c53b2c3c69a80cdd390694ba15eb', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-16::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [PK_bus_stoppoininjourpatt] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-16', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 610, '7:ed9a95d0439d73b9a9c6a3331d26140f', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-17::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [PK_bus_vehijour] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-17', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 611, '7:fd65b6ec0017d77145a89e6bac7dd61f', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::PK_table-18::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ADD CONSTRAINT [PK_bus_schestop_point] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK_table-18', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 612, '7:d11cf0063793814dd802556ccb693a27', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_authority] ADD CONSTRAINT [unique-id-bus_authority] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-01', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 613, '7:d6981f9a44f039dedc174f8d158528c8', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] ADD CONSTRAINT [unique-id-bus_operator] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-02', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 614, '7:2f780e54a8c405c842095800faa2d447', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [unique-id-bus_linea] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-03', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 615, '7:10f9dd9a98b8c7a4140611d7c54c8d3d', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ADD CONSTRAINT [unique-id-bus_rel_line_inci] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-04', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 616, '7:fa32fc4ac2c01c4e42344e2635751e5e', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] ADD CONSTRAINT [unique-id-bus_route] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-05', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 617, '7:95d9fed6f557ff4a79995b4fc502b5d3', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_incidencia] ADD CONSTRAINT [unique-id-bus_incidencia] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-06', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 618, '7:7e34ac2baaaa1c5686296323e59fba60', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [unique-id-bus_poinonrout] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-07', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 619, '7:0ca080ea62850f2d5acf20a9d7a6e461', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [unique-id-bus_jourpatt] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-08', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 620, '7:1732c70c36257ec33137ee7ee9c00919', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [unique-id-bus_stopoiinjoupat] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-09', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 621, '7:d582b09ecaf69c66fdc260f8853d4dc6', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_parada] ADD CONSTRAINT [unique-id-bus_parada] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-10', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 622, '7:46be4fc4dabee1807cc7cd03d4efd210', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-11::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [unique-id-bus_vehijour] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-11', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 623, '7:310314d4a5e645bb912188f6c735c1d2', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-12::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ADD CONSTRAINT [unique-id-bus_realpasstime] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-12', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 624, '7:60bbaed82c86a6d5bc7216ace0a1a53a', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-13::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ADD CONSTRAINT [unique-id-bus_headjourgroup] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-13', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 625, '7:ca9af7a3e057dcbd943a416add1791dc', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-14::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayinterval] ADD CONSTRAINT [unique-id-bus_headinte] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-14', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 626, '7:b8a320dc73a095379aebb2ed9a30e52a', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-15::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_servicecalendar] ADD CONSTRAINT [unique-id-bus_servicale] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-15', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 627, '7:8e0d18ea5822ba6e699f65e28279491d', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-16::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [unique-id-bus_daytypeassi] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-16', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 628, '7:c0e9abb52b6007a20f47d3964b1ed4a3', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-17::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytype] ADD CONSTRAINT [unique-id-bus_daytype] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-17', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 629, '7:da62bef29d1cc40cf18e433f37d981f3', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::unique-id-18::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ADD CONSTRAINT [unique-id-bus_schestoppoin] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-18', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 630, '7:5aede46fbb92c517f002024ee0600cee', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-1::Localidata
CREATE NONCLUSTERED INDEX [index_bus_afectada_incidencia] ON [schema_ciudadesAbiertas].[bus_rel_linea_incidencia]([afectada_incidencia])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-1', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 631, '7:713c424068bb0352155f650c6d7ee4ef', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-2::Localidata
CREATE NONCLUSTERED INDEX [index_bus_cabecera_linea] ON [schema_ciudadesAbiertas].[bus_linea]([cabecera_linea])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-2', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 632, '7:f572c5ac2fe77131b847137ff03737dc', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-3::Localidata
CREATE NONCLUSTERED INDEX [index_bus_composed_of] ON [schema_ciudadesAbiertas].[bus_vehiclejourney]([composed_of])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-3', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 633, '7:3bf460c87c2847ba8fef84f0fa6bde71', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-4::Localidata
CREATE NONCLUSTERED INDEX [index_bus_determined_by] ON [schema_ciudadesAbiertas].[bus_headwayjourneygroup]([determined_by])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-4', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 634, '7:5f4f1d911d2009d56bb747a8a64c4b0d', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-5::Localidata
CREATE NONCLUSTERED INDEX [index_bus_final_linea] ON [schema_ciudadesAbiertas].[bus_linea]([final_linea])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-5', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 635, '7:caf9a9f7e4f172ae9b231f60396681fb', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-6::Localidata
CREATE NONCLUSTERED INDEX [index_bus_for_the_defi_of] ON [schema_ciudadesAbiertas].[bus_daytypeassignment]([for_the_definition_of])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-6', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 636, '7:14f2e5787969d813fb29395fc6374c07', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-7::Localidata
CREATE NONCLUSTERED INDEX [index_bus_func_cent_for_1] ON [schema_ciudadesAbiertas].[bus_pointonroute]([functional_centroid_for])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-7', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 637, '7:42dd956691c847fa7a4037bdff5a2410', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-9::Localidata
CREATE NONCLUSTERED INDEX [index_bus_gene_por_inci] ON [schema_ciudadesAbiertas].[bus_journeypattern]([generado_por_incidencia])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-9', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 638, '7:653bddd1643a284300e7c5f47f10c5c5', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-10::Localidata
CREATE NONCLUSTERED INDEX [index_bus_has_feat_of_inte] ON [schema_ciudadesAbiertas].[bus_realtime_passing_time]([has_feature_of_interest])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-10', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 639, '7:429085cc9bfad9019905fe07ab7b6203', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-12::Localidata
CREATE NONCLUSTERED INDEX [index_bus_in_1] ON [schema_ciudadesAbiertas].[bus_pointonroute]([in_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-12', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 640, '7:9c962195cacb4772a1f70d6931015c6c', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-13::Localidata
CREATE NONCLUSTERED INDEX [index_bus_in_2] ON [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern]([in_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-13', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 641, '7:35067b410b19361f0ba4882584548b24', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-14::Localidata
CREATE NONCLUSTERED INDEX [index_bus_made_using] ON [schema_ciudadesAbiertas].[bus_vehiclejourney]([made_using])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-14', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 642, '7:166c40ba7e173c08e60ee22018e3cf54', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-15::Localidata
CREATE NONCLUSTERED INDEX [index_bus_on_1] ON [schema_ciudadesAbiertas].[bus_journeypattern]([on_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-15', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 643, '7:c9caadc8036dc9ba0c476af753918030', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-16::Localidata
CREATE NONCLUSTERED INDEX [index_bus_on_id_2] ON [schema_ciudadesAbiertas].[bus_route]([on_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-16', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 644, '7:980ff21ccc57d46f1475af331bc6d720', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-17::Localidata
CREATE NONCLUSTERED INDEX [index_bus_operating] ON [schema_ciudadesAbiertas].[bus_linea]([operating])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-17', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 645, '7:69453e2236eca60fc07cd3cf20b51d04', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-18::Localidata
CREATE NONCLUSTERED INDEX [index_bus_serving_pt_for] ON [schema_ciudadesAbiertas].[bus_operator]([serving_pt_for])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-18', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 646, '7:f3780871a2f15ac40ab711668e2536b6', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-19::Localidata
CREATE NONCLUSTERED INDEX [index_bus_specifying] ON [schema_ciudadesAbiertas].[bus_daytypeassignment]([specifying])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-19', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 647, '7:d08ddea724a8add8a2631794718be63c', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-20::Localidata
CREATE NONCLUSTERED INDEX [index_bus_worked_on] ON [schema_ciudadesAbiertas].[bus_vehiclejourney]([worked_on])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-20', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 648, '7:e91de6bde9ded22e6ce91ed1d127f0e5', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-21::Localidata
CREATE NONCLUSTERED INDEX [index_bus_centroid_route] ON [schema_ciudadesAbiertas].[bus_scheduled_stop_point]([functional_centroid_for])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-21', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 649, '7:4bae1fe487730736ebfc12ef8fabd1c5', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-table.xml::INDEX-bus-22::Localidata
CREATE NONCLUSTERED INDEX [index_bus_journew_viewed] ON [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern]([viewed_as])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-bus-22', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-table.xml', GETDATE(), 650, '7:820d84e3be19d3acba5742b347349935', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_authority::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_authority] ([ikey], [id], [telephone], [email], [url], [legal_name], [alternate_name], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSAUTH01', 'crtm', '+34 91 406 88 10', 'info@crtm.es', 'https://www.crtm.es', 'Consorcio de transportes de Madrid', 'CRTM', 'PORTAL000119', 'Calle Cerro de la Plata, 4', '28007', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_authority', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 651, '7:0794feb59250db60bc837ec0e3002a6d', 'insert', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_daytype::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_daytype] ([ikey], [id], [title], [description], [short_name], [earliest_time]) VALUES ('BUSDAYTYP01', 'laborable', N'Día laborable', N'Horario general para el servicio de EMT en día laborable.', 'Laborables', '05:30:00')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_daytype] ([ikey], [id], [title], [description], [short_name], [earliest_time]) VALUES ('BUSDAYTYP02', 'festivo', N'Día festivo', N'Horario general para el servicio de EMT en día festivo.', 'Festivos', '06:30:00')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_daytype', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 652, '7:ae9f357fdbbdeaa801f9aef594418cf6', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_daytypeassignment::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_daytypeassignment] ([ikey], [id], [date_assignment], [is_available], [specifying], [for_the_definition_of]) VALUES ('BUSDAYASS01', '2020-01-02-CAL01-laborable', '2020-01-02T00:00:00.000', 1, 'laborable', '2020')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_daytypeassignment] ([ikey], [id], [date_assignment], [is_available], [specifying], [for_the_definition_of]) VALUES ('BUSDAYASS02', '2020-02-02-CAL01-laborable', '2020-02-02T00:00:00.000', 1, 'laborable', '2020')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_daytypeassignment', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 653, '7:2c18fa71a0776e79041567a178ffc733', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_headwayinterval::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey], [id], [minimum_headway_interval], [maximum_headway_interval], [scheduled_headway_interval]) VALUES ('BUSHEAINT01', '6-laborable', 'P7M', 'P20M', 'Cada 7 - 20 min.')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey], [id], [minimum_headway_interval], [maximum_headway_interval], [scheduled_headway_interval]) VALUES ('BUSHEAINT02', '66-laborable', 'P5M', 'P15M', 'Cada 5 - 15 min.')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayinterval] ([ikey], [id], [minimum_headway_interval], [maximum_headway_interval], [scheduled_headway_interval]) VALUES ('BUSHEAINT03', '138-laborable', 'P10M', 'P30M', 'Cada 10 - 30 min.')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_headwayinterval', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 654, '7:9f8962f4d0417ec73b786df1de7afdf9', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_headwayjourneygroup::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey], [id], [first_departure_time], [last_departure_time], [determined_by]) VALUES ('BUSHEAJOU01', '6a1-laborable', '06:15:00', '23:30:00', '6-laborable')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey], [id], [first_departure_time], [last_departure_time], [determined_by]) VALUES ('BUSHEAJOU02', '66a1-laborable', '06:15:00', '23:30:00', '66-laborable')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([ikey], [id], [first_departure_time], [last_departure_time], [determined_by]) VALUES ('BUSHEAJOU03', '138a1-laborable', '06:15:00', '23:30:00', '138-laborable')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_headwayjourneygroup', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 655, '7:a561d4a34505630b6c928205076a88be', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_incidencia::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [x_etrs89], [y_etrs89], [incidencia_tramo_id], [incidencia_tramo_description], [street_address], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('29059944-382A-49AA-A068-B55BF2FAC51F', 'BUSINC01', N'Corte de calles entre el cruce de Alcalá con Gran Vía y la Plaza de la Independencia', 'obras', '2020-03-31T08:00:00.000', 2, 8, 0, '2020-05-03T23:59:00.000', 440124.33000, 4474637.17000, 'TRAFTRAM01', N'Calles entre el cruce de Alcalá con Gran Vía y la Plaza de la Independencia', 'Calle Pruebas, 4', '28006', 'PORTAL000119', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [x_etrs89], [y_etrs89], [incidencia_tramo_id], [incidencia_tramo_description], [street_address], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('30059944-382A-49AA-A068-B55BF2FAC51F', 'BUSINC02', N'Corte de calles entre Gran Vía y la Plaza de Callao', 'obras', '2020-04-30T08:00:00.000', 4, 6, 0, '2020-06-03T23:59:00.000', 440124.33000, 4474637.17000, 'TRAFTRAM01', N'Calles entre el cruce de Alcalá con Gran Vía y la Plaza de la Independencia', 'Calle Pruebas, 64', '28006', 'PORTAL000117', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [x_etrs89], [y_etrs89], [incidencia_tramo_id], [incidencia_tramo_description], [street_address], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('18059944-382A-49AA-A068-B55BF2FAC51F', 'BUSINC03', N'Corte de calles entre el cruce de Alcalá y  la Plaza de Sol', 'obras', '2020-02-28T08:00:00.000', 2, 8, 0, '2020-07-03T23:59:00.000', 440124.33000, 4474637.17000, 'TRAFTRAM01', N'Calles entre el cruce de Alcalá con Gran Vía y la Plaza de la Independencia', 'Calle Pruebas, xx', '28006', 'PORTAL000121', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_incidencia', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 656, '7:c33d5f66f0b41b2831174274c659f798', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_journeypattern::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey], [id], [title], [distance], [on_id], [generado_por_incidencia], [front_text]) VALUES ('BUSJOUPAT01', '6a2', '6a2', 11.19, '6a', 'BUSINC01', 'Benavente')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey], [id], [title], [distance], [on_id], [generado_por_incidencia], [front_text]) VALUES ('BUSJOUPAT02', '66a2', '66a2', 12.14, '66a', 'BUSINC02', 'Cuatro Caminos')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_journeypattern] ([ikey], [id], [title], [distance], [on_id], [generado_por_incidencia], [front_text]) VALUES ('BUSJOUPAT03', '138a2', '138a2', 14.94, '138a', 'BUSINC03', 'San Ignacio de Loyola')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_journeypattern', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 657, '7:bb3024c9dd0d9c58a128748e70b0324f', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_linea::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_linea] ([ikey], [id], [description], [title], [url], [short_name], [cabecera_linea], [final_linea], [distance], [operating], [colour], [text_colour], [geometry]) VALUES ('BUSLIN01', '6', N'La línea 6 de la EMT de Madrid une la plaza de Jacinto Benavente con el barrio de Orcasitas, en el distrito de Usera.', N'Línea 6', 'https://www.emtmadrid.es/Bloques-EMT/EMT-BUS/Mi-linea-(1).aspx?linea=6&lang=es-ES', '6', '1918', '5359', 51, 'emt', 'Azul', 'Negro', NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_linea] ([ikey], [id], [description], [title], [url], [short_name], [cabecera_linea], [final_linea], [distance], [operating], [colour], [text_colour], [geometry]) VALUES ('BUSLIN02', '138', N'La línea 138 de la EMT de Madrid une el Hospital Clínico San Carlos con la Colonia San Ignacio de Loyola, atravesando el eje Valmojado-Sepúlveda-Caramuel y el intercambiador de Aluche.', N'Línea 138', 'https://www.emtmadrid.es/Bloques-EMT/EMT-BUS/Mi-linea-(1).aspx?linea=138&lang=es-ES', '138', '4608', '5481', 58.34, 'emt', 'Azul', 'Negro', NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_linea] ([ikey], [id], [description], [title], [url], [short_name], [cabecera_linea], [final_linea], [distance], [operating], [colour], [text_colour], [geometry]) VALUES ('BUSLIN03', '66', N'La línea 66 de la EMT de Madrid une la Glorieta de Cuatro Caminos con Fuencarral.', N'Línea 66', 'https://www.emtmadrid.es/Bloques-EMT/EMT-BUS/Mi-linea-(1).aspx?linea=66&lang=es-ES', '66', '3219', '5105', 44.4, 'emt', 'Azul', 'Negro', NULL)
GO

-- CARLOS CAMBIO A MANO
INSERT [schema_ciudadesAbiertas].[bus_linea] ([ikey], [id], [description], [title], [url], [short_name], [cabecera_linea], [final_linea], [distance], [operating], [colour], [text_colour], [geometry]) VALUES (N'BUSLIN11', N'11', NULL, N'MARQUES DE VIANA-BARRIO BLANCO', N'http://www.crtm.es/tu-transporte-publico/autobuses-emt/lineas/6__11___.aspx', N'11', N'697', N'4293', NULL, NULL, NULL, NULL, N'{
"type": "FeatureCollection",
"name": "linea11_25830",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:EPSG::25830" } },
"features": [
{ "type": "Feature", "properties": { "Name": "Línea 11", "description": "Linea 11 EMT Madrid" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 440308.870944459049497, 4479452.675740204751492 ], [ 440379.863307164458092, 4479403.579860114492476 ], [ 440491.741487772611436, 4479323.482737871818244 ], [ 440521.527268830221146, 4479301.62903831154108 ], [ 440705.625575037673116, 4479167.761016940698028 ], [ 440766.662720031279605, 4479127.06952001247555 ], [ 440801.077184893656522, 4479105.648712418042123 ], [ 440864.126976786414161, 4479077.864846059121192 ], [ 440971.098966241406742, 4479030.262459769845009 ], [ 441121.047499030129984, 4478967.244703589007258 ], [ 441164.426214296545368, 4478949.543279623612761 ], [ 441260.504750287975185, 4478944.347836215049028 ], [ 441318.542625636793673, 4478942.556635236367583 ], [ 441377.655177495675161, 4478937.540894883684814 ], [ 441421.069730006158352, 4478932.345441631041467 ], [ 441432.764958768035285, 4478930.494328713044524 ], [ 441445.954443477327004, 4478924.568510095588863 ], [ 441449.968735988077242, 4478915.584292324259877 ], [ 441454.174258239858318, 4478907.173508103005588 ], [ 441460.476396671496332, 4478899.999958304688334 ], [ 441475.24154402106069, 4478892.091954371891916 ], [ 441494.513263864209875, 4478888.481374732218683 ], [ 441512.580260475864634, 4478889.083227279596031 ], [ 441534.26091153366724, 4478894.499362122267485 ], [ 441546.305830892990343, 4478900.517344374209642 ], [ 441558.005665614036843, 4478909.336702917702496 ], [ 441569.318943695747294, 4478923.468001393601298 ], [ 441678.081369047577027, 4478917.815605351701379 ], [ 441866.211863136850297, 4478902.859009006991982 ], [ 441993.963388050149661, 4478890.580387217923999 ], [ 442101.244615606148727, 4478876.474966249428689 ], [ 442148.297910889959894, 4478872.713353371247649 ], [ 442270.921043136913795, 4478873.172122637741268 ], [ 442350.911694879177958, 4478874.58268132340163 ], [ 442513.021614244556986, 4478878.34100444521755 ], [ 442556.781249978637788, 4478877.870745717547834 ], [ 442585.013124849705491, 4478875.049662729725242 ], [ 442594.044447521329857, 4478873.486546022817492 ], [ 442600.160218999837525, 4478871.908068963326514 ], [ 442601.371597761812154, 4478869.764605395495892 ], [ 442602.95622035942506, 4478867.4345200099051 ], [ 442604.167599070817232, 4478865.570605284534395 ], [ 442605.65903866494773, 4478863.520068715326488 ], [ 442607.243405145360157, 4478861.842519955709577 ], [ 442608.920954611618072, 4478859.978605312295258 ], [ 442611.157601736369543, 4478858.394239619374275 ], [ 442613.674053609662224, 4478857.36897165235132 ], [ 442615.944236384297255, 4478855.63305567856878 ], [ 442625.008326719456818, 4478853.891253002919257 ], [ 442628.313249588070903, 4478853.599416894838214 ], [ 442630.828933266573586, 4478853.689272342249751 ], [ 442633.238634106935933, 4478853.951157826930285 ], [ 442635.414097441826016, 4478854.980266589671373 ], [ 442637.442362497095019, 4478855.657123311422765 ], [ 442639.956765985582024, 4478856.865686115808785 ], [ 442642.088453608506825, 4478859.014526235871017 ], [ 442643.943152377614751, 4478861.000808133743703 ], [ 442645.636317063530441, 4478862.443096150644124 ], [ 442647.016141286410857, 4478863.822920814156532 ], [ 442647.956674509856384, 4478864.888892943970859 ], [ 442648.897463707136922, 4478866.080559658817947 ], [ 442649.775533632491715, 4478867.146531773731112 ], [ 442650.653347549319733, 4478868.275479182600975 ], [ 442659.019589583622292, 4478867.368738940916955 ], [ 442732.251406575378496, 4478862.183018817566335 ], [ 442969.981340655416716, 4478857.437131475657225 ], [ 443005.843209234357346, 4478857.032150532118976 ], [ 443049.084962718188763, 4478856.958431160077453 ], [ 443072.780568451678846, 4478855.073784731328487 ], [ 443122.325738756684586, 4478856.42008244805038 ], [ 443157.599837094312534, 4478860.728264144621789 ], [ 443178.333299033925869, 4478865.036699209362268 ], [ 443271.928145155776292, 4478891.647359451279044 ], [ 443300.324880048807245, 4478900.545568044297397 ], [ 443326.194923515024129, 4478908.651977124623954 ], [ 443328.372691443189979, 4478906.267876449972391 ], [ 443330.889655477833003, 4478904.310267011635005 ], [ 443333.165982185746543, 4478902.540047414600849 ], [ 443336.448889709892683, 4478899.986732847988605 ], [ 443338.444899464957416, 4478898.811962475068867 ], [ 443342.010171729663853, 4478896.713810809887946 ], [ 443345.144088548782747, 4478896.272984351962805 ], [ 443347.581437186861876, 4478895.929948667995632 ], [ 443352.020683143869974, 4478896.465239415876567 ], [ 443355.419556827866472, 4478896.875091399997473 ], [ 443357.456269868416712, 4478897.120592991821468 ], [ 443363.650375990662724, 4478898.15021447557956 ], [ 443366.063660765998065, 4478898.551362380385399 ], [ 443369.15636156097753, 4478900.813097378239036 ], [ 443373.1614359706291, 4478903.742473009042442 ], [ 443375.241156122705434, 4478906.228205307386816 ], [ 443378.752155862341169, 4478910.425022532232106 ], [ 443380.723588987952098, 4478914.268307472579181 ], [ 443383.077225679066032, 4478918.856544063426554 ], [ 443383.236711402074434, 4478921.534529847092927 ], [ 443383.451236338587478, 4478925.133593224920332 ], [ 443383.550306924094912, 4478926.79885443393141 ], [ 443386.337859329476487, 4478928.082424441352487 ], [ 443390.87284801073838, 4478929.713126835413277 ], [ 443398.105278168513905, 4478932.314058753661811 ], [ 443447.054996256309096, 4478949.917196686379611 ], [ 443548.229915383970365, 4478986.301827814429998 ], [ 443569.181742301036138, 4478993.836338455788791 ], [ 443608.528496488928795, 4479011.219061130657792 ], [ 443687.460081334342249, 4479050.810052031651139 ], [ 443721.0374272945337, 4479074.614973137155175 ], [ 443741.983876926882658, 4479089.710870367474854 ], [ 443753.411330884089693, 4479097.946555376052856 ], [ 443763.81633232079912, 4479106.324318603612483 ], [ 443770.320962663681712, 4479108.979777763597667 ], [ 443780.599502487690188, 4479111.973153794184327 ], [ 443797.320210041478276, 4479113.811216004192829 ], [ 443812.397928492748179, 4479113.339672011323273 ], [ 443825.671123525185976, 4479111.306545345112681 ], [ 443837.105491410533432, 4479108.350804762914777 ], [ 443843.346445506089367, 4479106.620265414938331 ], [ 443847.164899241062813, 4479102.734229991212487 ], [ 443967.061168850050308, 4478999.020350777544081 ], [ 444019.286382216028869, 4478948.844414815306664 ], [ 444037.521828297700267, 4478930.610768008045852 ], [ 444064.306811254878994, 4478906.377062496729195 ], [ 444077.456360671203583, 4478898.711999405175447 ], [ 444121.288963102328125, 4478856.006825570948422 ], [ 444136.63036073098192, 4478843.414074532687664 ], [ 444160.19029232300818, 4478817.134183561429381 ], [ 444188.133408736088313, 4478778.808861429803073 ], [ 444227.034741928335279, 4478717.48834499903023 ], [ 444266.91935950901825, 4478659.165810886770487 ], [ 444289.358792673272546, 4478627.314910656772554 ], [ 444336.600258056190796, 4478554.298399842344224 ], [ 444347.00475199020002, 4478537.329121381044388 ], [ 444357.286110500746872, 4478524.915055439807475 ], [ 444364.997001934272703, 4478512.50073304027319 ], [ 444370.994503889058251, 4478504.3671939894557 ], [ 444377.848828657704871, 4478493.665492094121873 ], [ 444393.270866912091151, 4478472.261576608754694 ], [ 444401.838581080897711, 4478457.707118543796241 ], [ 444407.836083261528984, 4478448.289497998543084 ], [ 444413.833585744549055, 4478437.159512791782618 ], [ 444418.117442903749179, 4478429.454000599682331 ], [ 444424.971767365699634, 4478420.464407360181212 ], [ 444431.563950690673664, 4478411.960952593013644 ], [ 444437.630060028808657, 4478402.926559729501605 ], [ 444444.934171588451136, 4478393.032528784126043 ], [ 444449.478889796242584, 4478385.409447705373168 ], [ 444454.023863829614129, 4478378.759411638602614 ], [ 444456.458396950503811, 4478375.840021044015884 ], [ 444461.327719476714265, 4478368.37898619659245 ], [ 444464.087369426561054, 4478362.702250816859305 ], [ 444515.838224305014592, 4478287.867649375461042 ], [ 444531.762017229222693, 4478264.568075406365097 ], [ 444539.154960243613459, 4478252.065945954062045 ], [ 444554.509927363716997, 4478229.902999049983919 ], [ 444568.727499082160648, 4478208.876679096370935 ], [ 444578.395232594106346, 4478195.805980475619435 ], [ 444586.357257301569916, 4478182.735537544824183 ], [ 444594.887596113607287, 4478166.823782809078693 ], [ 444623.322485143085942, 4478115.678381659090519 ], [ 444632.421905548020732, 4478099.766371036879718 ], [ 444640.95224445592612, 4478083.286302727647126 ], [ 444652.326200363168027, 4478061.123355126939714 ], [ 444658.582003864867147, 4478050.325910225510597 ], [ 444678.583320966572501, 4478015.176230874843895 ], [ 444733.178564260248095, 4477914.590368947945535 ], [ 444756.710594559204765, 4477874.036079284735024 ], [ 444772.639508114312775, 4477846.601640060544014 ], [ 444772.650771991349757, 4477846.583208277821541 ], [ 444781.75966411200352, 4477831.593043249100447 ], [ 444787.204980321170297, 4477823.097012202255428 ], [ 444824.826584950904362, 4477754.557633234187961 ], [ 444842.456343822996132, 4477724.438552646897733 ], [ 444852.12433420564048, 4477706.253543816506863 ], [ 444873.166024067788385, 4477668.178841722197831 ], [ 444882.26518824941013, 4477653.403458277694881 ], [ 444890.226956434198655, 4477643.174327256157994 ], [ 444894.776538923440967, 4477633.51350921113044 ], [ 444901.601167806307785, 4477623.852691575884819 ], [ 444914.112261583679356, 4477609.077564720995724 ], [ 444921.505460264859721, 4477598.280120017006993 ], [ 444939.704043021774851, 4477577.821858374401927 ], [ 444945.18647882778896, 4477569.193476836197078 ], [ 444939.018997646227945, 4477561.214557921513915 ], [ 444915.689471263205633, 4477543.955740871839225 ], [ 444802.894339736609254, 4477459.279046039097011 ], [ 444793.137522935809102, 4477451.449628810398281 ], [ 444778.163229599769693, 4477439.433633976615965 ], [ 444771.043438464112114, 4477435.314895274117589 ], [ 444761.675738147867378, 4477422.583901504054666 ], [ 444755.680288664938416, 4477405.359647101722658 ], [ 444755.612194326531608, 4477400.275800538249314 ], [ 444751.183703564165626, 4477381.020977355539799 ], [ 444732.379959790676367, 4477309.661268478259444 ], [ 444729.007456192979589, 4477295.806960459798574 ], [ 444726.759035612456501, 4477283.825015472248197 ], [ 444725.260430526454002, 4477272.217338393442333 ], [ 444723.01200955035165, 4477262.481768017634749 ], [ 444722.608047485875431, 4477254.601408998481929 ], [ 444722.307251436403021, 4477251.396069171838462 ], [ 444722.197428878513165, 4477250.227442359551787 ], [ 444719.750101493205875, 4477221.471798902377486 ], [ 444716.667642708052881, 4477207.187159803695977 ], [ 444713.235490337596275, 4477201.538583035580814 ], [ 444709.399630298721604, 4477197.100360515527427 ], [ 444703.342995401471853, 4477191.855234730057418 ], [ 444694.258171017398126, 4477184.189143775962293 ], [ 444685.173090638243593, 4477176.523052830249071 ], [ 444589.335975718626287, 4477095.752108840271831 ], [ 444582.014711873198394, 4477108.554778872057796 ], [ 444573.292631397314835, 4477123.61611111368984 ], [ 444572.796508830389939, 4477124.47267735004425 ], [ 444537.140963319980074, 4477186.042535254731774 ], [ 444535.358454841189086, 4477189.120388164184988 ] ] ] } }
]
}')
GO
-- FIN CAMBIO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_linea', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 658, '7:23fcff13f523cd7a8f65e9460367ae6d', 'insert (x4)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_operator::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_operator] ([ikey], [id], [serving_pt_for], [telephone], [email], [url], [legal_name], [alternate_name], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSOPE01', 'emt', 'crtm', '+34 91 406 88 10', 'info@emt.es', 'https://www.emtmadrid.es/AtencionAlCliente/Agradecimientos', 'Empresa Municipal de Transportes', 'EMT', 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_operator', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 659, '7:b78f0e34e85296a469b6ba4fee51b970', 'insert', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_parada::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR1', '3219', 'Cuatro Caminos', 'Cuatro Caminos', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28079', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR2', '1918', 'Benavente', 'Benavente', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR3', '5359', 'Orcasitas', 'Orcasitas', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR4', '4608', 'Cristo Rey', 'Cristo Rey', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR5', '5481', 'San Ignacio', 'San Ignacio', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('BUSPAR6', '5105', 'Fuencarral', 'Fuencarral', 'https://emtmadrid.es/paradas/', 0, 1, 'A', 440124.33000, 4474637.17000, 'PORTAL000010', 'Calle Cerro de la Plata, 4', '28007', '28079', 'Madrid', 'Norte', '28079011', 'Unico', '2807901')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2116', '2116', 'Cuzco', 'Cuzco', NULL, NULL, NULL, NULL, 441550.27791, 4478911.87784, NULL, 'Plaza de Cuzco 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2118', '2118', 'Arturo Soria-Condesa de Venadito', 'Arturo Soria-Condesa de Venadito', NULL, NULL, NULL, NULL, 444910.34837, 4477557.83454, NULL, 'Calle de la Condesa de Venadito 19', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2119', '2119', 'Condesa de Venadito', 'Condesa de Venadito', NULL, NULL, NULL, NULL, 444783.58868, 4477450.98895, NULL, 'Calle de la Condesa de Venadito 11', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2120', '2120', N'Madre Antonia París', N'Madre Antonia París', NULL, NULL, NULL, NULL, 444702.33809, 4477217.83732, NULL, N'Calle de la Madre Antonia París 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2121', '2121', 'Condesa de Venadito-Torrelaguna', 'Condesa de Venadito-Torrelaguna', NULL, NULL, NULL, NULL, 444543.33494, 4477294.83938, NULL, 'Calle de la Condesa de Venadito 16', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2122', '2122', 'Condesa de Venadito', 'Condesa de Venadito', NULL, NULL, NULL, NULL, 444749.34223, 4477424.83667, NULL, 'Calle de la Condesa de Venadito SN', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2123', '2123', N'Hernández de Tejada', N'Hernández de Tejada', NULL, NULL, NULL, NULL, 444734.93751, 4477561.33683, NULL, N'Calle de Hernández de Tejada 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR217', '217', N'Arturo Soria-Gran Vía de Hortaleza', N'Arturo Soria-Gran Vía de Hortaleza', NULL, NULL, NULL, NULL, 443853.34250, 4479148.84806, NULL, 'Calle de Arturo Soria 212 A', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR218', '218', N'Arturo Soria-López de Hoyos', N'Arturo Soria-López de Hoyos', NULL, NULL, NULL, NULL, 443984.09356, 4478975.84639, NULL, 'Calle de Arturo Soria SN', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR219', '219', N'Arturo Soria-López de Hoyos', N'Arturo Soria-López de Hoyos', NULL, NULL, NULL, NULL, 444088.34578, 4478935.84504, NULL, 'Calle de Arturo Soria 200', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR220', '220', 'Metro Arturo Soria', 'Metro Arturo Soria', NULL, NULL, NULL, NULL, 444247.34628, 4478668.84301, NULL, 'Calle de Arturo Soria 167', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR221', '221', 'Metro Arturo Soria', 'Metro Arturo Soria', NULL, NULL, NULL, NULL, 444257.47206, 4478705.84287, NULL, 'Calle de Arturo Soria 182', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR222', '222', N'Jefatura provincial Tráfico', N'Jefatura provincial Tráfico', NULL, NULL, NULL, NULL, 444421.90986, 4478414.34078, NULL, 'Calle de Arturo Soria 145', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR223', '223', 'Arturo Soria-Bueso Pineda', 'Arturo Soria-Bueso Pineda', NULL, NULL, NULL, NULL, 444431.25423, 4478440.84065, NULL, 'Calle de Arturo Soria 164', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR224', '224', 'Arturo Soria-Conservatorio', 'Arturo Soria-Conservatorio', NULL, NULL, NULL, NULL, 444608.41084, 4478129.83839, NULL, 'Calle de Arturo Soria 115', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR225', '225', 'Arturo Soria-Conservatorio', 'Arturo Soria-Conservatorio', NULL, NULL, NULL, NULL, 444696.66162, 4478017.83726, NULL, 'Calle de Arturo Soria 134 A', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR226', '226', N'Nuestra Señora de América', N'Nuestra Señora de América', NULL, NULL, NULL, NULL, 444744.62980, 4477885.83665, NULL, 'Calle de Arturo Soria 103', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR227', '227', N'Nuestra Señora de América', N'Nuestra Señora de América', NULL, NULL, NULL, NULL, 444827.34984, 4477820.83558, NULL, 'Calle de Arturo Soria 124', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR2388', '2388', 'Costa Rica', 'Costa Rica', NULL, NULL, NULL, NULL, 442992.31603, 4478893.85927, NULL, 'Calle de Costa Rica 30', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR293', '293', N'Alberto Alcocer-Padre Damián', N'Alberto Alcocer-Padre Damián', NULL, NULL, NULL, NULL, 441907.28715, 4478892.87326, NULL, 'Calle de Alberto Alcocer 12', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR294', '294', N'Alberto Alcocer-Padre Damián', N'Alberto Alcocer-Padre Damián', NULL, NULL, NULL, NULL, 441911.28785, 4478935.87320, NULL, 'Calle de Alberto Alcocer 15', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR295', '295', 'Alberto Alcocer-Paseo de la Habana', 'Alberto Alcocer-Paseo de la Habana', NULL, NULL, NULL, NULL, 442147.29331, 4478876.87017, NULL, 'Calle de Alberto Alcocer 32', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR296', '296', 'Alberto Alcocer-Paseo de la Habana', 'Alberto Alcocer-Paseo de la Habana', NULL, NULL, NULL, NULL, 442145.29373, 4478910.87019, NULL, 'Calle de Alberto Alcocer 31', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR297', '297', N'República Dominicana', N'República Dominicana', NULL, NULL, NULL, NULL, 442492.30259, 4478883.86573, NULL, 'Calle de Alberto Alcocer SN', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR298', '298', N'República Dominicana', N'República Dominicana', NULL, NULL, NULL, NULL, 442487.30299, 4478921.86579, NULL, 'Calle de Alberto Alcocer 49', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR299', '299', 'Chile', 'Chile', NULL, NULL, NULL, NULL, 442731.30858, 4478857.86265, NULL, 'Calle de Costa Rica 12', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR300', '300', 'Costa Rica', 'Costa Rica', NULL, NULL, NULL, NULL, 442999.31562, 4478850.85918, NULL, 'Calle de Costa Rica 30', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR302', '302', N'José María Soler', N'José María Soler', NULL, NULL, NULL, NULL, 443273.32358, 4478898.85563, NULL, 'Calle de Costa Rica 42', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR303', '303', N'José María Soler', N'José María Soler', NULL, NULL, NULL, NULL, 443253.32345, 4478927.85588, NULL, 'Calle de Costa Rica 29', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR314', '314', 'Chile', 'Chile', NULL, NULL, NULL, NULL, 442686.30807, 4478906.86322, NULL, 'Calle de Costa Rica 5', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR3997', '3997', N'Marqués de Viana-Genciana', N'Marqués de Viana-Genciana', NULL, NULL, NULL, NULL, 440361.25316, 4479405.89295, NULL, N'Calle del Marqués de Viana 73', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR3998', '3998', N'Marqués de Viana-Genciana', N'Marqués de Viana-Genciana', NULL, NULL, NULL, NULL, 440344.49774, 4479443.20200, NULL, N'Calle del Marqués de Viana 64', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR3999', '3999', N'Marqués de Viana-Gladiolo', N'Marqués de Viana-Gladiolo', NULL, NULL, NULL, NULL, 440494.25534, 4479308.89127, NULL, N'Calle del Marqués de Viana 43', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4000', '4000', N'Marqués de Viana-Gladiolo', N'Marqués de Viana-Gladiolo', NULL, NULL, NULL, NULL, 440489.25578, 4479349.89133, NULL, N'Calle del Marqués de Viana 40', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4001', '4001', N'Metro Tetuán', N'Metro Tetuán', NULL, NULL, NULL, NULL, 440763.26008, 4479134.88787, NULL, N'Calle del Marqués de Viana 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4002', '4002', N'Metro Tetuán', N'Metro Tetuán', NULL, NULL, NULL, NULL, 440756.26016, 4479153.88795, NULL, N'Calle del  Marqués de Viana 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4003', '4003', N'Sor Ángela de la Cruz-Infanta Mercedes', N'Sor Ángela de la Cruz-Infanta Mercedes', NULL, NULL, NULL, NULL, 440848.26160, 4479081.88679, NULL, N'Calle de Sor Ángela de la Cruz 37', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4004', '4004', N'Sor Ángela de la Cruz-Infanta Mercedes', N'Sor Ángela de la Cruz-Infanta Mercedes', NULL, NULL, NULL, NULL, 440853.26236, 4479126.88672, NULL, N'Calle de Sor Ángela de la Cruz 36', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4005', '4005', N'Sor Ángela de la Cruz-Orense', N'Sor Ángela de la Cruz-Orense', NULL, NULL, NULL, NULL, 441155.26796, 4478951.88289, NULL, N'Calle de Sor Ángela de la Cruz 11 A', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4006', '4006', N'Sor Ángela de la Cruz-Orense', N'Sor Ángela de la Cruz-Orense', NULL, NULL, NULL, NULL, 441157.29985, 4478993.88286, NULL, N'Calle de Sor Ángela de la Cruz 20', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4007', '4007', N'Sor Ángela de la Cruz-Cuzco', N'Sor Ángela de la Cruz-Cuzco', NULL, NULL, NULL, NULL, 441418.27477, 4478938.87953, NULL, N'Calle de  Sor Ángela de la Cruz 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4008', '4008', N'Sor Ángela de la Cruz-Cuzco', N'Sor Ángela de la Cruz-Cuzco', NULL, NULL, NULL, NULL, 441302.27230, 4478982.88100, NULL, N'Calle de Sor Ángela de la Cruz 6', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4009', '4009', 'Gardenias', 'Gardenias', NULL, NULL, NULL, NULL, 440157.52697, 4479600.10518, NULL, N'Paseo de la Dirección 170', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4293', '4293', N'Marqués de Viana', N'Marqués de Viana', NULL, NULL, NULL, NULL, 440191.75004, 4479505.89509, NULL, N'Calle del Marqués de Viana 80', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR4331', '4331', N'Jefatura Provincial Tráfico', N'Jefatura Provincial Tráfico', NULL, NULL, NULL, NULL, 444557.97376, 4478255.33903, NULL, 'Calle de Arturo Soria 148', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR5882', '5882', 'Cuzco', 'Cuzco', NULL, NULL, NULL, NULL, 441586.40451, 4478957.87737, NULL, 'Avda de Alberto Alcocer 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_parada] ([ikey], [id], [description], [title], [url], [wifi], [panel_electronico], [zona], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('BUSPAR697', '697', 'Barrio Blanco', 'Barrio Blanco', NULL, NULL, NULL, NULL, 444528.33316, 4477195.83959, NULL, 'Calle de Torrelaguna 48 C', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_parada', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 660, '7:33a1de293be2b887066e653aa09035a2', 'insert (x53)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_pointonroute::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIROU01', '6a-1918', 1, 0.0, '6a', '1918')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIROU02', '66a-3219', 1, 0.0, '66a', '3219')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIROU03', '138a-4608', 1, 0.0, '138a', '4608')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-1', '6_I01_sentido_0-1', 1, NULL, '6_I01_sentido_0', '4293')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-10', '6_I01_sentido_0-10', 10, NULL, '6_I01_sentido_0', '295')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-11', '6_I01_sentido_0-11', 11, NULL, '6_I01_sentido_0', '297')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-12', '6_I01_sentido_0-12', 12, NULL, '6_I01_sentido_0', '299')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-13', '6_I01_sentido_0-13', 13, NULL, '6_I01_sentido_0', '300')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-14', '6_I01_sentido_0-14', 14, NULL, '6_I01_sentido_0', '302')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-15', '6_I01_sentido_0-15', 15, NULL, '6_I01_sentido_0', '218')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-16', '6_I01_sentido_0-16', 16, NULL, '6_I01_sentido_0', '220')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-17', '6_I01_sentido_0-17', 17, NULL, '6_I01_sentido_0', '222')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-18', '6_I01_sentido_0-18', 18, NULL, '6_I01_sentido_0', '224')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-19', '6_I01_sentido_0-19', 19, NULL, '6_I01_sentido_0', '226')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-2', '6_I01_sentido_0-2', 2, NULL, '6_I01_sentido_0', '3997')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-20', '6_I01_sentido_0-20', 20, NULL, '6_I01_sentido_0', '2118')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-21', '6_I01_sentido_0-21', 21, NULL, '6_I01_sentido_0', '2119')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-22', '6_I01_sentido_0-22', 22, NULL, '6_I01_sentido_0', '2120')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-23', '6_I01_sentido_0-23', 23, NULL, '6_I01_sentido_0', '697')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-3', '6_I01_sentido_0-3', 3, NULL, '6_I01_sentido_0', '3999')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-4', '6_I01_sentido_0-4', 4, NULL, '6_I01_sentido_0', '4001')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-5', '6_I01_sentido_0-5', 5, NULL, '6_I01_sentido_0', '4003')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-6', '6_I01_sentido_0-6', 6, NULL, '6_I01_sentido_0', '4005')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-7', '6_I01_sentido_0-7', 7, NULL, '6_I01_sentido_0', '4007')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-8', '6_I01_sentido_0-8', 8, NULL, '6_I01_sentido_0', '2116')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_0-9', '6_I01_sentido_0-9', 9, NULL, '6_I01_sentido_0', '293')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-1', '6_I01_sentido_1-1', 1, NULL, '6_I01_sentido_1', '697')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-10', '6_I01_sentido_1-10', 10, NULL, '6_I01_sentido_1', '219')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-11', '6_I01_sentido_1-11', 11, NULL, '6_I01_sentido_1', '217')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-12', '6_I01_sentido_1-12', 12, NULL, '6_I01_sentido_1', '303')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-13', '6_I01_sentido_1-13', 13, NULL, '6_I01_sentido_1', '2388')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-14', '6_I01_sentido_1-14', 14, NULL, '6_I01_sentido_1', '314')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-15', '6_I01_sentido_1-15', 15, NULL, '6_I01_sentido_1', '298')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-16', '6_I01_sentido_1-16', 16, NULL, '6_I01_sentido_1', '296')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-17', '6_I01_sentido_1-17', 17, NULL, '6_I01_sentido_1', '294')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-18', '6_I01_sentido_1-18', 18, NULL, '6_I01_sentido_1', '5882')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-19', '6_I01_sentido_1-19', 19, NULL, '6_I01_sentido_1', '4008')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-2', '6_I01_sentido_1-2', 2, NULL, '6_I01_sentido_1', '2121')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-20', '6_I01_sentido_1-20', 20, NULL, '6_I01_sentido_1', '4006')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-21', '6_I01_sentido_1-21', 21, NULL, '6_I01_sentido_1', '4004')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-22', '6_I01_sentido_1-22', 22, NULL, '6_I01_sentido_1', '4002')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-23', '6_I01_sentido_1-23', 23, NULL, '6_I01_sentido_1', '4000')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-24', '6_I01_sentido_1-24', 24, NULL, '6_I01_sentido_1', '3998')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-25', '6_I01_sentido_1-25', 25, NULL, '6_I01_sentido_1', '4009')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-26', '6_I01_sentido_1-26', 26, NULL, '6_I01_sentido_1', '4293')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-3', '6_I01_sentido_1-3', 3, NULL, '6_I01_sentido_1', '2122')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-4', '6_I01_sentido_1-4', 4, NULL, '6_I01_sentido_1', '2123')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-5', '6_I01_sentido_1-5', 5, NULL, '6_I01_sentido_1', '227')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-6', '6_I01_sentido_1-6', 6, NULL, '6_I01_sentido_1', '225')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-7', '6_I01_sentido_1-7', 7, NULL, '6_I01_sentido_1', '4331')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-8', '6_I01_sentido_1-8', 8, NULL, '6_I01_sentido_1', '223')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_pointonroute] ([ikey], [id], [order_point], [distance_from_start], [in_id], [functional_centroid_for]) VALUES ('BUSPOIRO6_I01_sentido_1-9', '6_I01_sentido_1-9', 9, NULL, '6_I01_sentido_1', '221')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_pointonroute', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 661, '7:6616aaddb35402afa0c76a0baabd7f21', 'insert (x52)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_realtimepassingtime::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey], [id], [result_time], [expected_arrival_time], [has_feature_of_interest]) VALUES ('BUSREATIM01', '6a2-1918', '2020-05-13T12:45:05.000', 'PT15M', '6a-1918')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey], [id], [result_time], [expected_arrival_time], [has_feature_of_interest]) VALUES ('BUSREATIM02', '66a2-3219', '2020-05-13T12:35:05.000', 'PT10M', '66a-3219')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_realtime_passing_time] ([ikey], [id], [result_time], [expected_arrival_time], [has_feature_of_interest]) VALUES ('BUSREATIM03', '138a2-4608', '2020-05-13T12:25:05.000', 'PT20M', '138a-4608')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_realtimepassingtime', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 662, '7:94b66c36ffcce42849dca2851cb44ca6', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_rel_linea_incidencia::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey], [id], [linea], [afectada_incidencia]) VALUES ('18059944-382A-49AA-A068-B55BF2FAC51F', 'BUSRELLININC01', '6', 'BUSINC01')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey], [id], [linea], [afectada_incidencia]) VALUES ('29059944-382A-49AA-A068-B55BF2FAC51F', 'BUSRELLININC02', '66', 'BUSINC02')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ([ikey], [id], [linea], [afectada_incidencia]) VALUES ('30059944-382A-49AA-A068-B55BF2FAC51F', 'BUSRELLININC03', '138', 'BUSINC03')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_rel_linea_incidencia', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 663, '7:4d19c18187767ed467ac03de8aadf0fa', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_route::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU01', '6a', N'Línea 6, comienzo en plaza de Jacinto Benavente y final en Orcasitas', 'outbound', '6')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU02', '66a', N'Línea 6, comienzo en Glorieta de Cuatro Caminos y final en Fuencarral', 'outbound', '66')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU03', '138a', N'Línea 138, comienzo en Cristo Rey y final en San Ignacio de Loyola', 'outbound', '138')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU6_I01_sentido_0', '6_I01_sentido_0', N'Marqués de Viana-Barrio Blanco', 'outbound', '11')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_route] ([ikey], [id], [description], [direction_type], [on_id]) VALUES ('BUSROU6_I01_sentido_1', '6_I01_sentido_1', N'Barrio Blanco-Marqués de Viana', 'outbound', '11')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_route', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 664, '7:29bf49395d3f39a5650255c0fad6a581', 'insert (x5)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_servicecalendar::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_servicecalendar] ([ikey], [id], [title], [description], [short_name], [from_day], [to_day]) VALUES ('BUSSERCAL01', '2020', 'Calendario de servicio de la EMT Madrid para 2020', 'Calendario de servicio de la EMT Madrid para 2020', 'Calendario Servicio EMT Madrid 2020', '2020-01-01T00:00:00.000', '2020-12-31T00:00:00.000')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_servicecalendar] ([ikey], [id], [title], [description], [short_name], [from_day], [to_day]) VALUES ('BUSSERCAL02', '2021', 'Calendario de servicio de la EMT Madrid para 2021', 'Calendario de servicio de la EMT Madrid para 2021', 'Calendario Servicio EMT Madrid 2021', '2021-01-01T00:00:00.000', '2021-12-31T00:00:00.000')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_servicecalendar', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 665, '7:3efa3259c661cb07def6c06987bcd5e0', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_stoppointinjourneypattern::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey], [id], [order_stop], [stop_use], [in_id], [viewed_as]) VALUES ('BUSSTOPOI01', '6a2-1918', 1, 'pass-through', '6a2', '138a1-4608')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey], [id], [order_stop], [stop_use], [in_id], [viewed_as]) VALUES ('BUSSTOPOI02', '66a2-3219', 1, 'pass-through', '66a2', '138a1-4618')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ([ikey], [id], [order_stop], [stop_use], [in_id], [viewed_as]) VALUES ('BUSSTOPOI03', '138a2-4608', 1, 'pass-through', '138a2', '138a1-4628')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_stoppointinjourneypattern', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 666, '7:d9ececf7fdcd3963b545a4f5605c3308', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_routePoint::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey], [id], [functional_centroid_for], [alighting], [boarding], [title_stop_area]) VALUES ('RPOINT01', '138a1-4608', '1918', 1, 0, 'Benavente')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey], [id], [functional_centroid_for], [alighting], [boarding], [title_stop_area]) VALUES ('RPOINT02', '138a1-4618', '3219', 1, 0, 'Cuatro Caminos')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([ikey], [id], [functional_centroid_for], [alighting], [boarding], [title_stop_area]) VALUES ('RPOINT03', '138a1-4628', '4608', 1, 0, 'Cristo Rey')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_routePoint', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 667, '7:91466fa3533b978edb640916f9669196', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::data-autobus_vehiclejourney::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey], [id], [journey_duration], [departure_time], [made_using], [worked_on], [composed_of], [direction_type]) VALUES ('BUSVEHJOU01', '6a1', 'P1D', '09:00:00', '6a2', 'laborable', '6a1-laborable', 'outbound')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey], [id], [journey_duration], [departure_time], [made_using], [worked_on], [composed_of], [direction_type]) VALUES ('BUSVEHJOU02', '66a1', 'P1D', '09:00:00', '66a2', 'laborable', '66a1-laborable', 'outbound')
GO

INSERT INTO [schema_ciudadesAbiertas].[bus_vehiclejourney] ([ikey], [id], [journey_duration], [departure_time], [made_using], [worked_on], [composed_of], [direction_type]) VALUES ('BUSVEHJOU03', '138a1', 'P1D', '09:00:00', '138a2', 'laborable', '138a1-laborable', 'outbound')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-autobus_vehiclejourney', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 668, '7:026d4b444ac5172ffbf92f616600cae2', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.26-AUTOBUS-data.xml::DATA-AUTOBUS-tag-1.26::Localidata
INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [TAG]) VALUES ('DATA-AUTOBUS-tag-1.26', 'Localidata', 'liquibase/db-changelog-script-1.26-AUTOBUS-data.xml', GETDATE(), 669, '7:054fad0894de536b5d021fba56482848', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.4.2', '1.26')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [bus_daytypassi_ibfk_1] FOREIGN KEY ([specifying]) REFERENCES [schema_ciudadesAbiertas].[bus_daytype] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-1', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 670, '7:69e34376045d65365eb3fdbfc52ef69a', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] ADD CONSTRAINT [bus_daytypeassi_ibfk_2] FOREIGN KEY ([for_the_definition_of]) REFERENCES [schema_ciudadesAbiertas].[bus_servicecalendar] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-2', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 671, '7:01675d9ccb07f36a2749353ffb827269', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ADD CONSTRAINT [bus_headjourgrou_ibfk_1] FOREIGN KEY ([determined_by]) REFERENCES [schema_ciudadesAbiertas].[bus_headwayinterval] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-3', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 672, '7:c29acdfce291840933335d39943e593b', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [bus_jourpatt_ibfk_1] FOREIGN KEY ([on_id]) REFERENCES [schema_ciudadesAbiertas].[bus_route] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-4', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 673, '7:0f13737ed84f4d349ced99307292f83f', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] ADD CONSTRAINT [bus_jourpatt_ibfk_2] FOREIGN KEY ([generado_por_incidencia]) REFERENCES [schema_ciudadesAbiertas].[bus_incidencia] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-5', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 674, '7:833509d71eae8265a8af5715b65f5ad2', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [bus_linea_ibfk_1] FOREIGN KEY ([operating]) REFERENCES [schema_ciudadesAbiertas].[bus_operator] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-6', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 675, '7:969639a99feb72475bb1bf32a6e722d5', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-7::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [bus_linea_ibfk_2] FOREIGN KEY ([cabecera_linea]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-7', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 676, '7:2633c5ed353f45b91cb3ac6bfee860e1', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-8::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] ADD CONSTRAINT [bus_linea_ibfk_3] FOREIGN KEY ([final_linea]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-8', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 677, '7:c76a3cabce9182f5c9a076c33f8c3177', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-9::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [bus_poinonrout_ibfk_1] FOREIGN KEY ([in_id]) REFERENCES [schema_ciudadesAbiertas].[bus_route] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-9', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 678, '7:4f75db24a45601fb7fce78f156a5a57b', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] ADD CONSTRAINT [bus_poinonrout_ibfk_2] FOREIGN KEY ([functional_centroid_for]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-10', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 679, '7:a62fa6bae106f171fe1b166eac1aa033', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-11::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] ADD CONSTRAINT [bus_realpasstime_ibfk_1] FOREIGN KEY ([has_feature_of_interest]) REFERENCES [schema_ciudadesAbiertas].[bus_pointonroute] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-11', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 680, '7:1aa313f084a1038b1cabc8156d46e691', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-13::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] ADD CONSTRAINT [bus_rel_line_inci_ibfk_2] FOREIGN KEY ([afectada_incidencia]) REFERENCES [schema_ciudadesAbiertas].[bus_incidencia] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-13', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 681, '7:2390acbe81581d53f111bb16ffc25930', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-14::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] ADD CONSTRAINT [bus_route_ibfk_1] FOREIGN KEY ([on_id]) REFERENCES [schema_ciudadesAbiertas].[bus_linea] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-14', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 682, '7:dd810168471fb1beb5b344e03b640261', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-15::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [bus_stoppoinjourpatt_ibfk_1] FOREIGN KEY ([in_id]) REFERENCES [schema_ciudadesAbiertas].[bus_journeypattern] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-15', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 683, '7:54d750ed28423c24e8660da5e2dd111d', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-16::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ADD CONSTRAINT [bus_stoppoinjourpatt_ibfk_2] FOREIGN KEY ([functional_centroid_for]) REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-16', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 684, '7:787710659c1157da832f2f0a4bbe1b4a', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-17::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [bus_vehijour_ibfk_1] FOREIGN KEY ([made_using]) REFERENCES [schema_ciudadesAbiertas].[bus_journeypattern] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-17', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 685, '7:bd0a634855adb7148cb5314aa8c7f733', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-18::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [bus_vehijour_ibfk_2] FOREIGN KEY ([worked_on]) REFERENCES [schema_ciudadesAbiertas].[bus_daytype] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-18', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 686, '7:5d840a289d91a8a288180f2b6d460a06', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-19::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] ADD CONSTRAINT [bus_vehijour_ibfk_3] FOREIGN KEY ([composed_of]) REFERENCES [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-19', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 687, '7:d7a2cb23ffaeaea1d822f78dc0da346f', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-20::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] ADD CONSTRAINT [bus_ope_ibfk_1] FOREIGN KEY ([serving_pt_for]) REFERENCES [schema_ciudadesAbiertas].[bus_authority] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-20', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 688, '7:977392c964835683788e57b141b8e109', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-21::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] ADD CONSTRAINT [bus_route_p_ibfk_1] FOREIGN KEY ([viewed_as]) REFERENCES [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bus-21', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 689, '7:b1556e49cfbf362a4b0f321e7ce8d6d2', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Release Database Lock
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 0, [LOCKEDBY] = NULL, [LOCKGRANTED] = NULL WHERE [ID] = 1
GO

