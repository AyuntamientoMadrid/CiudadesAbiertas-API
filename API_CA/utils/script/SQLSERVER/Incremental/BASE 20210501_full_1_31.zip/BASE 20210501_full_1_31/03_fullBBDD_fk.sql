ALTER TABLE [schema_ciudadesAbiertas].[agenda] ADD  CONSTRAINT [DF_agenda_accesible]  DEFAULT ((0)) FOR [accesible]
GO
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_evento] ADD  CONSTRAINT [DF_agenda_m_evento_reunion_lobby]  DEFAULT ((0)) FOR [reunion_lobby]
GO
ALTER TABLE [schema_ciudadesAbiertas].[alojamiento] ADD  CONSTRAINT [DF_alojamiento_accesible]  DEFAULT ((0)) FOR [accesible]
GO
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_observacion] ADD  CONSTRAINT [DF_calidad_aire_observacion_result_time]  DEFAULT (getdate()) FOR [result_time]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] ADD  CONSTRAINT [DF_cont_acus_observacion_validada]  DEFAULT ((0)) FOR [validada]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio] ADD  CONSTRAINT [DF_convenio_gestionado_por_organization]  DEFAULT ((0)) FOR [gestionado_por_organization]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio] ADD  CONSTRAINT [DF_convenio_gestionado_por_distrito]  DEFAULT ((0)) FOR [gestionado_por_distrito]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_prestamo] ADD  CONSTRAINT [DF_deuda_f_prestamo_diferidas_o_parciales_cap]  DEFAULT ((0)) FOR [diferidas_o_parciales_cap]
GO
ALTER TABLE [schema_ciudadesAbiertas].[equipamiento] ADD  CONSTRAINT [DF_equipamiento_titularidad_publica]  DEFAULT ((1)) FOR [titularidad_publica]
GO
ALTER TABLE [schema_ciudadesAbiertas].[oauth_approvals] ADD  CONSTRAINT [DF_oauth_approvals_expiresAt]  DEFAULT (getdate()) FOR [expiresAt]
GO
ALTER TABLE [schema_ciudadesAbiertas].[punto_interes_turistico] ADD  CONSTRAINT [DF_punto_interes_turistico_accesible]  DEFAULT ((0)) FOR [accesible]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria] ADD  CONSTRAINT [DF_subvencion_gestionado_por_organization]  DEFAULT ((0)) FOR [gestionado_por_organization]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria] ADD  CONSTRAINT [DF_subvencion_gestionado_por_distrito]  DEFAULT ((0)) FOR [gestionado_por_distrito]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_v1] ADD  CONSTRAINT [DF_subvencion_nominativa]  DEFAULT ((0)) FOR [nominativa]
GO
ALTER TABLE [schema_ciudadesAbiertas].[users] ADD  CONSTRAINT [DF_users_enabled]  DEFAULT ((1)) FOR [enabled]
GO
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_document]  WITH CHECK ADD  CONSTRAINT [fk_documento_to_evento] FOREIGN KEY([event_id])
REFERENCES [schema_ciudadesAbiertas].[agenda_m_evento] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_document] CHECK CONSTRAINT [fk_documento_to_evento]
GO
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_evento]  WITH CHECK ADD  CONSTRAINT [fk_evento_to_evento_super] FOREIGN KEY([super_event_id])
REFERENCES [schema_ciudadesAbiertas].[agenda_m_evento] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_evento] CHECK CONSTRAINT [fk_evento_to_evento_super]
GO
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_rolintegranteevento]  WITH CHECK ADD  CONSTRAINT [fk_rol_i_evento_to_evento] FOREIGN KEY([event_id])
REFERENCES [schema_ciudadesAbiertas].[agenda_m_evento] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_rolintegranteevento] CHECK CONSTRAINT [fk_rol_i_evento_to_evento]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_anclaje]  WITH CHECK ADD  CONSTRAINT [bibileta_anclaje_ibfk_1] FOREIGN KEY([estacion_bicicleta_id])
REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_anclaje] CHECK CONSTRAINT [bibileta_anclaje_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_observacion]  WITH CHECK ADD  CONSTRAINT [bicicleta_observacion_ibfk_1] FOREIGN KEY([made_by_sensor])
REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_observacion] CHECK CONSTRAINT [bicicleta_observacion_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso]  WITH CHECK ADD  CONSTRAINT [bicicleta_punto_de_paso_ibfk_1] FOREIGN KEY([trayecto_id])
REFERENCES [schema_ciudadesAbiertas].[bici_trayecto] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] CHECK CONSTRAINT [bicicleta_punto_de_paso_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto]  WITH CHECK ADD  CONSTRAINT [bicicleta_trayecto_ibfk_1] FOREIGN KEY([usuario_id])
REFERENCES [schema_ciudadesAbiertas].[bici_usuario] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] CHECK CONSTRAINT [bicicleta_trayecto_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto]  WITH CHECK ADD  CONSTRAINT [bicicleta_trayecto_ibfk_2] FOREIGN KEY([bicicleta_id])
REFERENCES [schema_ciudadesAbiertas].[bici_bicicleta] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] CHECK CONSTRAINT [bicicleta_trayecto_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto]  WITH CHECK ADD  CONSTRAINT [bicicleta_trayecto_ibfk_3] FOREIGN KEY([estacion_bicicleta_origen_id])
REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] CHECK CONSTRAINT [bicicleta_trayecto_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto]  WITH CHECK ADD  CONSTRAINT [bicicleta_trayecto_ibfk_4] FOREIGN KEY([estacion_bicicleta_destino_id])
REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] CHECK CONSTRAINT [bicicleta_trayecto_ibfk_4]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto]  WITH CHECK ADD  CONSTRAINT [bicicleta_trayecto_ibfk_5] FOREIGN KEY([anclaje_origen_id])
REFERENCES [schema_ciudadesAbiertas].[bici_anclaje] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] CHECK CONSTRAINT [bicicleta_trayecto_ibfk_5]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto]  WITH CHECK ADD  CONSTRAINT [bicicleta_trayecto_ibfk_6] FOREIGN KEY([anclaje_destino_id])
REFERENCES [schema_ciudadesAbiertas].[bici_anclaje] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] CHECK CONSTRAINT [bicicleta_trayecto_ibfk_6]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment]  WITH CHECK ADD  CONSTRAINT [bus_daytypassi_ibfk_1] FOREIGN KEY([specifying])
REFERENCES [schema_ciudadesAbiertas].[bus_daytype] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] CHECK CONSTRAINT [bus_daytypassi_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment]  WITH CHECK ADD  CONSTRAINT [bus_daytypeassi_ibfk_2] FOREIGN KEY([for_the_definition_of])
REFERENCES [schema_ciudadesAbiertas].[bus_servicecalendar] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] CHECK CONSTRAINT [bus_daytypeassi_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup]  WITH CHECK ADD  CONSTRAINT [bus_headjourgrou_ibfk_1] FOREIGN KEY([determined_by])
REFERENCES [schema_ciudadesAbiertas].[bus_headwayinterval] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] CHECK CONSTRAINT [bus_headjourgrou_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern]  WITH CHECK ADD  CONSTRAINT [bus_jourpatt_ibfk_1] FOREIGN KEY([on_id])
REFERENCES [schema_ciudadesAbiertas].[bus_route] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] CHECK CONSTRAINT [bus_jourpatt_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern]  WITH CHECK ADD  CONSTRAINT [bus_jourpatt_ibfk_2] FOREIGN KEY([generado_por_incidencia])
REFERENCES [schema_ciudadesAbiertas].[bus_incidencia] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] CHECK CONSTRAINT [bus_jourpatt_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea]  WITH CHECK ADD  CONSTRAINT [bus_linea_ibfk_1] FOREIGN KEY([operating])
REFERENCES [schema_ciudadesAbiertas].[bus_operator] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] CHECK CONSTRAINT [bus_linea_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea]  WITH CHECK ADD  CONSTRAINT [bus_linea_ibfk_2] FOREIGN KEY([cabecera_linea])
REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] CHECK CONSTRAINT [bus_linea_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea]  WITH CHECK ADD  CONSTRAINT [bus_linea_ibfk_3] FOREIGN KEY([final_linea])
REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] CHECK CONSTRAINT [bus_linea_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator]  WITH CHECK ADD  CONSTRAINT [bus_ope_ibfk_1] FOREIGN KEY([serving_pt_for])
REFERENCES [schema_ciudadesAbiertas].[bus_authority] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] CHECK CONSTRAINT [bus_ope_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute]  WITH CHECK ADD  CONSTRAINT [bus_poinonrout_ibfk_1] FOREIGN KEY([in_id])
REFERENCES [schema_ciudadesAbiertas].[bus_route] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] CHECK CONSTRAINT [bus_poinonrout_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute]  WITH CHECK ADD  CONSTRAINT [bus_poinonrout_ibfk_2] FOREIGN KEY([functional_centroid_for])
REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] CHECK CONSTRAINT [bus_poinonrout_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time]  WITH CHECK ADD  CONSTRAINT [bus_realpasstime_ibfk_1] FOREIGN KEY([has_feature_of_interest])
REFERENCES [schema_ciudadesAbiertas].[bus_pointonroute] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] CHECK CONSTRAINT [bus_realpasstime_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia]  WITH CHECK ADD  CONSTRAINT [bus_rel_line_inci_ibfk_2] FOREIGN KEY([afectada_incidencia])
REFERENCES [schema_ciudadesAbiertas].[bus_incidencia] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] CHECK CONSTRAINT [bus_rel_line_inci_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_route]  WITH CHECK ADD  CONSTRAINT [bus_route_ibfk_1] FOREIGN KEY([on_id])
REFERENCES [schema_ciudadesAbiertas].[bus_linea] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] CHECK CONSTRAINT [bus_route_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point]  WITH CHECK ADD  CONSTRAINT [bus_stoppoinjourpatt_ibfk_2] FOREIGN KEY([functional_centroid_for])
REFERENCES [schema_ciudadesAbiertas].[bus_parada] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] CHECK CONSTRAINT [bus_stoppoinjourpatt_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern]  WITH CHECK ADD  CONSTRAINT [bus_route_p_ibfk_1] FOREIGN KEY([viewed_as])
REFERENCES [schema_ciudadesAbiertas].[bus_scheduled_stop_point] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] CHECK CONSTRAINT [bus_route_p_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern]  WITH CHECK ADD  CONSTRAINT [bus_stoppoinjourpatt_ibfk_1] FOREIGN KEY([in_id])
REFERENCES [schema_ciudadesAbiertas].[bus_journeypattern] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] CHECK CONSTRAINT [bus_stoppoinjourpatt_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney]  WITH CHECK ADD  CONSTRAINT [bus_vehijour_ibfk_1] FOREIGN KEY([made_using])
REFERENCES [schema_ciudadesAbiertas].[bus_journeypattern] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] CHECK CONSTRAINT [bus_vehijour_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney]  WITH CHECK ADD  CONSTRAINT [bus_vehijour_ibfk_2] FOREIGN KEY([worked_on])
REFERENCES [schema_ciudadesAbiertas].[bus_daytype] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] CHECK CONSTRAINT [bus_vehijour_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney]  WITH CHECK ADD  CONSTRAINT [bus_vehijour_ibfk_3] FOREIGN KEY([composed_of])
REFERENCES [schema_ciudadesAbiertas].[bus_headwayjourneygroup] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] CHECK CONSTRAINT [bus_vehijour_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_observacion]  WITH CHECK ADD  CONSTRAINT [fk_estacion] FOREIGN KEY([made_by_sensor])
REFERENCES [schema_ciudadesAbiertas].[calidad_aire_estacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_observacion] CHECK CONSTRAINT [fk_estacion]
GO
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_sensor]  WITH CHECK ADD  CONSTRAINT [fk_estacion_sensor] FOREIGN KEY([is_hosted_by])
REFERENCES [schema_ciudadesAbiertas].[calidad_aire_estacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_sensor] CHECK CONSTRAINT [fk_estacion_sensor]
GO
ALTER TABLE [schema_ciudadesAbiertas].[callejero_portal]  WITH CHECK ADD  CONSTRAINT [callejero_portal_ibfk_1] FOREIGN KEY([via])
REFERENCES [schema_ciudadesAbiertas].[callejero_via] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[callejero_portal] CHECK CONSTRAINT [callejero_portal_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[callejero_tramo_via]  WITH CHECK ADD  CONSTRAINT [callejero_tramo_via_ibfk_1] FOREIGN KEY([via])
REFERENCES [schema_ciudadesAbiertas].[callejero_via] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[callejero_tramo_via] CHECK CONSTRAINT [callejero_tramo_via_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_estacion_medida]  WITH CHECK ADD  CONSTRAINT [cont_acustica_ibfk_1] FOREIGN KEY([observes])
REFERENCES [schema_ciudadesAbiertas].[cont_acus_propiedad] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_estacion_medida] CHECK CONSTRAINT [cont_acustica_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion]  WITH CHECK ADD  CONSTRAINT [cont_acustica_ibfk_2] FOREIGN KEY([made_by_sensor])
REFERENCES [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] CHECK CONSTRAINT [cont_acustica_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion]  WITH CHECK ADD  CONSTRAINT [cont_acustica_ibfk_3] FOREIGN KEY([observed_property])
REFERENCES [schema_ciudadesAbiertas].[cont_acus_propiedad] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] CHECK CONSTRAINT [cont_acustica_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_award]  WITH CHECK ADD  CONSTRAINT [contratos_award_ibfk_1] FOREIGN KEY([is_supplier_for])
REFERENCES [schema_ciudadesAbiertas].[contratos_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_award] CHECK CONSTRAINT [contratos_award_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot]  WITH CHECK ADD  CONSTRAINT [contratos_lot_ibfk_1] FOREIGN KEY([tender_id])
REFERENCES [schema_ciudadesAbiertas].[contratos_tender] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] CHECK CONSTRAINT [contratos_lot_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot]  WITH CHECK ADD  CONSTRAINT [contratos_lot_ibfk_2] FOREIGN KEY([has_supplier])
REFERENCES [schema_ciudadesAbiertas].[contratos_award] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] CHECK CONSTRAINT [contratos_lot_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item]  WITH CHECK ADD  CONSTRAINT [contratos_lot_rel_item_ibfk_1] FOREIGN KEY([lot_id])
REFERENCES [schema_ciudadesAbiertas].[contratos_lot] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] CHECK CONSTRAINT [contratos_lot_rel_item_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item]  WITH CHECK ADD  CONSTRAINT [contratos_lot_rel_item_ibfk_2] FOREIGN KEY([item_id])
REFERENCES [schema_ciudadesAbiertas].[contratos_item] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] CHECK CONSTRAINT [contratos_lot_rel_item_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process]  WITH CHECK ADD  CONSTRAINT [contratos_process_ibfk_1] FOREIGN KEY([has_tender])
REFERENCES [schema_ciudadesAbiertas].[contratos_tender] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] CHECK CONSTRAINT [contratos_process_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process]  WITH CHECK ADD  CONSTRAINT [contratos_process_ibfk_2] FOREIGN KEY([is_buyer_for])
REFERENCES [schema_ciudadesAbiertas].[contratos_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] CHECK CONSTRAINT [contratos_process_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender]  WITH CHECK ADD  CONSTRAINT [contratos_tender_ibfk_1] FOREIGN KEY([has_supplier])
REFERENCES [schema_ciudadesAbiertas].[contratos_award] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender] CHECK CONSTRAINT [contratos_tender_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item]  WITH CHECK ADD  CONSTRAINT [cont_tender_r_item_ibfk_1] FOREIGN KEY([tender_id])
REFERENCES [schema_ciudadesAbiertas].[contratos_tender] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] CHECK CONSTRAINT [cont_tender_r_item_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item]  WITH CHECK ADD  CONSTRAINT [cont_tender_r_item_ibfk_2] FOREIGN KEY([item_id])
REFERENCES [schema_ciudadesAbiertas].[contratos_item] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] CHECK CONSTRAINT [cont_tender_r_item_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto]  WITH CHECK ADD  CONSTRAINT [fk_con_rel_firma_ayto_id] FOREIGN KEY([convenio_id])
REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] CHECK CONSTRAINT [fk_con_rel_firma_ayto_id]
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto]  WITH CHECK ADD  CONSTRAINT [fk_con_rel_firma_ayto_org] FOREIGN KEY([organization_id])
REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] CHECK CONSTRAINT [fk_con_rel_firma_ayto_org]
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad]  WITH CHECK ADD  CONSTRAINT [fk_con_rel_firma_ent_id] FOREIGN KEY([entidad_id])
REFERENCES [schema_ciudadesAbiertas].[convenio_susc_entidad] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] CHECK CONSTRAINT [fk_con_rel_firma_ent_id]
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad]  WITH CHECK ADD  CONSTRAINT [fk_con_rel_firma_ent_org] FOREIGN KEY([organization_id])
REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] CHECK CONSTRAINT [fk_con_rel_firma_ent_org]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio]  WITH CHECK ADD  CONSTRAINT [fk_convenio_org] FOREIGN KEY([organization_id])
REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio] CHECK CONSTRAINT [fk_convenio_org]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio]  WITH CHECK ADD  CONSTRAINT [fk_convenio_org_obliga] FOREIGN KEY([org_id_obligado_presta])
REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio] CHECK CONSTRAINT [fk_convenio_org_obliga]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio]  WITH CHECK ADD  CONSTRAINT [fk_convenio_prorroga] FOREIGN KEY([es_variacion_id])
REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio] CHECK CONSTRAINT [fk_convenio_prorroga]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio_documentacion]  WITH CHECK ADD  CONSTRAINT [fk_convenio_doc_id] FOREIGN KEY([convenio_id])
REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio_documentacion] CHECK CONSTRAINT [fk_convenio_doc_id]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad]  WITH CHECK ADD  CONSTRAINT [fk_convenio_susc_entidad_id] FOREIGN KEY([convenio_id])
REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] CHECK CONSTRAINT [fk_convenio_susc_entidad_id]
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad]  WITH CHECK ADD  CONSTRAINT [fk_convenio_susc_org_id] FOREIGN KEY([organization_id])
REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] CHECK CONSTRAINT [fk_convenio_susc_org_id]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_dimension_value]  WITH CHECK ADD  CONSTRAINT [dsd_dim_value_ibfk_1] FOREIGN KEY([dimension_key])
REFERENCES [schema_ciudadesAbiertas].[cube_dsd_dimension] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_dimension_value] CHECK CONSTRAINT [dsd_dim_value_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension]  WITH CHECK ADD  CONSTRAINT [cube_dsd_rel_dim_ibfk_1] FOREIGN KEY([cube_key])
REFERENCES [schema_ciudadesAbiertas].[cube_dsd] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] CHECK CONSTRAINT [cube_dsd_rel_dim_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension]  WITH CHECK ADD  CONSTRAINT [dsd_rel_dim_ibfk_2] FOREIGN KEY([dimension_key])
REFERENCES [schema_ciudadesAbiertas].[cube_dsd_dimension] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] CHECK CONSTRAINT [dsd_rel_dim_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure]  WITH CHECK ADD  CONSTRAINT [cube_dsd_rel_mea_ibfk_1] FOREIGN KEY([cube_key])
REFERENCES [schema_ciudadesAbiertas].[cube_dsd] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] CHECK CONSTRAINT [cube_dsd_rel_mea_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure]  WITH CHECK ADD  CONSTRAINT [cube_dsd_rel_mea_ibfk_2] FOREIGN KEY([measure_key])
REFERENCES [schema_ciudadesAbiertas].[cube_dsd_measure] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] CHECK CONSTRAINT [cube_dsd_rel_mea_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_morosidad_tri]  WITH CHECK ADD  CONSTRAINT [deudac_morosidad_tri_ibfk_1] FOREIGN KEY([entidad])
REFERENCES [schema_ciudadesAbiertas].[deuda_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_morosidad_tri] CHECK CONSTRAINT [deudac_morosidad_tri_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_morosidad_tri]  WITH CHECK ADD  CONSTRAINT [deudac_morosidad_tri_ibfk_2] FOREIGN KEY([periodo])
REFERENCES [schema_ciudadesAbiertas].[deuda_c_publica_interval] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_morosidad_tri] CHECK CONSTRAINT [deudac_morosidad_tri_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_pmp_mes]  WITH CHECK ADD  CONSTRAINT [deudac_inf_mes_ibfk_4] FOREIGN KEY([entidad])
REFERENCES [schema_ciudadesAbiertas].[deuda_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_pmp_mes] CHECK CONSTRAINT [deudac_inf_mes_ibfk_4]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_pmp_mes]  WITH CHECK ADD  CONSTRAINT [deudac_inf_mes_ibfk_5] FOREIGN KEY([periodo])
REFERENCES [schema_ciudadesAbiertas].[deuda_c_publica_interval] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_pmp_mes] CHECK CONSTRAINT [deudac_inf_mes_ibfk_5]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_pmp_mes_global]  WITH CHECK ADD  CONSTRAINT [deudac_inf_global_ibfk_3] FOREIGN KEY([periodo])
REFERENCES [schema_ciudadesAbiertas].[deuda_c_publica_interval] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_c_inf_pmp_mes_global] CHECK CONSTRAINT [deudac_inf_global_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_amortizacion]  WITH CHECK ADD  CONSTRAINT [deuda_f_amortizacion_ibfk_4] FOREIGN KEY([instrumenta_financiacion])
REFERENCES [schema_ciudadesAbiertas].[deuda_f_inst_financiacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_amortizacion] CHECK CONSTRAINT [deuda_f_amortizacion_ibfk_4]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_capital_vivo]  WITH CHECK ADD  CONSTRAINT [deuda_f_capital_vivo_ibfk_5] FOREIGN KEY([instrumenta_financiacion])
REFERENCES [schema_ciudadesAbiertas].[deuda_f_inst_financiacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_capital_vivo] CHECK CONSTRAINT [deuda_f_capital_vivo_ibfk_5]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_carga_financiera]  WITH CHECK ADD  CONSTRAINT [d_f_carga_financiera_ibfk_6] FOREIGN KEY([instrumenta_financiacion])
REFERENCES [schema_ciudadesAbiertas].[deuda_f_inst_financiacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_carga_financiera] CHECK CONSTRAINT [d_f_carga_financiera_ibfk_6]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_inst_financiacion]  WITH CHECK ADD  CONSTRAINT [d_f_inst_financiacion_ibfk_7] FOREIGN KEY([prestamo])
REFERENCES [schema_ciudadesAbiertas].[deuda_f_prestamo] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_inst_financiacion] CHECK CONSTRAINT [d_f_inst_financiacion_ibfk_7]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_inst_financiacion]  WITH CHECK ADD  CONSTRAINT [d_f_inst_financiacion_ibfk_8] FOREIGN KEY([emision])
REFERENCES [schema_ciudadesAbiertas].[deuda_f_emision] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_inst_financiacion] CHECK CONSTRAINT [d_f_inst_financiacion_ibfk_8]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_inst_financiacion]  WITH CHECK ADD  CONSTRAINT [deuda_f_inst_fin_ibfk_1] FOREIGN KEY([deuda_anual])
REFERENCES [schema_ciudadesAbiertas].[deuda_f_anual] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_inst_financiacion] CHECK CONSTRAINT [deuda_f_inst_fin_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_rel_prestamo_entidad]  WITH CHECK ADD  CONSTRAINT [d_f_rel_prestamo_ent_ibfk_2] FOREIGN KEY([prestamo_id])
REFERENCES [schema_ciudadesAbiertas].[deuda_f_prestamo] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_rel_prestamo_entidad] CHECK CONSTRAINT [d_f_rel_prestamo_ent_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_rel_prestamo_entidad]  WITH CHECK ADD  CONSTRAINT [d_f_rel_prestamo_ent_ibfk_3] FOREIGN KEY([entidad_prestamista])
REFERENCES [schema_ciudadesAbiertas].[deuda_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[deuda_f_rel_prestamo_entidad] CHECK CONSTRAINT [d_f_rel_prestamo_ent_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_oferta_publica]  WITH CHECK ADD  CONSTRAINT [empleo_oferta_publica_ibfk_1] FOREIGN KEY([boletin_oficial_id])
REFERENCES [schema_ciudadesAbiertas].[empleo_boletin_oficial] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_oferta_publica] CHECK CONSTRAINT [empleo_oferta_publica_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_plaza_turno]  WITH CHECK ADD  CONSTRAINT [empleo_plaza_turno_ibfk_1] FOREIGN KEY([convocatoria_id])
REFERENCES [schema_ciudadesAbiertas].[empleo_convocatoria_publica] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_plaza_turno] CHECK CONSTRAINT [empleo_plaza_turno_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_boletin_convoca]  WITH CHECK ADD  CONSTRAINT [empleo_rel_bole_conv_ibfk_1] FOREIGN KEY([boletin_id])
REFERENCES [schema_ciudadesAbiertas].[empleo_boletin_oficial] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_boletin_convoca] CHECK CONSTRAINT [empleo_rel_bole_conv_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_boletin_convoca]  WITH CHECK ADD  CONSTRAINT [empleo_rel_bole_conv_ibfk_2] FOREIGN KEY([convocatoria_id])
REFERENCES [schema_ciudadesAbiertas].[empleo_convocatoria_publica] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_boletin_convoca] CHECK CONSTRAINT [empleo_rel_bole_conv_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_oferta_convoca]  WITH CHECK ADD  CONSTRAINT [empleo_rel_ofer_conv_ibfk_1] FOREIGN KEY([oferta_id])
REFERENCES [schema_ciudadesAbiertas].[empleo_oferta_publica] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_oferta_convoca] CHECK CONSTRAINT [empleo_rel_ofer_conv_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_oferta_convoca]  WITH CHECK ADD  CONSTRAINT [empleo_rel_ofer_conv_ibfk_2] FOREIGN KEY([convocatoria_id])
REFERENCES [schema_ciudadesAbiertas].[empleo_convocatoria_publica] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[empleo_rel_oferta_convoca] CHECK CONSTRAINT [empleo_rel_ofer_conv_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[group_authorities]  WITH CHECK ADD  CONSTRAINT [fk_group_authori_users] FOREIGN KEY([group_id])
REFERENCES [schema_ciudadesAbiertas].[groups] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[group_authorities] CHECK CONSTRAINT [fk_group_authori_users]
GO
ALTER TABLE [schema_ciudadesAbiertas].[group_members]  WITH CHECK ADD  CONSTRAINT [fk_group_memebers_groups] FOREIGN KEY([group_id])
REFERENCES [schema_ciudadesAbiertas].[groups] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[group_members] CHECK CONSTRAINT [fk_group_memebers_groups]
GO
ALTER TABLE [schema_ciudadesAbiertas].[group_members]  WITH CHECK ADD  CONSTRAINT [fk_group_memebers_users] FOREIGN KEY([username])
REFERENCES [schema_ciudadesAbiertas].[users] ([username])
GO
ALTER TABLE [schema_ciudadesAbiertas].[group_members] CHECK CONSTRAINT [fk_group_memebers_users]
GO
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial]  WITH CHECK ADD  CONSTRAINT [fk_local_comercial_agrupacion] FOREIGN KEY([agrupacion_comercial])
REFERENCES [schema_ciudadesAbiertas].[local_comercial_agrupacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] CHECK CONSTRAINT [fk_local_comercial_agrupacion]
GO
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial]  WITH CHECK ADD  CONSTRAINT [fk_local_comercial_licencia] FOREIGN KEY([tiene_licencia_apertura])
REFERENCES [schema_ciudadesAbiertas].[local_comercial_licencia] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] CHECK CONSTRAINT [fk_local_comercial_licencia]
GO
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial]  WITH CHECK ADD  CONSTRAINT [fk_local_comercial_terraza] FOREIGN KEY([tiene_terraza])
REFERENCES [schema_ciudadesAbiertas].[local_comercial_terraza] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] CHECK CONSTRAINT [fk_local_comercial_terraza]
GO
ALTER TABLE [schema_ciudadesAbiertas].[organigrama]  WITH CHECK ADD  CONSTRAINT [fk_unidad_raiz] FOREIGN KEY([unidad_raiz])
REFERENCES [schema_ciudadesAbiertas].[organigrama] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] CHECK CONSTRAINT [fk_unidad_raiz]
GO
ALTER TABLE [schema_ciudadesAbiertas].[organigrama]  WITH CHECK ADD  CONSTRAINT [fk_unit_of] FOREIGN KEY([unit_of])
REFERENCES [schema_ciudadesAbiertas].[organigrama] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] CHECK CONSTRAINT [fk_unit_of]
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto]  WITH CHECK ADD  CONSTRAINT [presupuesto_liquidacion_ibfk_1] FOREIGN KEY([liquidacion])
REFERENCES [schema_ciudadesAbiertas].[presupuesto_liquidacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto] CHECK CONSTRAINT [presupuesto_liquidacion_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_gasto]  WITH CHECK ADD  CONSTRAINT [pres_ejecucion_gasto_ibfk_1] FOREIGN KEY([presupuesto_gasto])
REFERENCES [schema_ciudadesAbiertas].[presupuesto_gasto] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_gasto] CHECK CONSTRAINT [pres_ejecucion_gasto_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_ingreso]  WITH CHECK ADD  CONSTRAINT [pres_ejecucion_ingreso_ibfk_1] FOREIGN KEY([presupuesto_ingreso])
REFERENCES [schema_ciudadesAbiertas].[presupuesto_ingreso] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_ingreso] CHECK CONSTRAINT [pres_ejecucion_ingreso_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_gasto]  WITH CHECK ADD  CONSTRAINT [presupuesto_gasto_ibfk_1] FOREIGN KEY([presupuesto])
REFERENCES [schema_ciudadesAbiertas].[presupuesto] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_gasto] CHECK CONSTRAINT [presupuesto_gasto_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ingreso]  WITH CHECK ADD  CONSTRAINT [presupuesto_ingreso_ibfk_1] FOREIGN KEY([presupuesto])
REFERENCES [schema_ciudadesAbiertas].[presupuesto] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ingreso] CHECK CONSTRAINT [presupuesto_ingreso_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_concesion]  WITH CHECK ADD  CONSTRAINT [subvencion_beneficiario_ibfk_1] FOREIGN KEY([beneficiario])
REFERENCES [schema_ciudadesAbiertas].[subvencion_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_concesion] CHECK CONSTRAINT [subvencion_beneficiario_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_concesion]  WITH CHECK ADD  CONSTRAINT [subvencion_beneficiario_ibfk_2] FOREIGN KEY([convocatoria])
REFERENCES [schema_ciudadesAbiertas].[subvencion_convocatoria] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_concesion] CHECK CONSTRAINT [subvencion_beneficiario_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria]  WITH CHECK ADD  CONSTRAINT [subvencion_ibfk_1] FOREIGN KEY([area_id])
REFERENCES [schema_ciudadesAbiertas].[subvencion_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria] CHECK CONSTRAINT [subvencion_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria]  WITH CHECK ADD  CONSTRAINT [subvencion_ibfk_2] FOREIGN KEY([entidad_financiadora_id])
REFERENCES [schema_ciudadesAbiertas].[subvencion_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria] CHECK CONSTRAINT [subvencion_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria]  WITH CHECK ADD  CONSTRAINT [subvencion_ibfk_3] FOREIGN KEY([servicio_id])
REFERENCES [schema_ciudadesAbiertas].[subvencion_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria] CHECK CONSTRAINT [subvencion_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria]  WITH CHECK ADD  CONSTRAINT [subvencion_ibfk_5] FOREIGN KEY([organization_id])
REFERENCES [schema_ciudadesAbiertas].[subvencion_organization] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[subvencion_convocatoria] CHECK CONSTRAINT [subvencion_ibfk_5]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_autonomia]  WITH CHECK ADD  CONSTRAINT [t_autonomia_ibfk_1] FOREIGN KEY([pais])
REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_autonomia] CHECK CONSTRAINT [t_autonomia_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio]  WITH CHECK ADD  CONSTRAINT [t_barrio_ibfk_1] FOREIGN KEY([pais])
REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] CHECK CONSTRAINT [t_barrio_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio]  WITH CHECK ADD  CONSTRAINT [t_barrio_ibfk_2] FOREIGN KEY([autonomia])
REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] CHECK CONSTRAINT [t_barrio_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio]  WITH CHECK ADD  CONSTRAINT [t_barrio_ibfk_3] FOREIGN KEY([provincia])
REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] CHECK CONSTRAINT [t_barrio_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio]  WITH CHECK ADD  CONSTRAINT [t_barrio_ibfk_4] FOREIGN KEY([municipio])
REFERENCES [schema_ciudadesAbiertas].[territorio_municipio] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] CHECK CONSTRAINT [t_barrio_ibfk_4]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio]  WITH CHECK ADD  CONSTRAINT [t_barrio_ibfk_5] FOREIGN KEY([distrito])
REFERENCES [schema_ciudadesAbiertas].[territorio_distrito] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] CHECK CONSTRAINT [t_barrio_ibfk_5]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito]  WITH CHECK ADD  CONSTRAINT [t_distrito_ibfk_1] FOREIGN KEY([pais])
REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] CHECK CONSTRAINT [t_distrito_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito]  WITH CHECK ADD  CONSTRAINT [t_distrito_ibfk_2] FOREIGN KEY([autonomia])
REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] CHECK CONSTRAINT [t_distrito_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito]  WITH CHECK ADD  CONSTRAINT [t_distrito_ibfk_3] FOREIGN KEY([provincia])
REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] CHECK CONSTRAINT [t_distrito_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito]  WITH CHECK ADD  CONSTRAINT [t_distrito_ibfk_4] FOREIGN KEY([municipio])
REFERENCES [schema_ciudadesAbiertas].[territorio_municipio] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] CHECK CONSTRAINT [t_distrito_ibfk_4]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio]  WITH CHECK ADD  CONSTRAINT [t_municipio_ibfk_1] FOREIGN KEY([pais])
REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] CHECK CONSTRAINT [t_municipio_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio]  WITH CHECK ADD  CONSTRAINT [t_municipio_ibfk_2] FOREIGN KEY([autonomia])
REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] CHECK CONSTRAINT [t_municipio_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio]  WITH CHECK ADD  CONSTRAINT [t_municipio_ibfk_3] FOREIGN KEY([provincia])
REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] CHECK CONSTRAINT [t_municipio_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia]  WITH CHECK ADD  CONSTRAINT [t_provincia_ibfk_1] FOREIGN KEY([pais])
REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] CHECK CONSTRAINT [t_provincia_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia]  WITH CHECK ADD  CONSTRAINT [t_provincia_ibfk_2] FOREIGN KEY([autonomia])
REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] CHECK CONSTRAINT [t_provincia_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion]  WITH CHECK ADD  CONSTRAINT [t_seccion_ibfk_1] FOREIGN KEY([pais])
REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] CHECK CONSTRAINT [t_seccion_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion]  WITH CHECK ADD  CONSTRAINT [t_seccion_ibfk_2] FOREIGN KEY([autonomia])
REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] CHECK CONSTRAINT [t_seccion_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion]  WITH CHECK ADD  CONSTRAINT [t_seccion_ibfk_3] FOREIGN KEY([provincia])
REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] CHECK CONSTRAINT [t_seccion_ibfk_3]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion]  WITH CHECK ADD  CONSTRAINT [t_seccion_ibfk_4] FOREIGN KEY([municipio])
REFERENCES [schema_ciudadesAbiertas].[territorio_municipio] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] CHECK CONSTRAINT [t_seccion_ibfk_4]
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion]  WITH CHECK ADD  CONSTRAINT [t_seccion_ibfk_5] FOREIGN KEY([distrito])
REFERENCES [schema_ciudadesAbiertas].[territorio_distrito] ([ikey])
GO
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] CHECK CONSTRAINT [t_seccion_ibfk_5]
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion]  WITH CHECK ADD  CONSTRAINT [traf_disp_medicion_ibfk_1] FOREIGN KEY([monitorea])
REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] CHECK CONSTRAINT [traf_disp_medicion_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_equipo]  WITH CHECK ADD  CONSTRAINT [traf_equipo_ibfk_1] FOREIGN KEY([monitorea])
REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_equipo] CHECK CONSTRAINT [traf_equipo_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia]  WITH CHECK ADD  CONSTRAINT [trafico_incidencia_ibfk_1] FOREIGN KEY([incidencia_tramo])
REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] CHECK CONSTRAINT [trafico_incidencia_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion]  WITH CHECK ADD  CONSTRAINT [trafico_observacion_ibfk_1] FOREIGN KEY([has_feature_interest])
REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] CHECK CONSTRAINT [trafico_observacion_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp]  WITH CHECK ADD  CONSTRAINT [traf_obse_dispostivo_ibfk_1] FOREIGN KEY([id_observacion])
REFERENCES [schema_ciudadesAbiertas].[trafico_observacion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp] CHECK CONSTRAINT [traf_obse_dispostivo_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp]  WITH CHECK ADD  CONSTRAINT [traf_obse_dispostivo_ibfk_2] FOREIGN KEY([made_by_sensor])
REFERENCES [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp] CHECK CONSTRAINT [traf_obse_dispostivo_ibfk_2]
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via]  WITH CHECK ADD  CONSTRAINT [trafico_tramo_via_ibfk_1] FOREIGN KEY([id_tramo])
REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] CHECK CONSTRAINT [trafico_tramo_via_ibfk_1]
GO
ALTER TABLE [schema_ciudadesAbiertas].[user_roles]  WITH CHECK ADD  CONSTRAINT [fk_user_role_username] FOREIGN KEY([username])
REFERENCES [schema_ciudadesAbiertas].[users] ([username])
GO
ALTER TABLE [schema_ciudadesAbiertas].[user_roles] CHECK CONSTRAINT [fk_user_role_username]
GO