-- *********************************************************************
-- Rollback to '1.28' Script
-- *********************************************************************
-- Change Log: liquibase/db-changelog-master.xml
-- Ran at: 23/12/20 12:07
-- Against: ciudadesAbiertas@jdbc:sqlserver://localhost:1433;useBulkCopyForBatchInsert=false;cancelQueryTimeout=-1;sslProtocol=TLS;jaasConfigurationName=SQLJDBCDriver;statementPoolingCacheSize=0;serverPreparedStatementDiscardThreshold=10;enablePrepareOnFirstPreparedStatementCall=false;fips=false;socketTimeout=0;authentication=NotSpecified;authenticationScheme=nativeAuthentication;xopenStates=false;sendTimeAsDatetime=true;trustStoreType=JKS;trustServerCertificate=false;TransparentNetworkIPResolution=true;serverNameAsACE=false;sendStringParametersAsUnicode=true;selectMethod=direct;responseBuffering=adaptive;queryTimeout=-1;packetSize=8000;multiSubnetFailover=false;loginTimeout=15;lockTimeout=-1;lastUpdateCount=true;encrypt=false;disableStatementPooling=true;databaseName=ciudadesAbiertas;columnEncryptionSetting=Disabled;applicationName=Microsoft JDBC Driver for SQL Server;applicationIntent=readwrite;
-- Liquibase version: 3.4.2
-- *********************************************************************

USE [bbdd_ciudadesAbiertas];
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-21::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] DROP CONSTRAINT [bus_route_p_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-20::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_operator] DROP CONSTRAINT [bus_ope_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-19::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] DROP CONSTRAINT [bus_vehijour_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-19' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-18::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] DROP CONSTRAINT [bus_vehijour_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-18' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-17::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_vehiclejourney] DROP CONSTRAINT [bus_vehijour_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-17' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-16::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_scheduled_stop_point] DROP CONSTRAINT [bus_stoppoinjourpatt_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-15::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_stoppointinjourneypattern] DROP CONSTRAINT [bus_stoppoinjourpatt_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-14::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_route] DROP CONSTRAINT [bus_route_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-13::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_rel_linea_incidencia] DROP CONSTRAINT [bus_rel_line_inci_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-11::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_realtime_passing_time] DROP CONSTRAINT [bus_realpasstime_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] DROP CONSTRAINT [bus_poinonrout_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-9::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_pointonroute] DROP CONSTRAINT [bus_poinonrout_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-8::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] DROP CONSTRAINT [bus_linea_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-7::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] DROP CONSTRAINT [bus_linea_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_linea] DROP CONSTRAINT [bus_linea_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] DROP CONSTRAINT [bus_jourpatt_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_journeypattern] DROP CONSTRAINT [bus_jourpatt_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_headwayjourneygroup] DROP CONSTRAINT [bus_headjourgrou_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] DROP CONSTRAINT [bus_daytypeassi_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bus-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bus_daytypeassignment] DROP CONSTRAINT [bus_daytypassi_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bus-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-cont_acustica-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] DROP CONSTRAINT [cont_acustica_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-cont_acustica-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-cont_acustica-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] DROP CONSTRAINT [cont_acustica_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-cont_acustica-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-cont_acustica-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_estacion_medida] DROP CONSTRAINT [cont_acustica_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-cont_acustica-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] DROP CONSTRAINT [trafico_tramo_via_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp] DROP CONSTRAINT [traf_obse_dispostivo_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp] DROP CONSTRAINT [traf_obse_dispostivo_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] DROP CONSTRAINT [trafico_observacion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] DROP CONSTRAINT [trafico_incidencia_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] DROP CONSTRAINT [traf_disp_medicion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_ingreso] DROP CONSTRAINT [pres_ejecucion_ingreso_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_gasto] DROP CONSTRAINT [pres_ejecucion_gasto_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ingreso] DROP CONSTRAINT [presupuesto_ingreso_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_gasto] DROP CONSTRAINT [presupuesto_gasto_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto] DROP CONSTRAINT [presupuesto_liquidacion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] DROP CONSTRAINT [fk_convenio_org_obliga]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-9::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] DROP CONSTRAINT [fk_convenio_org]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-8::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] DROP CONSTRAINT [fk_con_rel_firma_ent_org]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-7::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] DROP CONSTRAINT [fk_con_rel_firma_ent_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] DROP CONSTRAINT [fk_con_rel_firma_ayto_org]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] DROP CONSTRAINT [fk_con_rel_firma_ayto_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] DROP CONSTRAINT [fk_convenio_susc_org_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] DROP CONSTRAINT [fk_convenio_susc_entidad_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] DROP CONSTRAINT [fk_convenio_prorroga]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_documentacion] DROP CONSTRAINT [fk_convenio_doc_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_observacion] DROP CONSTRAINT [bicicleta_observacion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] DROP CONSTRAINT [bicicleta_punto_de_paso_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_6]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_5]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_anclaje] DROP CONSTRAINT [bibileta_anclaje_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-61::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_5]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-61' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-60::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-60' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-59::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-59' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-58::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-58' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-57::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-57' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-56::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] DROP CONSTRAINT [t_provincia_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-56' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-55::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] DROP CONSTRAINT [t_provincia_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-55' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-54::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] DROP CONSTRAINT [t_municipio_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-54' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-53::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] DROP CONSTRAINT [t_municipio_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-53' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-52::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] DROP CONSTRAINT [t_municipio_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-52' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-51::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-51' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-50::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-50' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-49::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-49' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-48::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-48' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-47::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_5]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-47' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-46::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-46' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-45::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-45' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-44::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-44' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-43::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-43' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-42::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_autonomia] DROP CONSTRAINT [t_autonomia_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-42' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-24::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] DROP CONSTRAINT [dsd_rel_dim_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-24' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-23::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_dimension_value] DROP CONSTRAINT [dsd_dim_value_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-23' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-22::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] DROP CONSTRAINT [cube_dsd_rel_mea_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-22' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-21::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] DROP CONSTRAINT [cube_dsd_rel_mea_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-20::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] DROP CONSTRAINT [cube_dsd_rel_dim_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-42::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] DROP CONSTRAINT [cont_tender_r_item_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-42' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-41::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] DROP CONSTRAINT [cont_tender_r_item_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-41' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-40::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender] DROP CONSTRAINT [contratos_tender_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-40' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-39::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] DROP CONSTRAINT [contratos_process_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-39' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-38::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] DROP CONSTRAINT [contratos_process_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-38' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-37::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] DROP CONSTRAINT [contratos_lot_rel_item_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-37' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-36::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] DROP CONSTRAINT [contratos_lot_rel_item_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-36' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-35::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] DROP CONSTRAINT [contratos_lot_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-35' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-34::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] DROP CONSTRAINT [contratos_lot_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-34' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-33::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_award] DROP CONSTRAINT [contratos_award_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-33' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-eveto-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_evento] DROP CONSTRAINT [fk_evento_to_evento_super]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-eveto-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-rolEvento-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_rolintegranteevento] DROP CONSTRAINT [fk_rol_i_evento_to_evento]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-rolEvento-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-documento-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_document] DROP CONSTRAINT [fk_documento_to_evento]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-documento-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-Index-table-portal_via-via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[callejero_portal] DROP CONSTRAINT [callejero_portal_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-Index-table-portal_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-Index-table-callejero_tramo_via-via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[callejero_tramo_via] DROP CONSTRAINT [callejero_tramo_via_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-Index-table-callejero_tramo_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-UNIT-Of::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] DROP CONSTRAINT [fk_unit_of]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-UNIT-Of' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-UNIDAD-RAIZ::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] DROP CONSTRAINT [fk_unidad_raiz]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-UNIDAD-RAIZ' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-made-by-sensor-table-calidad-aire-sensor::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_sensor] DROP CONSTRAINT [fk_estacion_sensor]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-made-by-sensor-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-made-by-sensor-table-calidad-aire-observacion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_observacion] DROP CONSTRAINT [fk_estacion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-made-by-sensor-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-tiene_licencia_apertura::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] DROP CONSTRAINT [fk_local_comercial_licencia]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-tiene_licencia_apertura' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-tiene_terraza::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] DROP CONSTRAINT [fk_local_comercial_terraza]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-tiene_terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-agrupacion_comercial::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] DROP CONSTRAINT [fk_local_comercial_agrupacion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-agrupacion_comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO












