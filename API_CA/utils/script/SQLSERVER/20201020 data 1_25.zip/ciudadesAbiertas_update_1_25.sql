-- *********************************************************************
-- Rollback to '1.23' Script
-- *********************************************************************
-- Change Log: liquibase/db-changelog-master.xml
-- Ran at: 20/10/20 9:14
-- Against: ciudadesAbiertas@jdbc:sqlserver://localhost:1433;useBulkCopyForBatchInsert=false;cancelQueryTimeout=-1;sslProtocol=TLS;jaasConfigurationName=SQLJDBCDriver;statementPoolingCacheSize=0;serverPreparedStatementDiscardThreshold=10;enablePrepareOnFirstPreparedStatementCall=false;fips=false;socketTimeout=0;authentication=NotSpecified;authenticationScheme=nativeAuthentication;xopenStates=false;sendTimeAsDatetime=true;trustStoreType=JKS;trustServerCertificate=false;TransparentNetworkIPResolution=true;serverNameAsACE=false;sendStringParametersAsUnicode=true;selectMethod=direct;responseBuffering=adaptive;queryTimeout=-1;packetSize=8000;multiSubnetFailover=false;loginTimeout=15;lockTimeout=-1;lastUpdateCount=true;encrypt=false;disableStatementPooling=true;databaseName=ciudadesAbiertas;columnEncryptionSetting=Disabled;applicationName=Microsoft JDBC Driver for SQL Server;applicationIntent=readwrite;
-- Liquibase version: 3.4.2
-- *********************************************************************

USE [bbdd_ciudadesAbiertas];
GO

-- Lock Database
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 1, [LOCKEDBY] = 'DESKTOP-R1EU6J4 (192.168.56.1)', [LOCKGRANTED] = '2020-10-20T09:14:41.542' WHERE [ID] = 1 AND [LOCKED] = 0
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] DROP CONSTRAINT [trafico_tramo_via_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] DROP CONSTRAINT [traf_obse_dispostivo_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] DROP CONSTRAINT [traf_obse_dispostivo_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] DROP CONSTRAINT [trafico_observacion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] DROP CONSTRAINT [trafico_incidencia_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] DROP CONSTRAINT [traf_disp_medicion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-trafico-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_ingreso] DROP CONSTRAINT [pres_ejecucion_ingreso_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_gasto] DROP CONSTRAINT [pres_ejecucion_gasto_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ingreso] DROP CONSTRAINT [presupuesto_ingreso_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_gasto] DROP CONSTRAINT [presupuesto_gasto_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto] DROP CONSTRAINT [presupuesto_liquidacion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-presupuesto-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] DROP CONSTRAINT [fk_convenio_org_obliga]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-9::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] DROP CONSTRAINT [fk_convenio_org]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-8::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] DROP CONSTRAINT [fk_con_rel_firma_ent_org]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-7::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] DROP CONSTRAINT [fk_con_rel_firma_ent_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] DROP CONSTRAINT [fk_con_rel_firma_ayto_org]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] DROP CONSTRAINT [fk_con_rel_firma_ayto_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] DROP CONSTRAINT [fk_convenio_susc_org_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] DROP CONSTRAINT [fk_convenio_susc_entidad_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] DROP CONSTRAINT [fk_convenio_prorroga]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_documentacion] DROP CONSTRAINT [fk_convenio_doc_id]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-convenio-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_observacion] DROP CONSTRAINT [bicicleta_observacion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] DROP CONSTRAINT [bicicleta_punto_de_paso_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_6]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_5]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] DROP CONSTRAINT [bicicleta_trayecto_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_anclaje] DROP CONSTRAINT [bibileta_anclaje_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-bicicleta-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-61::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_5]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-61' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-60::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-60' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-59::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-59' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-58::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-58' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-57::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] DROP CONSTRAINT [t_seccion_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-57' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-56::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] DROP CONSTRAINT [t_provincia_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-56' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-55::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] DROP CONSTRAINT [t_provincia_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-55' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-54::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] DROP CONSTRAINT [t_municipio_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-54' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-53::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] DROP CONSTRAINT [t_municipio_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-53' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-52::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] DROP CONSTRAINT [t_municipio_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-52' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-51::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-51' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-50::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-50' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-49::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-49' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-48::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] DROP CONSTRAINT [t_distrito_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-48' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-47::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_5]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-47' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-46::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_4]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-46' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-45::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_3]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-45' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-44::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-44' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-43::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] DROP CONSTRAINT [t_barrio_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-43' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-42::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_autonomia] DROP CONSTRAINT [t_autonomia_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'TablasTerritorio-42' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-24::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] DROP CONSTRAINT [dsd_rel_dim_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-24' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-23::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_dimension_value] DROP CONSTRAINT [dsd_dim_value_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-23' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-22::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] DROP CONSTRAINT [cube_dsd_rel_mea_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-22' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-21::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] DROP CONSTRAINT [cube_dsd_rel_mea_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-20::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] DROP CONSTRAINT [cube_dsd_rel_dim_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DSD_Tables-20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-42::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] DROP CONSTRAINT [cont_tender_r_item_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-42' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-41::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] DROP CONSTRAINT [cont_tender_r_item_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-41' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-40::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender] DROP CONSTRAINT [contratos_tender_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-40' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-39::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] DROP CONSTRAINT [contratos_process_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-39' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-38::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] DROP CONSTRAINT [contratos_process_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-38' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-37::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] DROP CONSTRAINT [contratos_lot_rel_item_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-37' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-36::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] DROP CONSTRAINT [contratos_lot_rel_item_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-36' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-35::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] DROP CONSTRAINT [contratos_lot_ibfk_2]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-35' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-34::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] DROP CONSTRAINT [contratos_lot_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-34' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-33::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_award] DROP CONSTRAINT [contratos_award_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'fk-con-33' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-eveto-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_evento] DROP CONSTRAINT [fk_evento_to_evento_super]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-eveto-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-rolEvento-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_rolintegranteevento] DROP CONSTRAINT [fk_rol_i_evento_to_evento]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-rolEvento-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-documento-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_document] DROP CONSTRAINT [fk_documento_to_evento]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-documento-to-evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-Index-table-portal_via-via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[callejero_portal] DROP CONSTRAINT [callejero_portal_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-Index-table-portal_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-Index-table-callejero_tramo_via-via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[callejero_tramo_via] DROP CONSTRAINT [callejero_tramo_via_ibfk_1]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-Index-table-callejero_tramo_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-UNIT-Of::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] DROP CONSTRAINT [fk_unit_of]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-UNIT-Of' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-UNIDAD-RAIZ::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] DROP CONSTRAINT [fk_unidad_raiz]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-UNIDAD-RAIZ' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-made-by-sensor-table-calidad-aire-sensor::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_sensor] DROP CONSTRAINT [fk_estacion_sensor]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-made-by-sensor-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-made-by-sensor-table-calidad-aire-observacion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_observacion] DROP CONSTRAINT [fk_estacion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-made-by-sensor-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-tiene_licencia_apertura::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] DROP CONSTRAINT [fk_local_comercial_licencia]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-tiene_licencia_apertura' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-tiene_terraza::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] DROP CONSTRAINT [fk_local_comercial_terraza]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-tiene_terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-agrupacion_comercial::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] DROP CONSTRAINT [fk_local_comercial_agrupacion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'FK-agrupacion_comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-data.xml::DATA-TRAFICO-tag-1.24::Localidata
DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'DATA-TRAFICO-tag-1.24' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-data.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-data.xml::data-trafico_tramo_via::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_tramo_via]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'data-trafico_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-data.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-data.xml::data-trafico_tramo::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_tramo]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'data-trafico_tramo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-data.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-data.xml::data-trafico_observacion_dispostivo::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_observacion_dispostivo]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'data-trafico_observacion_dispostivo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-data.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-data.xml::data-trafico_observacion::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_observacion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'data-trafico_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-data.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-data.xml::data-trafico_incidencia::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_incidencia]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'data-trafico_incidencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-data.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-data.xml::data-trafico_dispositivo_medicion::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_dispositivo_medicion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'data-trafico_dispositivo_medicion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-data.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::INDEX-trafico-6::Localidata
DROP INDEX [schema_ciudadesAbiertas].[trafico_tramo_via].[index_tramo_id_travia]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'INDEX-trafico-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::INDEX-trafico-5::Localidata
DROP INDEX [schema_ciudadesAbiertas].[trafico_observacion_dispostivo].[index_disp_id_obs_di]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'INDEX-trafico-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::INDEX-trafico-4::Localidata
DROP INDEX [schema_ciudadesAbiertas].[trafico_observacion_dispostivo].[index_obs_id_obs_di]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'INDEX-trafico-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::INDEX-trafico-3::Localidata
DROP INDEX [schema_ciudadesAbiertas].[trafico_observacion].[index_tramo_id_obs]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'INDEX-trafico-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::INDEX-trafico-2::Localidata
DROP INDEX [schema_ciudadesAbiertas].[trafico_incidencia].[index_tramo_id_inc]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'INDEX-trafico-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::INDEX-trafico-1::Localidata
DROP INDEX [schema_ciudadesAbiertas].[trafico_dispositivo_medicion].[index_tramo_id_disp]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'INDEX-trafico-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::unique-id-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] DROP CONSTRAINT [unique-id-traf_tra_via]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'unique-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::unique-id-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo] DROP CONSTRAINT [unique-id-traf_tramo]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'unique-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::unique-id-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] DROP CONSTRAINT [unique-id-traf_obs_dis]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'unique-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::unique-id-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] DROP CONSTRAINT [unique-id-traf_obs]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'unique-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::unique-id-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] DROP CONSTRAINT [unique-id-traf_incid]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'unique-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::unique-id-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] DROP CONSTRAINT [unique-id-traf_disp]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'unique-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::PK-table-trafico_tramo_via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] DROP CONSTRAINT [PK_trafico_tramo_via]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'PK-table-trafico_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::PK-table-trafico_tramo::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo] DROP CONSTRAINT [PK_trafico_tramo]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'PK-table-trafico_tramo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::PK-table-trafico_observacion_dispostivo::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] DROP CONSTRAINT [PK_trafico_observacion_disp]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'PK-table-trafico_observacion_dispostivo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::PK-table-trafico_observacion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] DROP CONSTRAINT [PK_trafico_observacio]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'PK-table-trafico_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::PK-table-trafico_incidencia::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] DROP CONSTRAINT [PK_trafico_incidencia]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'PK-table-trafico_incidencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::PK-table-trafico_dispositivo_medicion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] DROP CONSTRAINT [PK_trafico_dispositivo]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'PK-table-trafico_dispositivo_medicion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::table-trafico_tramo_via::Localidata
DROP TABLE [schema_ciudadesAbiertas].[trafico_tramo_via]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'table-trafico_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::table-trafico_tramo::Localidata
DROP TABLE [schema_ciudadesAbiertas].[trafico_tramo]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'table-trafico_tramo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::table-trafico_observacion_dispostivo::Localidata
DROP TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'table-trafico_observacion_dispostivo' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::table-trafico_observacion::Localidata
DROP TABLE [schema_ciudadesAbiertas].[trafico_observacion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'table-trafico_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::table-trafico_incidencia::Localidata
DROP TABLE [schema_ciudadesAbiertas].[trafico_incidencia]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'table-trafico_incidencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Rolling Back ChangeSet: liquibase/db-changelog-script-1.24-TRAFICO-table.xml::table-trafico_dispositivo_medicion::Localidata
DROP TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion]
GO

DELETE FROM [schema_ciudadesAbiertas].[DATABASECHANGELOG] WHERE [ID] = 'table-trafico_dispositivo_medicion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.24-TRAFICO-table.xml'
GO

-- Release Database Lock
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 0, [LOCKEDBY] = NULL, [LOCKGRANTED] = NULL WHERE [ID] = 1
GO

-- *********************************************************************
-- Update Database Script
-- *********************************************************************
-- Change Log: liquibase/db-changelog-master.xml
-- Ran at: 20/10/20 9:27
-- Against: ciudadesAbiertas@jdbc:sqlserver://localhost:1433;useBulkCopyForBatchInsert=false;cancelQueryTimeout=-1;sslProtocol=TLS;jaasConfigurationName=SQLJDBCDriver;statementPoolingCacheSize=0;serverPreparedStatementDiscardThreshold=10;enablePrepareOnFirstPreparedStatementCall=false;fips=false;socketTimeout=0;authentication=NotSpecified;authenticationScheme=nativeAuthentication;xopenStates=false;sendTimeAsDatetime=true;trustStoreType=JKS;trustServerCertificate=false;TransparentNetworkIPResolution=true;serverNameAsACE=false;sendStringParametersAsUnicode=true;selectMethod=direct;responseBuffering=adaptive;queryTimeout=-1;packetSize=8000;multiSubnetFailover=false;loginTimeout=15;lockTimeout=-1;lastUpdateCount=true;encrypt=false;disableStatementPooling=true;databaseName=ciudadesAbiertas;columnEncryptionSetting=Disabled;applicationName=Microsoft JDBC Driver for SQL Server;applicationIntent=readwrite;
-- Liquibase version: 3.4.2
-- *********************************************************************

USE [bbdd_ciudadesAbiertas];
GO

-- Lock Database
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 1, [LOCKEDBY] = 'DESKTOP-R1EU6J4 (192.168.56.1)', [LOCKGRANTED] = '2020-10-20T09:27:29.712' WHERE [ID] = 1 AND [LOCKED] = 0
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bbfce268af0d2d9b0cd2a79fb056cd15' WHERE [ID] = 'empty-ciudades-abiertas' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-0.0-EMPTY.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:45840426b11d0e7a7c685c84fc636342' WHERE [ID] = 'table-ciudad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:163da683a506b391626e94588381e711' WHERE [ID] = 'table-estadistica' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b193f221ba44f8eb280b29fd59d4bd9' WHERE [ID] = 'table-oauth-access-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:62688a22372dd8f7c8eb59d9b73e5367' WHERE [ID] = 'table-oauth-approvals' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c97e2436866044a413f80a52588f6ec' WHERE [ID] = 'table-oauth-client-details' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9f9984fff938a4d5116ef6eceef4b01a' WHERE [ID] = 'table-oauth-client-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4c9bea4afc85cd184227f460427a2a36' WHERE [ID] = 'table-oauth-code' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e3ff3683926345e15d014b7a28cc0854' WHERE [ID] = 'table-oauth-refresh-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f97726314258c37899248c395df39665' WHERE [ID] = 'table-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e652fd1e9b69e8738bf20613721ffd39' WHERE [ID] = 'table-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c9f4157fb185eb137532c79cc89c175d' WHERE [ID] = 'table-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b116abd678e2679558ff6031f31802de' WHERE [ID] = 'table-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a1332aa076e0b118d770d2bae9b42838' WHERE [ID] = 'table-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b453c375749daad569e497b42ace2283' WHERE [ID] = 'PK-table-ciudad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cf7262df414fc451d07c883ea8427f7d' WHERE [ID] = 'PK-table-estadistica' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:991ead7eb536d8f74a80d5b90d218f04' WHERE [ID] = 'PK-table-oauth-access-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:886facdc9619f43493dd0a19e244603c' WHERE [ID] = 'PK-table-oauth-client-details' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:52ec1ab295b5e32febc60b64be33e9c3' WHERE [ID] = 'PK-table-oauth-client-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7332d9c46f9bb3dbeeee064f3ccfd49c' WHERE [ID] = 'PK-table-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:01de5d6fb10427b23ef21c9989e6d46b' WHERE [ID] = 'PK-table-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:96f86e27cdb2422b854506bb1fa4c84a' WHERE [ID] = 'Unique-field-user_roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fbac76edc3b9fbfbe0d64e954e5335e6' WHERE [ID] = 'Indice-username-table-user_roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cac64f75dd0e532ddf7ae8abde9b4618' WHERE [ID] = 'function-TRANSLAT' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-SQLSERVER-FUNCIONES.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8df17fcf0caad4e587f0ccd282497beb' WHERE [ID] = 'table-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:02c1162b6e60b4fa0ee9a779830f3e63' WHERE [ID] = 'PK-table-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1642ec6a87abb8d01df12019defa0e76' WHERE [ID] = 'Index-equipamiento-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5e349bb7313f1ff8aba39f3744c71d75' WHERE [ID] = 'table-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-PUNTO-INTERES-TURISTICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f9f67dbcbda6aec528c0e5f4de697ec2' WHERE [ID] = 'PK-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-PUNTO-INTERES-TURISTICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e1e42b952adaee61f6be271310dbb05b' WHERE [ID] = 'Index-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-PUNTO-INTERES-TURISTICO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26162a03d12e0f90391fdc928c72c356' WHERE [ID] = 'data-ciudad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ac1092dcc0f09000fcf50228877d4e5a' WHERE [ID] = 'data-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:510f8602fefea9b6edb555dafb672949' WHERE [ID] = 'data-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ca7bbea357ee7c45482cc9354d94296' WHERE [ID] = 'data-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3f8747c4c08ac9ea4ed9ccc39fc62093' WHERE [ID] = 'data-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c641227f106de85fffe90f7a50316206' WHERE [ID] = 'data-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e1e0ad7e580044e3f6f7629dbee76df0' WHERE [ID] = 'PK-table-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:565c0dfcc407b9e477d41bc6ffd558af' WHERE [ID] = 'PK-table-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d17293c9f0aacd1f652b0d5b64ec81d1' WHERE [ID] = 'PK-table-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:76bd6afc490b2fed2aff27036df3791b' WHERE [ID] = 'FK-USER-ROLE-USERNAME' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:34873c68b5f685c58167c1cd4650afaf' WHERE [ID] = 'FK-GROUP-MEMBERS-USERS' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8dcbba0717c053e81702277e406a4c9d' WHERE [ID] = 'FK-GROUP-MEMBERS-GROUP' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:553a44914ab92b994237f8e1b522c9da' WHERE [ID] = 'FK-GROUP-AUTHORI-GROUP' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5560655641c5ef77bca6b90c5b234724' WHERE [ID] = 'DATA-CORE-tag-1.0' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d094637aa50c90ec47cc3906c198d909' WHERE [ID] = 'TablasTerritorio-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:735e42ea8c1ed0145a6320bdc6cda1eb' WHERE [ID] = 'TablasTerritorio-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:11409df443a7a2042bc215286fbb14e5' WHERE [ID] = 'TablasTerritorio-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:357a149ef3f495c47f2b093023ddc8bb' WHERE [ID] = 'TablasTerritorio-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2a64201eefcae189d10e6984ba813064' WHERE [ID] = 'TablasTerritorio-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d51893da23232a65fbb15abd96d4eca' WHERE [ID] = 'TablasTerritorio-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d7ab69b91b90fb84265377a380c11851' WHERE [ID] = 'TablasTerritorio-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fd5d3e2d67eac1e5217b0cc254c7b800' WHERE [ID] = 'TablasTerritorio-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e73e44f8b234311533a5ecf27abdf234' WHERE [ID] = 'TablasTerritorio-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c4dfb8f27667a149a03125b45013c45' WHERE [ID] = 'TablasTerritorio-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1a5c7be2fde8bc356850d9c4cdcf817c' WHERE [ID] = 'TablasTerritorio-11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ce7ba7ac0e430a91fe41c8c616070643' WHERE [ID] = 'TablasTerritorio-12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:07375c695904e230938b38a8651bb940' WHERE [ID] = 'TablasTerritorio-13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6707ece4250de63048ff1a268a1d5833' WHERE [ID] = 'TablasTerritorio-14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:63f31fb200acd7de4b8c6814007524ec' WHERE [ID] = 'TablasTerritorio-15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1126e3db326ffd6ad0fc677b1ee861b4' WHERE [ID] = 'TablasTerritorio-16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:63ac47bb8c80ef5edaf6ef8358013343' WHERE [ID] = 'TablasTerritorio-17' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8352d3abf82670b77b73ab9f798cf7b8' WHERE [ID] = 'TablasTerritorio-18' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:12334f0a8d4e640acfa92deee1abfa78' WHERE [ID] = 'TablasTerritorio-19' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:119fd680d6f50c44374d354669d5c9fd' WHERE [ID] = 'TablasTerritorio-20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d92381b81717eb0922396b3e57c94d0' WHERE [ID] = 'TablasTerritorio-21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c74b5db43e36c6ac8e0e54d94d037401' WHERE [ID] = 'TablasTerritorio-22' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b61bc8bcc6e413ce4ca4ef2b78d83630' WHERE [ID] = 'TablasTerritorio-23' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ffd09ab3b9e78c8dedf8464e31be677' WHERE [ID] = 'TablasTerritorio-24' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d2aa67c39c2ce13448adc7a5187f17f6' WHERE [ID] = 'TablasTerritorio-25' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e8fed14156a649bfb6b9aba119dad77b' WHERE [ID] = 'TablasTerritorio-26' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:18db541dcf85c4a95ff92c3e5b268b85' WHERE [ID] = 'TablasTerritorio-27' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6d99c5b3e03d778c265aafe4969af20b' WHERE [ID] = 'TablasTerritorio-28' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:59bbfa933fa49633e31344609571ad25' WHERE [ID] = 'TablasTerritorio-29' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0ca7b478d16d60ff0f7c7355ee78c73c' WHERE [ID] = 'TablasTerritorio-30' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:70744f741c651b2932d4d9b84a04f77c' WHERE [ID] = 'TablasTerritorio-31' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c30fab0edae14c4b35683b49180d57b' WHERE [ID] = 'TablasTerritorio-32' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:01db0597b50d2ef8db8b83b8e426fd15' WHERE [ID] = 'TablasTerritorio-33' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:407613f9165370442e57a179e0e2ad90' WHERE [ID] = 'TablasTerritorio-34' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:69d7f703b0fa1aab0e5c5d2b6dfb1c1f' WHERE [ID] = 'TablasTerritorio-35' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9d0849414f48ea4b01dfae42863d1172' WHERE [ID] = 'TablasTerritorio-36' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:31be6b90be21dbc81f858e3f3830ad95' WHERE [ID] = 'TablasTerritorio-37' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d601ce16eded90acfca4e5a43e23d650' WHERE [ID] = 'TablasTerritorio-38' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7e842552d49f8fe114aa199ab29bac7e' WHERE [ID] = 'TablasTerritorio-39' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f453da82f8d003686bcc35948bc3e77a' WHERE [ID] = 'TablasTerritorio-40' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:aacef3960d9c8164d8f801a9fd3b4670' WHERE [ID] = 'TablasTerritorio-41' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:edece915c0f36581ec54f3d78e2ea8d1' WHERE [ID] = 'territorio_data-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fe9a2f82d471d699959bbf91d11961bf' WHERE [ID] = 'territorio_data-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ed819677dd669ede1f38073211bc5a21' WHERE [ID] = 'territorio_data-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:df60bdb4d216d597bd905da4485aa2ad' WHERE [ID] = 'territorio_data-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b38f1c4c8f499d5f798e959cc5e7627b' WHERE [ID] = 'territorio_data-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c52294c9f612421c0fc66bc14fb9c956' WHERE [ID] = 'territorio_data-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:165b5ed5300f0364e99037603d195b00' WHERE [ID] = 'territorio_data-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f949a2af30a38ea0fc448b5cfe82e09f' WHERE [ID] = 'DATA-CORE-tag-1.0.1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.1-TERRITORIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1ee5fe055425e60003a0f98f0c4e0ead' WHERE [ID] = 'DSD_Tables-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b7d57e4e06cccce35542de4ce0b18d5' WHERE [ID] = 'DSD_Tables-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3f45b243d751468248b83b927f76b87a' WHERE [ID] = 'DSD_Tables-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ae7737c73810829c0003bda3fb79b9a1' WHERE [ID] = 'DSD_Tables-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:68a420bf442467a49133eff632b55fd7' WHERE [ID] = 'DSD_Tables-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a1bd32046c72f1517a51531add24a493' WHERE [ID] = 'DSD_Tables-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:102d3ebabce4637d5f8f5d9d297e67a7' WHERE [ID] = 'DSD_Tables-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:841bd08b39b8e8d934c040c9040ad991' WHERE [ID] = 'DSD_Tables-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:16a0a8aa7ab00b32e3dd117b988f66a9' WHERE [ID] = 'DSD_Tables-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cd54a5083a081e3030f2c79f655cda43' WHERE [ID] = 'DSD_Tables-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6812fb7adecb13206e08db144b5ee8f6' WHERE [ID] = 'DSD_Tables-11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3526f2b3760938e90ffca163e61ba5be' WHERE [ID] = 'DSD_Tables-12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:92090b8c5d459eb9b6f7c02f13c9f8e3' WHERE [ID] = 'DSD_Tables-13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:742f481ea9c18f9f812afc1b26d5bbdc' WHERE [ID] = 'DSD_Tables-14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c0dc9f4ae053860592ad95a7bf11bca7' WHERE [ID] = 'DSD_Tables-15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2cb54905633a411df635b69bd115afd2' WHERE [ID] = 'DSD_Tables-16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a65aa2b976d121400e7eb72fc8a12230' WHERE [ID] = 'DSD_Tables-17' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1991dbb5be3bf6a6fb2ed973fdeea158' WHERE [ID] = 'DSD_Tables-18' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bb4f45ca282dc1b3050d60b762d9d3ca' WHERE [ID] = 'DSD_Tables-19' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:86b17fa71eb7c3d3cab3b75331b1b220' WHERE [ID] = 'dsdDatos-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fa190ce11d65915155098ae2283d6a89' WHERE [ID] = 'dsdDatos-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5803fa8ab7c4b8d37b980ee08af91ccd' WHERE [ID] = 'dsdDatos-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d3883e5a2be5c9025ce7c707dd55d7e8' WHERE [ID] = 'dsdDatos-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:43245629a6bb49d702250dffc36f0681' WHERE [ID] = 'dsdDatos-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a17385b812b4eec36691ff761517ea0' WHERE [ID] = 'dsdDatos-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:54b38c99607de1d2388004a3c2e7c6bb' WHERE [ID] = 'TABLE-dsdDatos-1-tag-1.0.2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0.2-DSD-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e5685f4ec490308877695c57fd3f8dd3' WHERE [ID] = 'table-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d7fe923c9d768f86d6a0187fe32e247' WHERE [ID] = 'PK-table-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b3b76691e1516ec4c31c243e8716f18' WHERE [ID] = 'Index-on-id-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6af91eaef29568c2e5dd2200262f55fe' WHERE [ID] = 'data-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3c9d75423dcefb5f40dd0886b1066474' WHERE [ID] = 'DATA-SUBVENCION-tag-1.1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.01-SUBVENCION-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f334338408df0e5f910127cac7f173fc' WHERE [ID] = 'data-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.02-EQUIPAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:10c09d49819760e13e95af97a3d117a1' WHERE [ID] = 'DATA-EQUIPAMIENTO-tag-1.02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.02-EQUIPAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d73febe0f09fa26618e4bfd04e1b617a' WHERE [ID] = 'table-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c1d7de402693e62fbd780560766d7fe' WHERE [ID] = 'PK-table-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:610fe113e456058d5d5676cf7e78f02a' WHERE [ID] = 'Index-agenda-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6800114a8e47593dca10ed512bdb3f43' WHERE [ID] = 'data-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ef1f9097da7e88e9fdfd110b58eb77e5' WHERE [ID] = 'DATA-AGENDA-tag-1.03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.03-AGENDA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:81bb281e6a596117f7ef0b5213b18c31' WHERE [ID] = 'Tabla-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d4b7895859b9866f6c7c45f1219bf8de' WHERE [ID] = 'Tabla-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e6fb2557bfbf6c1fe666771a6e1fe1e9' WHERE [ID] = 'Tabla-local-comercial-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:80d3691d2a8c361f279a939aea90cbad' WHERE [ID] = 'tabla-local-comercial-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ba427ae5beef06794503073a3a835f1f' WHERE [ID] = 'pk-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6657a49580a89645f54239257875f13b' WHERE [ID] = 'pk-local-comercial-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:834900d6d4ca6e0f5d211e83f1e526bf' WHERE [ID] = 'pk-local-comercial-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:61d0249bdece35745f85bc36b6afc561' WHERE [ID] = 'pk-local-comercial-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:eeb0feff7faf9462006a18d1be86b61b' WHERE [ID] = 'index-id-on-local-comercial-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1fdfc867e10c928b5476f8524d95e5bf' WHERE [ID] = 'index-id-on-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f2cb7f3279991ad845a6af9a8434692a' WHERE [ID] = 'index-id-on-local-comercial-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6576e4fc437ef0a6f319c06dfc9b7b1b' WHERE [ID] = 'index-id-on-local-comercial-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f5e3310c93f3f44a27a7d1859aa961f3' WHERE [ID] = 'Datos-tabla-local-comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:19e1c0eed092ad3aa27d6b82e28e1adb' WHERE [ID] = 'Datos-tabla-local-comercial-agrupacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0ef977c68ac114e51e1cdf776e7ac8c6' WHERE [ID] = 'Datos-tabla-local-licencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e63063faa8d6ea2609771875a2ea0c32' WHERE [ID] = 'Datos-tabla-local-terraza' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26d68f691d261f9ac8169e04cc10d800' WHERE [ID] = 'DATA-LOCALCOMERCIAL-tag-1.04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.04-LOCAL-COMERCIAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:536b96a62fc6f6e872115b2b9ddd93da' WHERE [ID] = 'data-equipamiento-punto-wifi' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.05-EQUIPAMIENTO-PUNTOWIFI-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c94c88a1d45b9101883b0ad3a25bd382' WHERE [ID] = 'DATA-EQUIPAMIENTO-PUNTO-WIFI-tag-1.05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.05-EQUIPAMIENTO-PUNTOWIFI-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b03f70f7b18f589e3d48c04318261d33' WHERE [ID] = 'data-equipamiento-aparcamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.06-EQUIPAMIENTO-APARCAMIENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dce8024a65fed855c0ba2797715f9ed5' WHERE [ID] = 'DATA-EQUIPAMIENTO-APARCAMIENTO-tag-1.06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.06-EQUIPAMIENTO-APARCAMIENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:11e66f35abdcf9f9006420de286d83e1' WHERE [ID] = 'data-equipamiento-instalaciones-deportivas' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.07-EQUIPAMIENTO-INSTAL-DEPORTIVAS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ff0f1614f516286bfd49eef15bf8093b' WHERE [ID] = 'DATA-EQUIPAMIENTO-INSTALACIONES-DEPORTIVAS-tag-1.07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.07-EQUIPAMIENTO-INSTAL-DEPORTIVAS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1269456364eaf42198b04396bd87a748' WHERE [ID] = 'table-aviso_queja_sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d64007ebd75da01b5c9b525fc2b68c30' WHERE [ID] = 'PK-table-aviso_queja_sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a6d1590717c0f84b7f3806f086ac704c' WHERE [ID] = 'Index-aviso_queja_sug-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0a811d1d8f0a0ce1b0f1aae481eb8da1' WHERE [ID] = 'data-aviso-queja-sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9ab4089fb176a2df9cf00cc49a2de7e4' WHERE [ID] = 'DATA-AVISO-QUEJA-SUG-tag-1.08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.08-AVISO_QUEJA_SUG-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ac504f75a15bbb45ed30e3a1e50f1a53' WHERE [ID] = 'tabla-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6a4faa90075ae003011f3cc596329a49' WHERE [ID] = 'tabla-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:74fddda694c544bb9a1a70afc2433eff' WHERE [ID] = 'tabla-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6290c2f4bcd8fd89e09a8b2429712507' WHERE [ID] = 'PK-table-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4b5f13ab8c573e4dbc8560d58eb2c324' WHERE [ID] = 'PK-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3da69a34d17606d7fecb2ffe0a344662' WHERE [ID] = 'PK-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:127313673c18c0340b86f444a74c6927' WHERE [ID] = 'index-id-table-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4eec50a28e974a65813bda79b9c002f1' WHERE [ID] = 'index-id-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:053512f9ae2b82ae7d5d3f3070e6d28b' WHERE [ID] = 'index-id-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c2cf4cf570722401809657b20c25c057' WHERE [ID] = 'index-made-by-sensor-table-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bc1ace949eb665a295eced3516b7a013' WHERE [ID] = 'index-is_hosted_by-table-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c6e15fa0c1d6c19084e9fc8b91c00835' WHERE [ID] = 'data-calidad-aire-estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1a32ecec85c3f7ad3cb2605cb0dafd7f' WHERE [ID] = 'data-calidad-aire-observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:20d914740a09b39b7dbb029b98b2faf5' WHERE [ID] = 'data-calidad-aire-sensor' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b84dcf622628d171750e4421405f5c58' WHERE [ID] = 'DATA-CALIDAD-AIRE-tag-1.09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.09-CALIDAD_AIRE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e3e2bb937c8979fcd260e9ef357bcc14' WHERE [ID] = 'table-organigrama' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f40597dc24112fbeaff92f3db27a070f' WHERE [ID] = 'PK-table-organigrama' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6a94e789c5d4601dfdb58bb80805721c' WHERE [ID] = 'Unique-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0142c1ba020173f5cd3f93d0a39d842e' WHERE [ID] = 'Index_unidad_raiz' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5926a732c91755efa216a0de9524ef2f' WHERE [ID] = 'Index_unit_of' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7496881f21b63e23959229e2146fdab8' WHERE [ID] = 'data-organigrama' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:073d706d8d6fe12b0b2a377c0bd141ab' WHERE [ID] = 'DATA-ORGANIGRAMA-tag-1.10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.10-ORGANIGRAMA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7cd4b1312ac0705514934eb341f79b2a' WHERE [ID] = 'data-punto-interes-turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.11-PUNTO-INTERES-TURISTICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5e30253cf00736b1d22dc76e27b3f2a1' WHERE [ID] = 'DATA-PUNTO-INTERES-TURISTICO-tag-1.11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.11-PUNTO-INTERES-TURISTICO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0d7b4cbdf27166d3d1931c51755c5ed9' WHERE [ID] = 'data-punto-interes-turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.12-MONUMENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:add34b971a32e69118b85a0b1914da81' WHERE [ID] = 'DATA-PUNTO-MONUMENTOS-tag-1.12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.12-MONUMENTOS-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:96595cd1a484685bcdbb5725afc19b4e' WHERE [ID] = 'table-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:875acd0bd9d7f575a34eadc61a4bf6c7' WHERE [ID] = 'PK-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:aacccdcff3d4f17dfb2b08fb22565999' WHERE [ID] = 'Index-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:469317830363ea41e8049519d9415494' WHERE [ID] = 'data-alojamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:364f472b52b49f328b83858c6af92857' WHERE [ID] = 'DATA-ALOJAMIENTO-tag-1.13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.13-ALOJAMIENTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0fb0301fba8779a2086511ebc922584f' WHERE [ID] = 'table-callejero_portal' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7f97bb945be3a8250acce91b2d51c55f' WHERE [ID] = 'table-callejero_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9e6ebcc263a1b0d9e0341ac77c524e74' WHERE [ID] = 'table-callejero_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:df31bfadc2ffa417fe53cf54ea13e55d' WHERE [ID] = 'PK-table-callejero_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a8328497e024e4b59aa17186a856d859' WHERE [ID] = 'Index-callejero_via-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f934e37ac50f6b22d20a3abd246bc756' WHERE [ID] = 'PK-table-callejero_tramo_via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cbea775454d5a115198911ab5924be49' WHERE [ID] = 'Index-table-callejero_tramo_via-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d7073be5952b1ebb53f5c1e1a78e820' WHERE [ID] = 'Index-table-callejero_tramo_via-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5a68fa1b29a3219097670c3f51e069a8' WHERE [ID] = 'PK-table-callejero_portal' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e9add8a6330ed278179297d601095913' WHERE [ID] = 'Index-table-callejero_portal-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7e35e20e09e5a5ef3ae7d6a7aa3a619b' WHERE [ID] = 'Index-table-callejero_portal-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fa6566f01af63754622f7884074e0606' WHERE [ID] = 'datos-callejero-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:63fbd8187670f27cc9ea8ce3561fadfb' WHERE [ID] = 'datos-callejero-portal' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:928efb3421ddd31b68916ee460a68eb3' WHERE [ID] = 'datos-callejero-tramo-via' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c4e84fa48cbd45b82c70997b5c129583' WHERE [ID] = 'DATA-CALIDAD-AIRE-tag-1.14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.14-CALLEJERO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ccb80c5629422a781d67cea6b6df0eb2' WHERE [ID] = 'table-tramite' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e5e12ec32286e215c964af004b6d7d9a' WHERE [ID] = 'PK-table-tramite' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:34051762bca0062942f221c896827768' WHERE [ID] = 'Index-table-tramite_portal-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:103b8092b2d08251d6fca8c6eb2d0346' WHERE [ID] = 'datos-tramite' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:45cdb6296b6a1bca9feb8674b16b9d4d' WHERE [ID] = 'TABLE-TRAMITE-tag-1.15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.15-TRAMITE-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d7c94fc924fd09e0b6a89b2e144c9fc9' WHERE [ID] = 'Tabla-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c5613a9073c8b416a7e75f0d4c46c47c' WHERE [ID] = 'pk-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a99a00cd381df6d28282ade4b8839ba3' WHERE [ID] = 'index-id-on-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c95e6a1c3a32c712d4270faed5271036' WHERE [ID] = 'data-plantilla' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ce22ff48a9fef39bb1c11b668c3c9b58' WHERE [ID] = 'DATA-PLANTILLA-tag-1.16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.16-PLANTILLA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ba3e0b695b29bd8134f1bdbd8a4f7b4' WHERE [ID] = 'table_padron_cube1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3c11abb3da40a44cb96310401e9e5f03' WHERE [ID] = 'PK-table-padron_cube_edad_g_q' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f6c948e0b46847e387ffaeb611fdde2d' WHERE [ID] = 'INDEX-table-padron_cube_edad_g_q' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a99d5612282ffe4d5c798d1a9a7d1a9e' WHERE [ID] = 'table_padron_cube2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:aec18f3807ee8b1c9b03d91471bf77f5' WHERE [ID] = 'PK-table-padron_cube_estudios' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:844018616f66ef4fe62a2ab8899245b4' WHERE [ID] = 'INDEX-table-padron_cube_estudios' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dd90eef84ee62d5a98ecabd419b681bf' WHERE [ID] = 'table_padron_cube3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:45fd1107dccbc551020143306f5ce8fc' WHERE [ID] = 'PK-table-padron_cube_nacionalidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:81bb539e55f13b8807e2603c6072090d' WHERE [ID] = 'INDEX-table-padron_cube_nacionalidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:815bcd2a55d92ee63643ec6a3d589f6f' WHERE [ID] = 'table_padron_cube4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:439ddf5cc0a1a6030f6e47b6ec48f589' WHERE [ID] = 'PK-table-padron_cube_procedencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:888518384e289207ef2cda46fb368788' WHERE [ID] = 'INDEX-table-padron_cube_procedencia' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cceaf56510373e415278f5f09596a251' WHERE [ID] = 'table_padron_cube5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5f9976ff2559ee094158cace1293fa21' WHERE [ID] = 'PK-table-padron_cube_indicadores' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26a189c825b87c40e995f300297e9c47' WHERE [ID] = 'INDEX-table-padron_cube_indicadores' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b1426a972532f0c422fe57641a0da35b' WHERE [ID] = 'table_padron_cube6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:39fd68718b7c37b54c5b0f46db37ff06' WHERE [ID] = 'PK-table-padron_cube_edad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:140c9677a335866b5f7f633a89f9ed57' WHERE [ID] = 'INDEX-table-padron_cube_edad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:86a47a919bcd30ef2c082b84d2ed7d71' WHERE [ID] = 'table_padron_cube7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bbe5890fdb1548be66759e952f116af7' WHERE [ID] = 'PK-table-padron_cube_pais_n' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:eb83df13b9fae438621860c484f767a6' WHERE [ID] = 'INDEX-table-padron_cube_pais_n' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:238f72b3ca8d679fc3f43503d24731bc' WHERE [ID] = 'data-cube-padron1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c63919e44390504d7b313e47b69a6b75' WHERE [ID] = 'data-cube-padron2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a27f4fe7e4600ec99e266cbd0b3c7e06' WHERE [ID] = 'data-cube-padron3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:26208dc33dcdd3c1a12606c236648dd0' WHERE [ID] = 'data-cube-padron4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ee8219b33950d77ef1535c3dfcfbc416' WHERE [ID] = 'data-cube-padron5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a11fc5e681015fac4039a42cb749e349' WHERE [ID] = 'data-cube-padro6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:67e609eff096c78328916aa9760fc2c3' WHERE [ID] = 'TablesPadron-tag-1.17' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c3d4cbdf322a9600ececfd7fe190ac43' WHERE [ID] = 'data-cube-padron7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.17-PADRON-data-demo.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c12dc8cfa43a62994cbd2b65b6a53a73' WHERE [ID] = 'integraciones-entre-modelos-addColumn' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2956f148f9700308d1be6daf8d571060' WHERE [ID] = 'update-example' AND [AUTHOR] = 'liquibase-docs' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2956f148f9700308d1be6daf8d571060' WHERE [ID] = 'sql-update-alojamiento' AND [AUTHOR] = 'liquibase-docs' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:37f6b74c552cb1dc284dad95e2d45905' WHERE [ID] = 'sql-update-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9ec1e9d0d6ac4dc1bf079d119732884c' WHERE [ID] = 'sql-update-aviso_queja_sug' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b0e3d56d739c943eb6e6c4eb31e812f' WHERE [ID] = 'sql-update-calidad_aire_estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bbf5441d3a7fc9aab283cd8facecd183' WHERE [ID] = 'sql-update-punto_interes_turistico' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a9bf565f82074e379159effd6dd70a6' WHERE [ID] = 'sql-update-local_comercial' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:03ee908b581e925c19079c66ab3755ab' WHERE [ID] = 'sql-update-agenda' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6b1da0de657fc0a13937baa64d63f39c' WHERE [ID] = 'sql-update-organigrama' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4410b7f23e7759b13d8f98f86fa89fde' WHERE [ID] = 'addColumn-portal_id-tag-1.18' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.18-INTEGRACIONES-ALL-update.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d3d0335a1843424f8a20db8b4e4003d0' WHERE [ID] = 'table-agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7b3b819e8749cd61e49a917251d1d713' WHERE [ID] = 'table-agenda_m_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:27894f40c334688d8a41849503d56d79' WHERE [ID] = 'table-agenda_m_rolintegranteevento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:71effd5cccdc0144cbee5dfac0d7e9a0' WHERE [ID] = 'PK-table-agenda_m_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1a2ad34118fde402d7bd94afa8d75d6b' WHERE [ID] = 'PK-table-agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b34bccb646a0676d2d475f01cbf4d0cf' WHERE [ID] = 'PK-table-agenda_m_rolintegranteevento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8a538ce331610a1eb94e5e5cbf7e4193' WHERE [ID] = 'INDEX-table-agenda_m_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d0092fe8ed1f90654e99cded50df0ab8' WHERE [ID] = 'INDEX-table-agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9f358ca892fcd5598f2ba8cb140fe686' WHERE [ID] = 'INDEX-table-agenda_m_rolintegranteevento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:61d65656500be3978521feb066857823' WHERE [ID] = 'INDEX-table-agenda_m_documentacion_event' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8958871b98221654eda626321e82ac61' WHERE [ID] = 'INDEX-table-agenda_m_rol_i_evento_event' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0f9a67227dae95247e3d702cac6785a5' WHERE [ID] = 'INDEX-table-index_super_event_id_agenda_m_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bfcc76b591b3af87f6fc68de7fb264fe' WHERE [ID] = 'data-agenda_municipal_evento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:439d27a51cfdab1c9c87beff9d5b6678' WHERE [ID] = 'data-agenda_municipal_documento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:daa49e58ec1c17a62fcb27b74cae9d3a' WHERE [ID] = 'data-agenda_municipal_rol' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7f31069289254bf70d989162b5ddecb2' WHERE [ID] = 'tabla-contratos_award' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ebc966c2cc2c3b8a08f38f55bfca61c7' WHERE [ID] = 'DATA-AGENDA-MUNICIPAL-tag-1.19' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.19-AGENDA_MUNICIPAL-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:18cbb58f2f0328a0e7f50a6359309604' WHERE [ID] = 'tabla-contratos_item' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4be17f070d515aa91970a819bb5de331' WHERE [ID] = 'tabla-contratos_lot' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7b0f709401a232eff7ff8d4614a74432' WHERE [ID] = 'tabla-contratos_lot_rel_item' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:790b8b409f6c0de43756163b15e42584' WHERE [ID] = 'tabla-contratos_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:394818e25b678b576c97888bb34190b4' WHERE [ID] = 'tabla-contratos_process' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a71e51bf321cc2a4b96715b270b23214' WHERE [ID] = 'tabla-contratos_tender' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3ebf5e7ba4dcd259c4ebad51d87c34e4' WHERE [ID] = 'tabla-contratos_tender_rel_item' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:13b8d0945de9e7bba51b693d71f99363' WHERE [ID] = 'pk-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7632b0f4b6c539e0942ac14ede186e61' WHERE [ID] = 'pk-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3cafa3c91d3b3d660ac9d6af1bdd992d' WHERE [ID] = 'pk-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3c3a2424dd6b07a93c0c195e032f568c' WHERE [ID] = 'pk-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:086f8d2587beee49d61ec43cb08829f1' WHERE [ID] = 'pk-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f79871a3435076b63f82bfd6ff250770' WHERE [ID] = 'pk-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:194d9fe065d1d77fb94ea156903d8b3a' WHERE [ID] = 'pk-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:48ddec26ddbf7346b9c7e8c703f80854' WHERE [ID] = 'pk-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f2d45430d1ba8dc13644c55503026514' WHERE [ID] = 'index-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b52e7533dfafe9b637ff80607550aecc' WHERE [ID] = 'index-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8535ae5e2360ee678c0859829559e048' WHERE [ID] = 'index-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:28a8b89135777ae66d0c3db9eef02279' WHERE [ID] = 'index-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a5e600936ef0c6e353f12391309774fe' WHERE [ID] = 'index-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6dae2dd40fb757660182885fc43d0b02' WHERE [ID] = 'index-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:af93c83dcb8d0c25bf4d6f2a196369fb' WHERE [ID] = 'index-extra-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1f821d39f3b4d4e88cff1183b9425c5f' WHERE [ID] = 'index-extra-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:324b4049c78a73581957c4898e97f46f' WHERE [ID] = 'index-extra-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:16ea636f90a06fb61d067276f21cac10' WHERE [ID] = 'index-extra-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4a421be912ebc4f12bac271aa73654c0' WHERE [ID] = 'index-extra-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b010fd8b7682958f803891cabf6097a' WHERE [ID] = 'index-extra-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:42fb7580cba2277603da453a582848af' WHERE [ID] = 'index-extra-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e893c62d47d225f016d9f9a0a711d8f2' WHERE [ID] = 'index-extra-08' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:643e3595c24515d1635c20eb8ac80de2' WHERE [ID] = 'index-extra-09' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9eefedc8612b068ace4bedbd0db7eb6c' WHERE [ID] = 'index-extra-10' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0b7d5a2e3d2adbd0ba46c90314b9bcc6' WHERE [ID] = 'datos-award-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4d4a032e8fa49226d022147de7679a39' WHERE [ID] = 'datos-item-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d042b4484feb2b181800692066dd194b' WHERE [ID] = 'datos-lot-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:17b785887ef42845a0b2243c319a206b' WHERE [ID] = 'datos-lot-rel-item-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:14832048085ad42759029650567a7ba8' WHERE [ID] = 'datos-organization-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7007c15389c3e92c0a50af0515dbadd0' WHERE [ID] = 'datos-process-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:243ae65019576547a32157731faf0688' WHERE [ID] = 'datos-tender-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5d50f0657ec3fc0805ebb281534454fd' WHERE [ID] = 'datos-tender-rel-item-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bb7bf2689ec786f5bf92377f9e7b4438' WHERE [ID] = 'DATA-CONTRATOS-tag-1.20' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.20-CONTRATOS-data-mini.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d88b5f371f951a8e156550932ccd6bea' WHERE [ID] = 'table-bici_bicicleta' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e1682b260d68fa1dd8188b28f1848e93' WHERE [ID] = 'table-bici_estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7727189e8aa2ab7f6dac6438022d4972' WHERE [ID] = 'table-bici_anclaje' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0fede01a7f67325dcd405675866b1c71' WHERE [ID] = 'table-bici_usuario' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7110ff0a116ef4460404f238c9d1c8d6' WHERE [ID] = 'table-bici_trayecto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e2023c80ae8717097132107dae8a69f7' WHERE [ID] = 'table-bici_punto_paso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b91426017547f86ca40e5a2a933c2889' WHERE [ID] = 'table-bici_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:599327cc3995800b94633db922bd58ea' WHERE [ID] = 'pk-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6a342facc98e237da9a1fa23359f159c' WHERE [ID] = 'pk-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7950d9cc6bb26fb3fb19a6e4e87e388d' WHERE [ID] = 'pk-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8c5715734c7aab422a342bddd92dd423' WHERE [ID] = 'pk-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2209d37e51727d48efd0dd83de29f960' WHERE [ID] = 'pk-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e774e482191a8ee635ff3edad649a925' WHERE [ID] = 'pk-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:47acedcc1c8c6563244067a5e2a9503b' WHERE [ID] = 'pk-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:153d0cbbe252924c94107495dc607a45' WHERE [ID] = 'index-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7fcabab133a1708e69ea16f930aa2d25' WHERE [ID] = 'index-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3d674d34eaedab7357ea667441e7a783' WHERE [ID] = 'index-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:142558cf5ed6f53ced425215e67b4cfc' WHERE [ID] = 'index-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:bd77b4128518902ce50acf55a7c699c4' WHERE [ID] = 'index-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b2ed880cf562a1e2fa7b0ae3a8cff960' WHERE [ID] = 'index-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:2418dafe7d7c8d014f13e99b407dbd73' WHERE [ID] = 'index-id-07' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b9aac3bd4b3606317ad5f998391b9384' WHERE [ID] = 'data-bici_bicicleta' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ccb38677090c8d7dc83186db08a83682' WHERE [ID] = 'data-bici_estacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:95318554c3de9e0f9a80dd9d94d30023' WHERE [ID] = 'data-bici_anclaje' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:02f7d8375a42cfd306f4bea73f251a8e' WHERE [ID] = 'data-bici_usuario' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:0e5f39218e5f8ecc11717ae0171520fb' WHERE [ID] = 'data-bici_trayecto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5df79ab910b70df38624953c4ee3aab4' WHERE [ID] = 'data-bici_punto_paso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:91a8802966bfc9b7459924bdf49f2cf3' WHERE [ID] = 'data-bici_observacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dea3d4b6e323a2d3be72f101990e30d4' WHERE [ID] = 'DATA-ORGANIGRAMA-tag-1.21' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.21-BICICLETA-PUBLICA-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:33d7d1b7844888812b76d0b03edeefb8' WHERE [ID] = 'table-convenio' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c4f504ddc5022b5d3a73a30f061e55e5' WHERE [ID] = 'table-convenio_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1eb31fccb5714ba9f21ae4b0004abf66' WHERE [ID] = 'table-convenio_susc_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3e6b4cf1616ba99264cdc0dc7ed2c0af' WHERE [ID] = 'table-convenio_rel_firmante_ayto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:10195803476de7715b7fd1aedf9a40a4' WHERE [ID] = 'table-convenio_rel_firmante_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b3d93815b7216be1563a4cbd7febf0d7' WHERE [ID] = 'tabla-convenio_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a2f5f4ce7b85da592eefedc0d814e96' WHERE [ID] = 'PK-table-convenio' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8f6ee774ea524f50e6b40aeb0c764c7e' WHERE [ID] = 'PK-table-convenio_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a48f03ecb258f6bcc18c7062d3743c59' WHERE [ID] = 'PK-table-convenio_susc_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9be2899f759df34b7ba17e554e6e8162' WHERE [ID] = 'PK-table-conv_rel_firmante_ayto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:50abb8cf0f7d7addf22cd8d18605a9eb' WHERE [ID] = 'PK-table-conv_rel_firmante_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:42a4024b689881a7b32b9ce4bc2fb2fe' WHERE [ID] = 'PK-table-convenio_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cfb067b32518f75d2f31788b587f3738' WHERE [ID] = 'unique-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:42fd3cda2259175d949ade5f37e87add' WHERE [ID] = 'unique-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c6c0252746dea2c743c59c9109fab6a0' WHERE [ID] = 'unique-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:23ad4c146255c4481c0a2ecaf62ef4fb' WHERE [ID] = 'unique-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fcbbc74e15f2fa5ecc816b857c71400a' WHERE [ID] = 'unique-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:681e695380ffe9f72b4858e793aa5a05' WHERE [ID] = 'unique-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:a398b2832454c9d7f4ab896b1467ec78' WHERE [ID] = 'INDEX-convenio-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7cd05647f10ebe0c0fbfd788a8a98e49' WHERE [ID] = 'INDEX-convenio-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cacd89c29c2856e042d96c0250709d21' WHERE [ID] = 'INDEX-convenio-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:fdd6cd5084631cc4f12b3949ab1b523f' WHERE [ID] = 'INDEX-convenio-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:87b1482711d1a03ede1aba34d52e22a8' WHERE [ID] = 'INDEX-convenio-16' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5fa28f06b68ce5be7402d60f82f3e178' WHERE [ID] = 'INDEX-convenio-6' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7bfa4983508754c89f53e450dd066e30' WHERE [ID] = 'INDEX-convenio-7' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d4faf5ee40e579ea895547bef32950f1' WHERE [ID] = 'INDEX-convenio-8' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d27b6d7031df0519df383ed62ce73db0' WHERE [ID] = 'INDEX-convenio-9' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:682068a4d9e1f5497615b908410284eb' WHERE [ID] = 'INDEX-convenio-11' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:164718261930aa8c9f152506fd16f3e6' WHERE [ID] = 'INDEX-convenio-12' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c8d4a0cc734861aae73f7019307d87d6' WHERE [ID] = 'INDEX-convenio-13' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6134d1fca0dc8512b84837f8ae64f5d0' WHERE [ID] = 'INDEX-convenio-14' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:181a3163f4acdfc1dc860ab895a6f83a' WHERE [ID] = 'INDEX-convenio-15' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b7f36b5fce8d005ef0fda63acdff8188' WHERE [ID] = 'data-convenio' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:60465b4bc045901b030de5d170c65308' WHERE [ID] = 'data-convenio_documentacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4a2abc8ccbabe9d4a81abb54aa0b04dd' WHERE [ID] = 'data-convenio_susc_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:261f2989c04f40f56bcc35dc574f21b8' WHERE [ID] = 'data-conv_rel_firmante_ayto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d4ef274285690a807198e0fe1758d4a' WHERE [ID] = 'data-conv_rel_firmante_entidad' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:1fb1fd370977403166176af209664c9b' WHERE [ID] = 'datos-convenio_organization' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d2f9947790497dbd7e09de1df5751b34' WHERE [ID] = 'DATA-CONVENIO-tag-1.22' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.22-CONVENIO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5a70847b6e6e5a14a2f5c4bcce0b3b4f' WHERE [ID] = 'table-presupuesto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:9ef97309ae3f96ba971816054eaac28e' WHERE [ID] = 'table-presupuesto_liquidacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6e46992a812f463d9e53dcbeb7dd2b77' WHERE [ID] = 'table-presupuesto_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:cec9ac4641833e6ba2d0acb98413b907' WHERE [ID] = 'table-presupuesto_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:11d73e59b6d9004621e726080352ca93' WHERE [ID] = 'table-presupuesto_ejecucion_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4e4200904f3864c3587b06f60540d2f9' WHERE [ID] = 'table-presupuesto_ejecucion_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:e93fb503c7a44519844a375e624787cb' WHERE [ID] = 'PK-table-presupuesto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:46c2762a82935660a86f2c2928afd0f4' WHERE [ID] = 'PK-table-presupuesto_liquidacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:dad239fd939369c519d45f5009b91151' WHERE [ID] = 'PK-table-presupuesto_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:10a508b99e0297174f4367bd595cb792' WHERE [ID] = 'PK-table-presupuesto_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5dbd74c2e01a26c8bc8142453fa8a8dc' WHERE [ID] = 'PK-table-presupuesto_ejecucion_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6e9d1f4213977dd3ddf00119995ffd92' WHERE [ID] = 'PK-table-presupuesto_ejecucion_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:f2cdbb642a3ff896b1cd93fd861872ba' WHERE [ID] = 'unique-id-01' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3ac3af4143a22964ca90c0ed0a816b8c' WHERE [ID] = 'unique-id-02' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:763b77459b0d856adba15316c92fa9a3' WHERE [ID] = 'unique-id-03' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b799363fa56bc9c6a11834162ff6d991' WHERE [ID] = 'unique-id-04' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5464cb77c400cd6f8d1d353858a9e577' WHERE [ID] = 'unique-id-05' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8426e1b4e1920302a6d4a996eba579aa' WHERE [ID] = 'unique-id-06' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:6ee972624113f1de05ee00d523f8b0ea' WHERE [ID] = 'INDEX-presupuesto-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:d0f7017e66ec43eff9e20197eb5978be' WHERE [ID] = 'INDEX-presupuesto-2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:b20eee4a14850a49c173ef662678cbd5' WHERE [ID] = 'INDEX-presupuesto-3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:715ec0b89635b2c0cff27ba80e7eff25' WHERE [ID] = 'INDEX-presupuesto-4' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:c6c515535b68b4575955509f4c867d44' WHERE [ID] = 'INDEX-presupuesto-5' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-table.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:ecffce130b2b2a8d720604265535cb06' WHERE [ID] = 'data-presupuesto_liquidacion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b0cdef79776d19443a8471d99a40447' WHERE [ID] = 'data-presupuesto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:78c9571c2cd09a318f7c3e6592d21b75' WHERE [ID] = 'presupuesto-pres_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:7f0fb9080cc98e9c0fd556affd0592ee' WHERE [ID] = 'presupuesto-pres_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:8ddd3a6e138a012de7687c48e100e857' WHERE [ID] = 'presupuesto-ejec_gasto' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:3a3b4e9088b0b62a02a107c0fbef280b' WHERE [ID] = 'presupuesto-ejec_ingreso' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOG] SET [MD5SUM] = '7:4d5397b9d366725d955af3b84cbf5a16' WHERE [ID] = 'DATA-CONVENIO-tag-1.23' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.23-PRESUPUESTO-data.xml'
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::table-trafico_dispositivo_medicion::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [num_sentidos] [int] NULL, [num_carriles] [int] NULL, [urbano] [bit] NULL, [tipo_equipo_trafico] [varchar](200) NULL, [monitorea] [varchar](50) NULL, [en_servicio] [bit] NULL, [frecuencia_medicion] [varchar](200) NULL, [observes] [varchar](200) NULL, [x_etrs89] [decimal](13, 5) NULL, [y_etrs89] [decimal](13, 5) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-trafico_dispositivo_medicion', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 411, '7:20ee9f1e2a5797bf226dc7be382cfdbf', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::table-trafico_incidencia::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [tipo_incidencia] [varchar](200) NULL, [date_posted] [datetime] NULL, [end_date] [datetime] NOT NULL, [start_date] [datetime] NOT NULL, [num_sentidos] [int] NULL, [num_carriles] [int] NULL, [es_recurrente] [bit] NULL, [fecha_fin_prevista] [datetime] NULL, [recurrencia] [varchar](200) NULL, [incidencia_tramo] [varchar](50) NOT NULL, [x_etrs89] [decimal](13, 5) NOT NULL, [y_etrs89] [decimal](13, 5) NOT NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-trafico_incidencia', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 412, '7:8f4d3243dcd82b6dba9bd92c06c40da8', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::table-trafico_observacion::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_observacion] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [observed_property] [varchar](100) NOT NULL, [result_time] [datetime] NOT NULL, [has_simple_result] [decimal](12, 2) NOT NULL, [has_feature_interest] [varchar](50) NOT NULL, [validada] [bit] NULL, [phenomenon_time_beginning] [varchar](200) NULL, [phenomenon_time_end] [varchar](200) NULL, [unidad_medida] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-trafico_observacion', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 413, '7:153ff2c977073c9936ee4de56e15eda3', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::table-trafico_observacion_dispostivo::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [id_observacion] [varchar](50) NOT NULL, [made_by_sensor] [varchar](50) NOT NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-trafico_observacion_dispostivo', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 414, '7:8b28742da7b0bc37f771ff182225283e', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::table-trafico_tramo::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_tramo] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NOT NULL, [x_etrs89_inicio_tramo] [decimal](13, 5) NOT NULL, [y_etrs89_inicio_tramo] [decimal](13, 5) NOT NULL, [x_etrs89_fin_tramo] [decimal](13, 5) NULL, [y_etrs89_fin_tramo] [decimal](13, 5) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-trafico_tramo', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 415, '7:9f65a9f4c3f82863fc905412d55ba532', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::table-trafico_tramo_via::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [id_tramo] [varchar](50) NOT NULL, [id_via] [varchar](50) NULL, [title_via] [varchar](400) NULL, [tipo_via] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-trafico_tramo_via', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 416, '7:bfad8147c02d6029b19e6c3efc28b4d4', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::PK-table-trafico_dispositivo_medicion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD CONSTRAINT [PK_trafico_dispositivo] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-trafico_dispositivo_medicion', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 417, '7:a6301aa724258852b121044e2a284599', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::PK-table-trafico_incidencia::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD CONSTRAINT [PK_trafico_incidencia] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-trafico_incidencia', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 418, '7:52e802f8d9670a11538fae12f21fc231', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::PK-table-trafico_observacion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] ADD CONSTRAINT [PK_trafico_observacio] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-trafico_observacion', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 419, '7:8cdbde3bdb7a31361be9e0111fcd4dcf', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::PK-table-trafico_observacion_dispostivo::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] ADD CONSTRAINT [PK_trafico_observacion_disp] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-trafico_observacion_dispostivo', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 420, '7:a2899200709e8f2d11e4c788f627854f', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::PK-table-trafico_tramo::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo] ADD CONSTRAINT [PK_trafico_tramo] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-trafico_tramo', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 421, '7:61a559c1bcdc6cb4aaf8619bd051c046', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::PK-table-trafico_tramo_via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] ADD CONSTRAINT [PK_trafico_tramo_via] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-trafico_tramo_via', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 422, '7:35db62c26253b46a0d89bd8512f41b05', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::unique-id-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD CONSTRAINT [unique-id-traf_disp] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-01', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 423, '7:933cdb85dac550354ee3d64a556419b0', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::unique-id-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD CONSTRAINT [unique-id-traf_incid] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-02', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 424, '7:b3607735bfb34cb974f62b4a9172fe76', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::unique-id-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] ADD CONSTRAINT [unique-id-traf_obs] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-03', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 425, '7:b3fb6365f231cb8daac67d8b7996fe1e', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::unique-id-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] ADD CONSTRAINT [unique-id-traf_obs_dis] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-04', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 426, '7:3e13dcd6d8ec33d13bbda8e3152a8c35', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::unique-id-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo] ADD CONSTRAINT [unique-id-traf_tramo] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-05', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 427, '7:45fc4c7182f1a1a4e600bb1d420519bd', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::unique-id-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] ADD CONSTRAINT [unique-id-traf_tra_via] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-06', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 428, '7:96ae3bdb82c5ede9b60c11ce692436a1', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::INDEX-trafico-1::Localidata
CREATE NONCLUSTERED INDEX [index_tramo_id_disp] ON [schema_ciudadesAbiertas].[trafico_dispositivo_medicion]([monitorea])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-trafico-1', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 429, '7:71e866e68caa2c8777417663b80de969', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::INDEX-trafico-2::Localidata
CREATE NONCLUSTERED INDEX [index_tramo_id_inc] ON [schema_ciudadesAbiertas].[trafico_incidencia]([incidencia_tramo])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-trafico-2', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 430, '7:6b03ed7c7f1ab392870bd7a7fbc08019', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::INDEX-trafico-3::Localidata
CREATE NONCLUSTERED INDEX [index_tramo_id_obs] ON [schema_ciudadesAbiertas].[trafico_observacion]([has_feature_interest])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-trafico-3', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 431, '7:b380e5384b6f1fd8ce51a1610e59c192', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::INDEX-trafico-4::Localidata
CREATE NONCLUSTERED INDEX [index_obs_id_obs_di] ON [schema_ciudadesAbiertas].[trafico_observacion_dispostivo]([id_observacion])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-trafico-4', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 432, '7:68efb73cd5bf848f816de8d9fcf8d0b2', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::INDEX-trafico-5::Localidata
CREATE NONCLUSTERED INDEX [index_disp_id_obs_di] ON [schema_ciudadesAbiertas].[trafico_observacion_dispostivo]([made_by_sensor])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-trafico-5', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 433, '7:9be8148ead54249ae7b31de0d6ec3dc9', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml::INDEX-trafico-6::Localidata
CREATE NONCLUSTERED INDEX [index_tramo_id_travia] ON [schema_ciudadesAbiertas].[trafico_tramo_via]([id_tramo])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-trafico-6', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-table.xml', GETDATE(), 434, '7:e506eaa1e031482e2a4e125e711fc741', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml::data-trafico_dispositivo_medicion::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ([ikey], [id], [description], [num_sentidos], [num_carriles], [urbano], [tipo_equipo_trafico], [monitorea], [en_servicio], [frecuencia_medicion], [observes], [x_etrs89], [y_etrs89]) VALUES ('TRAFDISMED01', 'TRAFDISMED01', N'Dispositivo que detecta los cambios que se producen en un campo electromagnético cuando circula un vehículo (masa metálica) sobre un punto determinado de la calzada. Registra el número total de vehículos que pasan y pueden clasificarlos por su longitud, número de ejes y masas.', 2, 2, 1, 'lazo-magnetico', 'TRAFTRAM01', 0, 'P1m', 'carga', 440124.33000, 4474637.17000)
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ([ikey], [id], [description], [num_sentidos], [num_carriles], [urbano], [tipo_equipo_trafico], [monitorea], [en_servicio], [frecuencia_medicion], [observes], [x_etrs89], [y_etrs89]) VALUES ('TRAFDISMED02', 'TRAFDISMED02', 'C. GRAN VIA;San Bernardo-Garcia Molinas;San Bernardo', 2, 8, 1, 'lazo-magnetico', 'TRAFTRAM02', 1, 'P1m', 'carga', 439247.03900, 4475788.14600)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-trafico_dispositivo_medicion', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml', GETDATE(), 435, '7:3292e7c7d0b859292ae62c2196c3b475', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml::data-trafico_incidencia::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [end_date], [start_date], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [recurrencia], [incidencia_tramo], [x_etrs89], [y_etrs89]) VALUES ('1', 'TRAFINCI01', N'Corte de calles entre el cruce de Alcalá con Gran Vía y la Plaza de la Independencia', 'obra', '2020-03-31T08:00:00.000', '2020-05-03T23:59:00.000', '2020-03-31T23:00:00.000', 2, 8, 0, '2020-05-03T23:59:00.000', 'Sin recurrencia', 'TRAFTRAM01', 440124.33000, 4474637.17000)
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [end_date], [start_date], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [recurrencia], [incidencia_tramo], [x_etrs89], [y_etrs89]) VALUES ('2', 'TRAFINCI02', N'Corte de calles entre el paseo de Prado y calle Génova', 'obra', '2020-03-31T08:00:00.000', '2020-05-03T23:59:00.000', '2020-03-31T23:00:00.000', 2, 2, 0, '2020-05-03T23:59:00.000', 'Sin recurrencia', 'TRAFTRAM02', 440124.43000, 4474637.27000)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-trafico_incidencia', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml', GETDATE(), 436, '7:ddadef23b3443d322d7c06516cb701df', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml::data-trafico_observacion::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_observacion] ([ikey], [id], [observed_property], [result_time], [has_simple_result], [has_feature_interest], [validada], [phenomenon_time_beginning], [phenomenon_time_end], [unidad_medida]) VALUES ('1', 'TRAFOBS01', 'intensidad', '2020-04-01T12:45:00.000', 30.00, 'TRAFTRAM01', 0, '2020-04-01 12:45:00', '2020-04-01 12:46:00', N'Número total de vehículos')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_observacion] ([ikey], [id], [observed_property], [result_time], [has_simple_result], [has_feature_interest], [validada], [phenomenon_time_beginning], [phenomenon_time_end], [unidad_medida]) VALUES ('2', 'TRAFOBS02', 'velocidad', '2020-04-01T12:45:00.000', 97.00, 'TRAFTRAM02', 0, '2020-04-01 12:45:00', '2020-04-01 12:46:00', 'kilometros por segundo')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-trafico_observacion', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml', GETDATE(), 437, '7:7248755b19075b5aac8c710ec88eb395', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml::data-trafico_observacion_dispostivo::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] ([ikey], [id], [id_observacion], [made_by_sensor]) VALUES ('1', 'TRAFOBSDIPS01', 'TRAFOBS02', 'TRAFDISMED01')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_observacion_dispostivo] ([ikey], [id], [id_observacion], [made_by_sensor]) VALUES ('2', 'TRAFOBSDIPS02', 'TRAFOBS02', 'TRAFDISMED02')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-trafico_observacion_dispostivo', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml', GETDATE(), 438, '7:5cacfe9350a8517051b04cf2fa84380f', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml::data-trafico_tramo::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_tramo] ([ikey], [id], [description], [x_etrs89_inicio_tramo], [y_etrs89_inicio_tramo], [x_etrs89_fin_tramo], [y_etrs89_fin_tramo]) VALUES ('1', 'TRAFTRAM01', N'Calles entre el cruce de Alcalá con Gran Vía y la Plaza de la Independencia', 440124.33000, 4474637.17000, 440124.43000, 4474637.27000)
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_tramo] ([ikey], [id], [description], [x_etrs89_inicio_tramo], [y_etrs89_inicio_tramo], [x_etrs89_fin_tramo], [y_etrs89_fin_tramo]) VALUES ('2', 'TRAFTRAM02', N'Calles entre Paseo del prado y calle Génova', 440124.43000, 4474637.27000, 440124.53000, 4474637.37000)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-trafico_tramo', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml', GETDATE(), 439, '7:ef24c609eb6b0ad672549692351462ca', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml::data-trafico_tramo_via::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_tramo_via] ([ikey], [id], [id_tramo], [id_via], [title_via], [tipo_via]) VALUES ('1', 'TRAFTRAVIA01', 'TRAFTRAM01', '496400', '', '')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_tramo_via] ([ikey], [id], [id_tramo], [id_via], [title_via], [tipo_via]) VALUES ('2', 'TRAFTRAVIA02', 'TRAFTRAM01', '', 'BRAVO MURILLO', 'CALLE')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-trafico_tramo_via', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml', GETDATE(), 440, '7:d6c52c60f14123bb59face5a7ba22449', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml::DATA-TRAFICO-tag-1.24::Localidata
INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [TAG]) VALUES ('DATA-TRAFICO-tag-1.24', 'Localidata', 'liquibase/db-changelog-script-1.24.0-TRAFICO-data.xml', GETDATE(), 441, '7:4c263b7c16889b04cd18eb319fc0c9fb', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.4.2', '1.24')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::mod-1-tra_obs::Localidata
exec sp_rename '[schema_ciudadesAbiertas].[trafico_observacion].[phenomenon_time_beginning]', 'phenomenon_time'
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-1-tra_obs', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 442, '7:79b2b40cbcba5bf17ec1fb27f3024987', 'renameColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::mod-2-tra_obs::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] DROP COLUMN [phenomenon_time_end]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-2-tra_obs', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 443, '7:2c8017f08ac6f13007ca3caf82d9384e', 'dropColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::mod-3-tra_obs::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_observacion]
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] ALTER COLUMN [has_simple_result] [varchar](200)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-3-tra_obs', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 444, '7:e3f42ee941b3fabf08644a78092928e1', 'delete, modifyDataType', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::mod-4-tra_obs::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] DROP COLUMN [unidad_medida]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-4-tra_obs', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 445, '7:29738e8ccc6832536a402495ef4c0f0d', 'dropColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::mod-tra_obs_disp::Localidata
exec sp_rename '[schema_ciudadesAbiertas].[trafico_observacion_dispostivo]', 'trafico_observacion_disp'
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-tra_obs_disp', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 446, '7:617a4771e37f8e0fbce4718c125ae121', 'renameTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::table-tra_equipo::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_equipo] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [num_sentidos] [int] NULL, [num_carriles] [int] NULL, [urbano] [bit] NULL, [tipo_equipo_trafico] [varchar](200) NULL, [monitorea] [varchar](50) NULL, [x_etrs89] [decimal](13, 5) NULL, [y_etrs89] [decimal](13, 5) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-tra_equipo', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 447, '7:f8f84127ec8a5917e7d7abbfca1ba4c4', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::table-tra_propiedad_med::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL, [unidad_medida] [varchar](200) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-tra_propiedad_med', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 448, '7:596055a6a242146bf1c3c15eb5d620d5', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::table-tra_prop_inte::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[trafico_proper_interval] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [has_beginning] [datetime] NULL, [has_end] [datetime] NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-tra_prop_inte', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 449, '7:92be9918b1a699e4fb3815d5b1638baa', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::mod-2-tra_inc::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] DROP COLUMN [start_date]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-2-tra_inc', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 450, '7:5802879aafe988aa1a70c4ff7da48aa1', 'dropColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::mod-3-tra_inc::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] DROP COLUMN [end_date]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-3-tra_inc', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 451, '7:cebed69c58779f606d9629fcf48ffde6', 'dropColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::inte_terr_dispo::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [portal_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [street_address] [varchar](200)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [postal_code] [varchar](10)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [municipio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [municipio_title] [varchar](200)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [distrito_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [distrito_title] [varchar](400)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [barrio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD [barrio_title] [varchar](400)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('inte_terr_dispo', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 452, '7:e6e7a667d03a74bf9eeb62e34671fbce', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::inte_terr_inci::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [portal_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [street_address] [varchar](200)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [postal_code] [varchar](10)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [municipio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [municipio_title] [varchar](200)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [distrito_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [distrito_title] [varchar](400)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [barrio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD [barrio_title] [varchar](400)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('inte_terr_inci', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 453, '7:0289ac285636d9fff8bc9591451c8c85', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::inte_terr_tramo::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo] ADD [municipio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo] ADD [municipio_title] [varchar](200)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('inte_terr_tramo', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 454, '7:603eae52087fb9f2350c5f4e3f4876a3', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml::inte_terr_tramo_via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] ADD [municipio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] ADD [municipio_title] [varchar](200)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('inte_terr_tramo_via', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_table.xml', GETDATE(), 455, '7:74f55cf59fc4e070d3fda809eaa65aad', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::bor-tra_obs::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_observacion]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bor-tra_obs', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 456, '7:f5daaefd9679a28419717229ccbff1b0', 'delete', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::mod-5-tra_obs::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_observacion] ([ikey], [id], [observed_property], [result_time], [has_simple_result], [has_feature_interest], [validada], [phenomenon_time]) VALUES ('TRAFOBS01', 'TRAFOBS01', 'intensidad', '2020-04-01T12:45:00.000', 30.00, 'TRAFTRAM01', 0, '468a5a615f32d0dbee5937f86acf58b3')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_observacion] ([ikey], [id], [observed_property], [result_time], [has_simple_result], [has_feature_interest], [validada], [phenomenon_time]) VALUES ('TRAFOBS02', 'TRAFOBS02', 'velocidad', '2020-04-01T12:45:00.000', 97.00, 'TRAFTRAM02', 0, '79f474b097fa31a50fbb9c17357b22d8')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-5-tra_obs', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 457, '7:e29ec2be3cb34bd9450b99e9edbf7d6e', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::bor-tra_tramo_via::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_tramo_via]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bor-tra_tramo_via', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 458, '7:3a794fc6ba62d402f6f80bd817596d1b', 'delete', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::mod-3-tra_tramo_via::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_tramo_via] ([ikey], [id], [id_tramo], [id_via], [tipo_via], [title_via], [municipio_id], [municipio_title]) VALUES ('TRAFTRAVIA01', 'TRAFTRAVIA01', 'TRAFTRAM01', '496400', 'CALLE', 'MAUDES', '28079', 'Madrid')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_tramo_via] ([ikey], [id], [id_tramo], [id_via], [tipo_via], [title_via], [municipio_id], [municipio_title]) VALUES ('TRAFTRAVIA02', 'TRAFTRAVIA02', 'TRAFTRAM01', '627700', 'CALLE', N'RAIMUNDO FERNÁNDEZ VILLAVERDE', '28079', 'Madrid')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_tramo_via] ([ikey], [id], [id_tramo], [id_via], [tipo_via], [title_via], [municipio_id], [municipio_title]) VALUES ('3', 'TRAFTRAVIA03', 'TRAFTRAM02', '114600', 'CALLE', 'BRAVO MURILLO', '28079', 'Madrid')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-3-tra_tramo_via', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 459, '7:99d59158886b1c46d958246744a32c9a', 'insert (x3)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::bor-tra_disp_med::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_dispositivo_medicion]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bor-tra_disp_med', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 460, '7:7975711492b37cf7ab5aded69ff5354b', 'delete', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::mod-tra_disp_med::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ([ikey], [id], [description], [num_sentidos], [num_carriles], [urbano], [tipo_equipo_trafico], [monitorea], [en_servicio], [frecuencia_medicion], [observes], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('TRAFDISMED01', 'TRAFDISMED01', N'Dispositivo que detecta los cambios que se producen en un campo electromagnético cuando circula un vehículo (masa metálica) sobre un punto determinado de la calzada. Registra el número total de vehículos que pasan y pueden clasificarlos por su longitud, número de ejes y masas.', 2, 2, 1, 'lazo-magnetico', 'TRAFTRAM01', 0, '5 minutos', 'carga', 440124.33000, 4474637.17000, 'PORTAL000012', 'Bravo Murillo 265', '28039', '28079', 'Madrid', '28079606', N'Tetuán', '280796062', 'Cuatro Caminos')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ([ikey], [id], [description], [num_sentidos], [num_carriles], [urbano], [tipo_equipo_trafico], [monitorea], [en_servicio], [frecuencia_medicion], [observes], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id]) VALUES ('TRAFDISMED02', 'TRAFDISMED02', 'C. GRAN VIA;San Bernardo-Garcia Molinas;San Bernardo', 2, 8, 1, 'detector-bluetooth', 'TRAFTRAM02', 1, '3 minutos', 'carga', 439247.03900, 4475788.14600, 'PORTAL000119', 'Calle Cerro de la Plata, 4', '28007', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('mod-tra_disp_med', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 461, '7:51d62d9570d56241b5e0cb8ecfb83404', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::data-trafico_equipo::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_equipo] ([ikey], [id], [description], [num_sentidos], [num_carriles], [urbano], [tipo_equipo_trafico], [monitorea], [x_etrs89], [y_etrs89], [municipio_id], [municipio_title]) VALUES ('TRAFEQUI01', 'TRAFEQUI01', N'C. GRAN VIA;C. Alcalá', 2, 2, 1, 'radar', 'TRAFTRAM01', 440124.33000, 4474637.17000, '28006', 'Alcobendas')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_equipo] ([ikey], [id], [description], [num_sentidos], [num_carriles], [urbano], [tipo_equipo_trafico], [monitorea], [x_etrs89], [y_etrs89], [municipio_id], [municipio_title]) VALUES ('TRAFEQUI02', 'TRAFEQUI02', 'C. GRAN VIA;San Bernardo-Garcia Molinas;San Bernardo', 2, 8, 1, 'lector-matricula', 'TRAFTRAM02', 439247.03900, 4475788.14600, '28006', 'Alcobendas')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-trafico_equipo', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 462, '7:d3eb70e607ceca12547971f435265fed', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::PK-table-trafico_equipo::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_equipo] ADD CONSTRAINT [PK_trafico_equipo] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-trafico_equipo', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 463, '7:863be3429a6529a1b6cc6dc85e477bd4', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::unique-id-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_equipo] ADD CONSTRAINT [unique-id-traf_equi] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-07', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 464, '7:70102c5cafd5463800d579ccac19bf73', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::INDEX-trafico-7::Localidata
CREATE NONCLUSTERED INDEX [index_tramo_id_equip] ON [schema_ciudadesAbiertas].[trafico_equipo]([monitorea])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-trafico-7', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 465, '7:b771a4db81e9c07f7803833556544e5d', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::fk-trafico-7::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_equipo] ADD CONSTRAINT [traf_equipo_ibfk_1] FOREIGN KEY ([monitorea]) REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-trafico-7', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 466, '7:83b0d8fab7f108773f07ba8e2374663b', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::data-tra_propiedad_med::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ([ikey], [id], [description], [unidad_medida]) VALUES ('TRAPROMED01', 'carga', N'Propiedad de medición de carga', 'Porcentaje')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ([ikey], [id], [description], [unidad_medida]) VALUES ('TRAPROMED02', 'velocidad', N'Propiedad de medición de velocidad', N'Kilómetros por hora')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ([ikey], [id], [description], [unidad_medida]) VALUES ('TRAPROMED03', 'composicion', N'Propiedad de medición de composicion', 'Unidad de medida de composicion')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ([ikey], [id], [description], [unidad_medida]) VALUES ('TRAPROMED04', 'intensidad', N'Propiedad de medición de intensidad', N'vehículos por hora')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ([ikey], [id], [description], [unidad_medida]) VALUES ('TRAPROMED05', 'nivel', N'Propiedad de medición de nivel', 'Unidad de medida de nivel')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ([ikey], [id], [description], [unidad_medida]) VALUES ('TRAPROMED06', 'ocupacion', N'Propiedad de medición de ocupacion', N'Número de vehículos')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-tra_propiedad_med', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 467, '7:506d2c630af0b8dba8cfd9d742148ffb', 'insert (x6)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::PK-table-tra_propiedad::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ADD CONSTRAINT [PK_trafico_propiedad] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-tra_propiedad', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 468, '7:91704d1377775688a5e11533477157ba', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::unique-id-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_propiedad_medicion] ADD CONSTRAINT [unique-id-traf_pro] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-08', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 469, '7:671e4e66f2dec79eb1c93334d67c3781', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::data-tra_prop_inte::Localidata
INSERT INTO [schema_ciudadesAbiertas].[trafico_proper_interval] ([ikey], [id], [has_beginning], [has_end]) VALUES ('TRAPROINT01', '468a5a615f32d0dbee5937f86acf58b3', '2020-03-31T23:00:00.000', '2020-03-31T23:01:00.000')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_proper_interval] ([ikey], [id], [has_beginning], [has_end]) VALUES ('TRAPROINT02', '79f474b097fa31a50fbb9c17357b22d8', '2020-04-01T23:58:00.000', '2020-04-01T23:59:00.000')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-tra_prop_inte', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 470, '7:4822b25f6ece41a8636394ff78215e2b', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::PK-table-tra_prop_inte::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_proper_interval] ADD CONSTRAINT [PK_trafico_phenomenon] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-tra_prop_inte', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 471, '7:6112d8d15bdfd89fd2276a5c9fed47fb', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::unique-id-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_proper_interval] ADD CONSTRAINT [unique-id-traf_phen] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-09', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 472, '7:f15c6f9a194b1f9b5d61a4d58aff1af1', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::data-inci_terri::Localidata
DELETE FROM [schema_ciudadesAbiertas].[trafico_incidencia]
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [recurrencia], [incidencia_tramo], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('1', 'TRAFINCI01', 'Corte de calle', 'obra', '2020-03-31T08:00:00.000', 2, 8, 0, '2020-05-03T23:59:00.000', 'Sin recurrencia', 'TRAFTRAM01', 440124.33000, 4474637.17000, 'PORTAL00011', 'Bravo Murillo 111', '28039', '28079', 'Madrid', '28079606', N'Tetuán', '280796062', 'Cuatro Caminos')
GO

INSERT INTO [schema_ciudadesAbiertas].[trafico_incidencia] ([ikey], [id], [description], [tipo_incidencia], [date_posted], [num_sentidos], [num_carriles], [es_recurrente], [fecha_fin_prevista], [recurrencia], [incidencia_tramo], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('2', 'TRAFINCI02', 'Corte de calle', 'obra', '2020-03-31T08:00:00.000', 2, 2, 0, '2020-05-03T23:59:00.000', 'Sin recurrencia', 'TRAFTRAM02', 440124.43000, 4474637.27000, 'PORTAL00015', 'Bravo Murillo 113', '28039', '28079', 'Madrid', '28079606', N'Tetuán', '280796062', 'Cuatro Caminos')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-inci_terri', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 473, '7:67fb4cd75e6eeec12733b4653623eddf', 'delete, insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::data-tramo_terri::Localidata
UPDATE [schema_ciudadesAbiertas].[trafico_tramo] SET [municipio_id] = '28079', [municipio_title] = 'Madrid' WHERE id='TRAFTRAM01'
GO

UPDATE [schema_ciudadesAbiertas].[trafico_tramo] SET [municipio_id] = '28079', [municipio_title] = 'Madrid' WHERE id='TRAFTRAM02'
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-tramo_terri', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 474, '7:71e374858c1cf1bb7ba39faafa78732b', 'update (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml::DATA-TRAFICO-tag-1.24.1::Localidata
INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [TAG]) VALUES ('DATA-TRAFICO-tag-1.24.1', 'Localidata', 'liquibase/db-changelog-script-1.24.1-TRAFICO_data.xml', GETDATE(), 475, '7:0a699f63d6cba4a25754cacd222bc3b8', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.4.2', '1.24.1')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::table-cont_acus_estacion_medida::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [title] [varchar](4000) NULL, [fecha_alta] [datetime] NULL, [fecha_baja] [datetime] NULL, [postal_code] [varchar](10) NULL, [portal_id] [varchar](50) NULL, [municipio_id] [varchar](50) NULL, [municipio_title] [varchar](200) NULL, [distrito_id] [varchar](50) NULL, [distrito_title] [varchar](400) NULL, [barrio_id] [varchar](50) NULL, [barrio_title] [varchar](400) NULL, [street_address] [varchar](200) NULL, [equipamiento_id] [varchar](50) NULL, [equipamiento_title] [varchar](400) NULL, [tipo_equipamiento] [varchar](200) NULL, [observes] [varchar](50) NULL, [x_etrs89] [decimal](13, 5) NULL, [y_etrs89] [decimal](13, 5) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-cont_acus_estacion_medida', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 476, '7:53242cb534fb4e146ea9b8f79197e293', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::table-cont_acus_observacion::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [observed_property] [varchar](50) NULL, [result_time] [datetime] NULL, [has_simple_result] [decimal](12, 2) NULL, [validada] [bit] CONSTRAINT DF_cont_acus_observacion_validada DEFAULT 0 NULL, [tipo_medicion] [varchar](200) NULL, [tipo_emisor_predominante] [varchar](200) NULL, [tipo_intervalo_referencia] [varchar](200) NULL, [made_by_sensor] [varchar](50) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-cont_acus_observacion', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 477, '7:389aa76b79c4b88da3a8ddf577839eae', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::table-cont_acus_propiedad::Localidata
CREATE TABLE [schema_ciudadesAbiertas].[cont_acus_propiedad] ([ikey] [varchar](50) NOT NULL, [id] [varchar](50) NOT NULL, [description] [varchar](4000) NULL)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('table-cont_acus_propiedad', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 478, '7:00f0adf469fb93c7405af8175e01818d', 'createTable', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::PK-table-cont_acus_estacion_medida::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ADD CONSTRAINT [PK_cont_acus_es_med] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-cont_acus_estacion_medida', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 479, '7:7b76d0dad44261faa12235026f738447', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::PK-table-cont_acus_observacion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] ADD CONSTRAINT [PK_cont_acus_observacion] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-cont_acus_observacion', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 480, '7:4e21f4b7cab435aa0538d6b01a1a017d', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::PK-table-cont_acus_propiedad::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_propiedad] ADD CONSTRAINT [PK_cont_acus_propiedad_con] PRIMARY KEY ([ikey])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('PK-table-cont_acus_propiedad', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 481, '7:f1cc8ee512ce6cafcd9fc88f69bdc686', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::unique-id-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ADD CONSTRAINT [unique-id-con_acus_es_m] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-01', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 482, '7:6f326fb8f1b1cf39f50da561f5796ebb', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::unique-id-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] ADD CONSTRAINT [unique-id-cont_acus_ob] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-02', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 483, '7:4e647c3579fd75ebc4648a04ea795a3a', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::unique-id-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_propiedad] ADD CONSTRAINT [unique-id-cont_acus_prop] UNIQUE ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('unique-id-03', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 484, '7:590df6dfdd690d2fed305c502ec2abcf', 'addUniqueConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::INDEX-contaminacion-1::Localidata
CREATE NONCLUSTERED INDEX [index_cont_portal_id] ON [schema_ciudadesAbiertas].[cont_acus_estacion_medida]([portal_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-contaminacion-1', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 485, '7:c05f9461439406f3e24d3e1a0bb6486a', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml::INDEX-contaminacion-2::Localidata
CREATE NONCLUSTERED INDEX [index_cont_equip_id] ON [schema_ciudadesAbiertas].[cont_acus_estacion_medida]([equipamiento_id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('INDEX-contaminacion-2', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-table.xml', GETDATE(), 486, '7:6b3a63e1ab0a8fbdc17dd8598e5edd23', 'createIndex', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml::data-cont_acus_estacion_medida::Localidata
INSERT INTO [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ([ikey], [id], [title], [fecha_alta], [fecha_baja], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id], [street_address], [equipamiento_id], [equipamiento_title], [tipo_equipamiento], [observes], [x_etrs89], [y_etrs89]) VALUES ('CONTACUSTESTMED001', 'CONTACUSTESTMED001', 'Dispositivo que detecta los ruidos I.', '2020-03-31T08:00:00.000', '2020-07-30T09:00:00.000', '28100', 'PORTAL000119', '28006', 'Alcobendas', 'Norte', '28006011', 'Unico', '2800601', 'CL BLAS DE OTERO 4', 'EQ0044', 'Teatro Auditorio Ciudad de Alcobendas', N'Aparato de medición A.C.M.E', 'nivelRuido', 440124.33000, 4474637.17000)
GO

INSERT INTO [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ([ikey], [id], [title], [fecha_alta], [postal_code], [portal_id], [municipio_id], [municipio_title], [barrio_title], [barrio_id], [distrito_title], [distrito_id], [street_address], [equipamiento_id], [equipamiento_title], [tipo_equipamiento], [observes], [x_etrs89], [y_etrs89]) VALUES ('CONTACUSTESTMED002', 'CONTACUSTESTMED002', 'Dispositivo que detecta los ruidos II', '2020-04-15T08:00:00.000', '28100', 'PORTAL000105', '28079', 'Madrid', 'Cortes', '280796062', 'Centro', '28079606', 'CL PERCEBE, 42', 'EQID0004', N'Instalación Deportiva Municipal Básica Alameda de Osuna I', N'Aparato de medición A.C.M.E', 'nivelRuido', 440124.32000, 4474637.27000)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-cont_acus_estacion_medida', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml', GETDATE(), 487, '7:51f141adefe8b49cfbaf08f98896dfc1', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml::data-cont_acus_observacion::Localidata
INSERT INTO [schema_ciudadesAbiertas].[cont_acus_observacion] ([ikey], [id], [observed_property], [result_time], [has_simple_result], [validada], [tipo_medicion], [tipo_emisor_predominante], [tipo_intervalo_referencia], [made_by_sensor]) VALUES ('CONTACUSTOBVD001', 'CONTACUSTOBVD001', 'nivelRuido', '2020-04-15T08:00:00.000', 135.01, 0, 'LAS50', 'ferrocarriles', 'D', 'CONTACUSTESTMED001')
GO

INSERT INTO [schema_ciudadesAbiertas].[cont_acus_observacion] ([ikey], [id], [observed_property], [result_time], [has_simple_result], [validada], [tipo_medicion], [tipo_emisor_predominante], [tipo_intervalo_referencia], [made_by_sensor]) VALUES ('CONTACUSTOBVD002', 'CONTACUSTOBVD002', 'nivelRuido', '2020-05-15T08:00:00.000', 105.01, 0, 'LAS50', 'coches', 'D', 'CONTACUSTESTMED002')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-cont_acus_observacion', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml', GETDATE(), 488, '7:ae7a0f81d99b376a723664a1795bfb87', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml::data-cont_acus_propiedad::Localidata
INSERT INTO [schema_ciudadesAbiertas].[cont_acus_propiedad] ([ikey], [id], [description]) VALUES ('CONTACUSTPROP001', 'nivelRuido', 'nivelRuido')
GO

INSERT INTO [schema_ciudadesAbiertas].[cont_acus_propiedad] ([ikey], [id], [description]) VALUES ('CONTACUSTPROP002', 'nivelVibracion', 'nivelVibracion')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('data-cont_acus_propiedad', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml', GETDATE(), 489, '7:4d66820ecf153537e8511ece176d80dc', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml::DATA-CONT_ACUSTICA-tag-1.25::Localidata
INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [TAG]) VALUES ('DATA-CONT_ACUSTICA-tag-1.25', 'Localidata', 'liquibase/db-changelog-script-1.25-CONTAMINACION-ACUSTICA-data.xml', GETDATE(), 490, '7:95e43b2b39432caaf2b329da8b0ca822', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.4.2', '1.25')
GO

-- Changeset liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-table.xml::bici_estacion_table_2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_estacion] ADD [municipio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_estacion] ADD [municipio_title] [varchar](200)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_estacion] ADD [distrito_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_estacion] ADD [distrito_title] [varchar](400)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_estacion] ADD [barrio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_estacion] ADD [barrio_title] [varchar](400)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bici_estacion_table_2', 'Localidata', 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-table.xml', GETDATE(), 491, '7:f9184e4509e7801abb84f47e273f4116', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-table.xml::bici_punto_paso_table_2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [portal_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [street_address] [varchar](200)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [postal_code] [varchar](10)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [municipio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [municipio_title] [varchar](200)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [distrito_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [distrito_title] [varchar](400)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [barrio_id] [varchar](50)
GO

ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD [barrio_title] [varchar](400)
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bici_punto_paso_table_2', 'Localidata', 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-table.xml', GETDATE(), 492, '7:5683a84f6e5e8cfb2511c8e42be79052', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml::bici_estacion_data_1::Localidata
DELETE FROM [schema_ciudadesAbiertas].[bici_estacion]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bici_estacion_data_1', 'Localidata', 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml', GETDATE(), 493, '7:0de7eb652bb8ae893acc9632f4405905', 'delete', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml::bici_estacion_data_2::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bici_estacion] ([ikey], [id], [title], [portal_id], [street_address], [postal_code], [estado_estacion], [tipo_equipamiento], [fecha_alta], [fecha_baja], [observes_id], [observes_title], [x_etrs89], [y_etrs89], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('1', 'EST01', N'Estación Raimunro Férnandez Villaverde', 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'operativa', 'estacion-de-bicicletas', '2020-01-01', NULL, 'anclajesLibres', 'Anclajes libres', 440124.33000, 4474637.17000, 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_estacion] ([ikey], [id], [title], [portal_id], [street_address], [postal_code], [estado_estacion], [tipo_equipamiento], [fecha_alta], [fecha_baja], [observes_id], [observes_title], [x_etrs89], [y_etrs89], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('2', 'EST02', N'Estación calle atocha', NULL, 'calle atocha', '28021', 'operativa', 'estacion-de-bicicletas', '2020-01-01', NULL, 'anclajesLibres', 'Anclajes libres', 440944.44800, 4474468.32900, 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bici_estacion_data_2', 'Localidata', 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml', GETDATE(), 494, '7:d514611a432740263bc806133cbf34f0', 'insert (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml::bici_punto_paso_data_1::Localidata
DELETE FROM [schema_ciudadesAbiertas].[bici_punto_paso]
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bici_punto_paso_data_1', 'Localidata', 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml', GETDATE(), 495, '7:93406f320aeb9248e9542a5b833d2fce', 'delete', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml::bici_punto_paso_data_2::Localidata
INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('1', 'PPASO01', '2020-01-09T07:00:00.000', 'TRA04', 1, 440124.33000, 4474637.17000, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('2', 'PPASO02', '2020-01-09T07:15:00.000', 'TRA04', 2, 439247.03900, 4475788.14600, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('3', 'PPASO03', '2020-01-09T07:30:00.000', 'TRA04', 3, 440124.33000, 4474637.17000, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('4', 'PPASO04', '2020-01-09T08:00:00.000', 'TRA01', 1, 440124.33000, 4474637.17000, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('5', 'PPASO05', '2020-01-09T08:15:00.000', 'TRA01', 2, 440944.44800, 4474468.32900, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('6', 'PPASO06', '2020-01-09T09:00:00.000', 'TRA02', 1, 440124.33000, 4474637.17000, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('7', 'PPASO07', '2020-01-09T09:15:00.000', 'TRA02', 2, 440678.92700, 4475099.73100, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('8', 'PPASO08', '2020-01-09T10:00:00.000', 'TRA03', 1, 440124.33000, 4474637.17000, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[bici_punto_paso] ([ikey], [id], [fecha_paso], [trayecto_id], [orden], [x_etrs89], [y_etrs89], [portal_id], [street_address], [postal_code], [municipio_id], [municipio_title], [distrito_id], [distrito_title], [barrio_id], [barrio_title]) VALUES ('9', 'PPASO09', '2020-01-09T10:15:00.000', 'TRA03', 2, 440176.19400, 4473788.50900, 'PORTAL000101', N'CALLE DE RAIMUNDO FERNÁNDEZ VILLAVERDE NUMERO 43', '28003', 'madrid', 'Madrid', 'tetuan', N'Tetuán', 'bellas-vistas', 'Bellas Vistas')
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('bici_punto_paso_data_2', 'Localidata', 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml', GETDATE(), 496, '7:3dcd6657a88bc39d7bac2da472be54f8', 'insert (x9)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml::DATA-ORGANIGRAMA-tag-1.98.1::Localidata
INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [TAG]) VALUES ('DATA-ORGANIGRAMA-tag-1.98.1', 'Localidata', 'liquibase/db-changelog-script-1.98.1-BICICLETA-PUBLICA-data.xml', GETDATE(), 497, '7:b6989454c74b80ab03c10d10417144a8', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.4.2', '1.98.1')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-agrupacion_comercial::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] ADD CONSTRAINT [fk_local_comercial_agrupacion] FOREIGN KEY ([agrupacion_comercial]) REFERENCES [schema_ciudadesAbiertas].[local_comercial_agrupacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-agrupacion_comercial', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 498, '7:ecf08d83bed863aed57e49364d7cb23e', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-tiene_terraza::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] ADD CONSTRAINT [fk_local_comercial_terraza] FOREIGN KEY ([tiene_terraza]) REFERENCES [schema_ciudadesAbiertas].[local_comercial_terraza] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-tiene_terraza', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 499, '7:f40d67b5f7f63cf8bdc3847c5122051e', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-tiene_licencia_apertura::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[local_comercial] ADD CONSTRAINT [fk_local_comercial_licencia] FOREIGN KEY ([tiene_licencia_apertura]) REFERENCES [schema_ciudadesAbiertas].[local_comercial_licencia] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-tiene_licencia_apertura', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 500, '7:15683817f79d73268482b34b13cc31fc', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-made-by-sensor-table-calidad-aire-observacion::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_observacion] ADD CONSTRAINT [fk_estacion] FOREIGN KEY ([made_by_sensor]) REFERENCES [schema_ciudadesAbiertas].[calidad_aire_estacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-made-by-sensor-table-calidad-aire-observacion', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 501, '7:be8d7e6e7bbbdb469265c8faac4335c1', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-made-by-sensor-table-calidad-aire-sensor::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[calidad_aire_sensor] ADD CONSTRAINT [fk_estacion_sensor] FOREIGN KEY ([is_hosted_by]) REFERENCES [schema_ciudadesAbiertas].[calidad_aire_estacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-made-by-sensor-table-calidad-aire-sensor', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 502, '7:c665b65078dde4c75d1555164717c771', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-UNIDAD-RAIZ::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] ADD CONSTRAINT [fk_unidad_raiz] FOREIGN KEY ([unidad_raiz]) REFERENCES [schema_ciudadesAbiertas].[organigrama] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-UNIDAD-RAIZ', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 503, '7:b481b7381c5d9707290dc07aa22cccfb', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-UNIT-Of::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[organigrama] ADD CONSTRAINT [fk_unit_of] FOREIGN KEY ([unit_of]) REFERENCES [schema_ciudadesAbiertas].[organigrama] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-UNIT-Of', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 504, '7:245b341c9fa1a8b5fbd8321d25262151', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-Index-table-callejero_tramo_via-via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[callejero_tramo_via] ADD CONSTRAINT [callejero_tramo_via_ibfk_1] FOREIGN KEY ([via]) REFERENCES [schema_ciudadesAbiertas].[callejero_via] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-Index-table-callejero_tramo_via-via', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 505, '7:ef681e174646c53b771b5e356c83c459', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-Index-table-portal_via-via::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[callejero_portal] ADD CONSTRAINT [callejero_portal_ibfk_1] FOREIGN KEY ([via]) REFERENCES [schema_ciudadesAbiertas].[callejero_via] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-Index-table-portal_via-via', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 506, '7:1aa1af180196093a47ae9b7f9cbb5a06', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-documento-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_document] ADD CONSTRAINT [fk_documento_to_evento] FOREIGN KEY ([event_id]) REFERENCES [schema_ciudadesAbiertas].[agenda_m_evento] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-documento-to-evento', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 507, '7:71b016597c44ff71e9c125be2be1dadb', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-rolEvento-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_rolintegranteevento] ADD CONSTRAINT [fk_rol_i_evento_to_evento] FOREIGN KEY ([event_id]) REFERENCES [schema_ciudadesAbiertas].[agenda_m_evento] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-rolEvento-to-evento', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 508, '7:1159d22a81998f6fbc4770f4c7166e04', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::FK-eveto-to-evento::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[agenda_m_evento] ADD CONSTRAINT [fk_evento_to_evento_super] FOREIGN KEY ([super_event_id]) REFERENCES [schema_ciudadesAbiertas].[agenda_m_evento] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('FK-eveto-to-evento', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 509, '7:a1323ec77a041c4e72259e2582edd73d', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-33::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_award] ADD CONSTRAINT [contratos_award_ibfk_1] FOREIGN KEY ([is_supplier_for]) REFERENCES [schema_ciudadesAbiertas].[contratos_organization] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-33', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 510, '7:8e709547aeb2009b439922f246f1b506', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-34::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] ADD CONSTRAINT [contratos_lot_ibfk_1] FOREIGN KEY ([tender_id]) REFERENCES [schema_ciudadesAbiertas].[contratos_tender] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-34', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 511, '7:e7e023fdd55f34bb5f1b4d308757652a', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-35::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot] ADD CONSTRAINT [contratos_lot_ibfk_2] FOREIGN KEY ([has_supplier]) REFERENCES [schema_ciudadesAbiertas].[contratos_award] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-35', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 512, '7:6bafd84560a77e7d3634cf71b42bc49c', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-36::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] ADD CONSTRAINT [contratos_lot_rel_item_ibfk_1] FOREIGN KEY ([lot_id]) REFERENCES [schema_ciudadesAbiertas].[contratos_lot] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-36', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 513, '7:9fda8dbb3ad43161c3169483fe95e5d0', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-37::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_lot_rel_item] ADD CONSTRAINT [contratos_lot_rel_item_ibfk_2] FOREIGN KEY ([item_id]) REFERENCES [schema_ciudadesAbiertas].[contratos_item] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-37', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 514, '7:97b7828df064323c492aeee2d514dd82', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-38::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] ADD CONSTRAINT [contratos_process_ibfk_1] FOREIGN KEY ([has_tender]) REFERENCES [schema_ciudadesAbiertas].[contratos_tender] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-38', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 515, '7:4959bd937415c79971966e890381124c', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-39::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_process] ADD CONSTRAINT [contratos_process_ibfk_2] FOREIGN KEY ([is_buyer_for]) REFERENCES [schema_ciudadesAbiertas].[contratos_organization] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-39', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 516, '7:34e2b7c6b8187843857238f35a9d4b39', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-40::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender] ADD CONSTRAINT [contratos_tender_ibfk_1] FOREIGN KEY ([has_supplier]) REFERENCES [schema_ciudadesAbiertas].[contratos_award] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-40', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 517, '7:6c293557a276c19d7b9df8bb59c9ce84', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-41::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] ADD CONSTRAINT [cont_tender_r_item_ibfk_1] FOREIGN KEY ([tender_id]) REFERENCES [schema_ciudadesAbiertas].[contratos_tender] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-41', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 518, '7:df697caf25c3802fa9e895ec23a8dc62', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-con-42::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[contratos_tender_rel_item] ADD CONSTRAINT [cont_tender_r_item_ibfk_2] FOREIGN KEY ([item_id]) REFERENCES [schema_ciudadesAbiertas].[contratos_item] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-con-42', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 519, '7:6e1f223eded203448b0886ac77de5bc3', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-20::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] ADD CONSTRAINT [cube_dsd_rel_dim_ibfk_1] FOREIGN KEY ([cube_key]) REFERENCES [schema_ciudadesAbiertas].[cube_dsd] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('DSD_Tables-20', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 520, '7:006da3ca9143796bbca437279710342e', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-21::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] ADD CONSTRAINT [cube_dsd_rel_mea_ibfk_1] FOREIGN KEY ([cube_key]) REFERENCES [schema_ciudadesAbiertas].[cube_dsd] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('DSD_Tables-21', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 521, '7:446a9c2b1733811cbdd76d841db7fbea', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-22::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_measure] ADD CONSTRAINT [cube_dsd_rel_mea_ibfk_2] FOREIGN KEY ([measure_key]) REFERENCES [schema_ciudadesAbiertas].[cube_dsd_measure] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('DSD_Tables-22', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 522, '7:06d8158696ea74b0d02ba83b2114e5e9', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-23::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_dimension_value] ADD CONSTRAINT [dsd_dim_value_ibfk_1] FOREIGN KEY ([dimension_key]) REFERENCES [schema_ciudadesAbiertas].[cube_dsd_dimension] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('DSD_Tables-23', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 523, '7:f79e77fc8ebdab233ed4d0b08d9564e8', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::DSD_Tables-24::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cube_dsd_rel_dimension] ADD CONSTRAINT [dsd_rel_dim_ibfk_2] FOREIGN KEY ([dimension_key]) REFERENCES [schema_ciudadesAbiertas].[cube_dsd_dimension] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('DSD_Tables-24', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 524, '7:fad3832a6e2b68ee36488a1ea1421928', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-42::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_autonomia] ADD CONSTRAINT [t_autonomia_ibfk_1] FOREIGN KEY ([pais]) REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-42', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 525, '7:25938f44c39ab00e358fef8d0cd37ca7', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-43::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] ADD CONSTRAINT [t_barrio_ibfk_1] FOREIGN KEY ([pais]) REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-43', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 526, '7:c2fdc3ccb37477017ace3d0dedf40507', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-44::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] ADD CONSTRAINT [t_barrio_ibfk_2] FOREIGN KEY ([autonomia]) REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-44', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 527, '7:fd7ed26ffbd2d49ff6e78b1ee9a4635e', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-45::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] ADD CONSTRAINT [t_barrio_ibfk_3] FOREIGN KEY ([provincia]) REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-45', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 528, '7:7beb3305830d2586b87a1b75a4c26539', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-46::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] ADD CONSTRAINT [t_barrio_ibfk_4] FOREIGN KEY ([municipio]) REFERENCES [schema_ciudadesAbiertas].[territorio_municipio] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-46', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 529, '7:d9556cfd972c80b03dabae4557cd3c8f', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-47::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_barrio] ADD CONSTRAINT [t_barrio_ibfk_5] FOREIGN KEY ([distrito]) REFERENCES [schema_ciudadesAbiertas].[territorio_distrito] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-47', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 530, '7:5351d8a537e2899d70e454e46a3aa514', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-48::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] ADD CONSTRAINT [t_distrito_ibfk_1] FOREIGN KEY ([pais]) REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-48', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 531, '7:2ae8f1a6fcb266bb13721389372ad566', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-49::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] ADD CONSTRAINT [t_distrito_ibfk_2] FOREIGN KEY ([autonomia]) REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-49', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 532, '7:5b6632b17913e4074a36a859be33ae7d', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-50::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] ADD CONSTRAINT [t_distrito_ibfk_3] FOREIGN KEY ([provincia]) REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-50', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 533, '7:c997e9f709fb28463fc47f9a474c45df', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-51::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_distrito] ADD CONSTRAINT [t_distrito_ibfk_4] FOREIGN KEY ([municipio]) REFERENCES [schema_ciudadesAbiertas].[territorio_municipio] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-51', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 534, '7:739b5ad40d4cf32c0b7bb02f4826f7f6', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-52::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] ADD CONSTRAINT [t_municipio_ibfk_1] FOREIGN KEY ([pais]) REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-52', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 535, '7:7ea7d3f2ea76f5cce7a9967850f9d45c', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-53::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] ADD CONSTRAINT [t_municipio_ibfk_2] FOREIGN KEY ([autonomia]) REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-53', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 536, '7:ca6f03e5e55024c2500c2d5ce00f1147', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-54::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_municipio] ADD CONSTRAINT [t_municipio_ibfk_3] FOREIGN KEY ([provincia]) REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-54', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 537, '7:edb5699fb673140d15ee0860a78be7db', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-55::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] ADD CONSTRAINT [t_provincia_ibfk_1] FOREIGN KEY ([pais]) REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-55', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 538, '7:0e686c2dcbb45d2d0ca68b0d8afc4b00', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-56::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_provincia] ADD CONSTRAINT [t_provincia_ibfk_2] FOREIGN KEY ([autonomia]) REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-56', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 539, '7:ba49ecaa43a8bc34c2113f7b1147458e', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-57::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] ADD CONSTRAINT [t_seccion_ibfk_1] FOREIGN KEY ([pais]) REFERENCES [schema_ciudadesAbiertas].[territorio_pais] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-57', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 540, '7:6fb1150ea9182e1bcc06850b574623b3', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-58::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] ADD CONSTRAINT [t_seccion_ibfk_2] FOREIGN KEY ([autonomia]) REFERENCES [schema_ciudadesAbiertas].[territorio_autonomia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-58', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 541, '7:4ceca60fdce40e0b8abaf6f3a0b1d77d', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-59::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] ADD CONSTRAINT [t_seccion_ibfk_3] FOREIGN KEY ([provincia]) REFERENCES [schema_ciudadesAbiertas].[territorio_provincia] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-59', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 542, '7:d1433cdae4ffb93e206ebd489153c8d5', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-60::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] ADD CONSTRAINT [t_seccion_ibfk_4] FOREIGN KEY ([municipio]) REFERENCES [schema_ciudadesAbiertas].[territorio_municipio] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-60', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 543, '7:f52856b73874c8ff66b70f5f49b58bf2', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::TablasTerritorio-61::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[territorio_seccion] ADD CONSTRAINT [t_seccion_ibfk_5] FOREIGN KEY ([distrito]) REFERENCES [schema_ciudadesAbiertas].[territorio_distrito] ([ikey]) ON UPDATE NO ACTION ON DELETE NO ACTION
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('TablasTerritorio-61', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 544, '7:9f698b3e1da0ef17d20de77596dcad10', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-01::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_anclaje] ADD CONSTRAINT [bibileta_anclaje_ibfk_1] FOREIGN KEY ([estacion_bicicleta_id]) REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-01', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 545, '7:7efba45c780332dff2987f7a6e955001', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-02::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] ADD CONSTRAINT [bicicleta_trayecto_ibfk_1] FOREIGN KEY ([usuario_id]) REFERENCES [schema_ciudadesAbiertas].[bici_usuario] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-02', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 546, '7:a71c590bcc12d8c5cd7f2d0eb7a8242a', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-03::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] ADD CONSTRAINT [bicicleta_trayecto_ibfk_2] FOREIGN KEY ([bicicleta_id]) REFERENCES [schema_ciudadesAbiertas].[bici_bicicleta] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-03', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 547, '7:250c7ef618e3deff314b94ba98cfadaf', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-04::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] ADD CONSTRAINT [bicicleta_trayecto_ibfk_3] FOREIGN KEY ([estacion_bicicleta_origen_id]) REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-04', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 548, '7:d285abad83b28eca286f8dc956216c15', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-05::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] ADD CONSTRAINT [bicicleta_trayecto_ibfk_4] FOREIGN KEY ([estacion_bicicleta_destino_id]) REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-05', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 549, '7:e4636e13e1f82ee88d6b27be872f9fae', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-06::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] ADD CONSTRAINT [bicicleta_trayecto_ibfk_5] FOREIGN KEY ([anclaje_origen_id]) REFERENCES [schema_ciudadesAbiertas].[bici_anclaje] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-06', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 550, '7:acc44c55d6586bb872ce4e522277473f', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-07::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_trayecto] ADD CONSTRAINT [bicicleta_trayecto_ibfk_6] FOREIGN KEY ([anclaje_destino_id]) REFERENCES [schema_ciudadesAbiertas].[bici_anclaje] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-07', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 551, '7:5b3385ca302afcadc9468ec15ff835dd', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-08::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_punto_paso] ADD CONSTRAINT [bicicleta_punto_de_paso_ibfk_1] FOREIGN KEY ([trayecto_id]) REFERENCES [schema_ciudadesAbiertas].[bici_trayecto] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-08', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 552, '7:d6d96fb8109a6fc0c820455bec28e004', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-bicicleta-09::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[bici_observacion] ADD CONSTRAINT [bicicleta_observacion_ibfk_1] FOREIGN KEY ([made_by_sensor]) REFERENCES [schema_ciudadesAbiertas].[bici_estacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-bicicleta-09', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 553, '7:a55bc8011283402a86d05a172b37d5f1', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_documentacion] ADD CONSTRAINT [fk_convenio_doc_id] FOREIGN KEY ([convenio_id]) REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-1', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 554, '7:ce21375ee8bb8916595521cf704dab5c', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] ADD CONSTRAINT [fk_convenio_prorroga] FOREIGN KEY ([es_variacion_id]) REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-2', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 555, '7:6f30e305a2bdb6f5e9ffb5ab66fb1f90', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] ADD CONSTRAINT [fk_convenio_susc_entidad_id] FOREIGN KEY ([convenio_id]) REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-3', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 556, '7:234f54bd2cb98f39dc4290288edbfaba', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio_susc_entidad] ADD CONSTRAINT [fk_convenio_susc_org_id] FOREIGN KEY ([organization_id]) REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-4', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 557, '7:8932ffa9237dd68e146426c9bc466ad4', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] ADD CONSTRAINT [fk_con_rel_firma_ayto_id] FOREIGN KEY ([convenio_id]) REFERENCES [schema_ciudadesAbiertas].[convenio] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-5', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 558, '7:2bac324a501d8b4e1261b5cd1f10b09d', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_ayto] ADD CONSTRAINT [fk_con_rel_firma_ayto_org] FOREIGN KEY ([organization_id]) REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-6', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 559, '7:60fe7cb89708349809ad32897f228966', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-7::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] ADD CONSTRAINT [fk_con_rel_firma_ent_id] FOREIGN KEY ([entidad_id]) REFERENCES [schema_ciudadesAbiertas].[convenio_susc_entidad] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-7', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 560, '7:ed21230355f258c48f830784ae1f8b78', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-8::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[conv_rel_firmante_entidad] ADD CONSTRAINT [fk_con_rel_firma_ent_org] FOREIGN KEY ([organization_id]) REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-8', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 561, '7:d5fa3e3665436958e4c2fbb78969cbfc', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-9::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] ADD CONSTRAINT [fk_convenio_org] FOREIGN KEY ([organization_id]) REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-9', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 562, '7:66102e756b18c44b86addfb06c64dcf0', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-convenio-10::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[convenio] ADD CONSTRAINT [fk_convenio_org_obliga] FOREIGN KEY ([org_id_obligado_presta]) REFERENCES [schema_ciudadesAbiertas].[convenio_organization] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-convenio-10', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 563, '7:7f0d6ab2d96d05bfcc11297683697ca4', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto] ADD CONSTRAINT [presupuesto_liquidacion_ibfk_1] FOREIGN KEY ([liquidacion]) REFERENCES [schema_ciudadesAbiertas].[presupuesto_liquidacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-presupuesto-1', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 564, '7:4494ae6017a41da56b2c78742ba5d7f9', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_gasto] ADD CONSTRAINT [presupuesto_gasto_ibfk_1] FOREIGN KEY ([presupuesto]) REFERENCES [schema_ciudadesAbiertas].[presupuesto] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-presupuesto-2', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 565, '7:9fa3f1a657fbd8bc203e1c5b9f67c10c', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ingreso] ADD CONSTRAINT [presupuesto_ingreso_ibfk_1] FOREIGN KEY ([presupuesto]) REFERENCES [schema_ciudadesAbiertas].[presupuesto] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-presupuesto-3', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 566, '7:3d5b47a4abf3ee9c44fe1ea5e9804af4', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_gasto] ADD CONSTRAINT [pres_ejecucion_gasto_ibfk_1] FOREIGN KEY ([presupuesto_gasto]) REFERENCES [schema_ciudadesAbiertas].[presupuesto_gasto] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-presupuesto-4', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 567, '7:222e1a8029197b5327fdb893d54a92e2', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-presupuesto-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[presupuesto_ejecucion_ingreso] ADD CONSTRAINT [pres_ejecucion_ingreso_ibfk_1] FOREIGN KEY ([presupuesto_ingreso]) REFERENCES [schema_ciudadesAbiertas].[presupuesto_ingreso] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-presupuesto-5', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 568, '7:4c18ff3fbade86cf97feb350cd404e91', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ADD CONSTRAINT [traf_disp_medicion_ibfk_1] FOREIGN KEY ([monitorea]) REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-trafico-1', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 569, '7:7a1cb913eb2e9451a5cb784f5bf7c579', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_incidencia] ADD CONSTRAINT [trafico_incidencia_ibfk_1] FOREIGN KEY ([incidencia_tramo]) REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-trafico-2', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 570, '7:df7f18d125f6c67160a5ec7e5d98769a', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion] ADD CONSTRAINT [trafico_observacion_ibfk_1] FOREIGN KEY ([has_feature_interest]) REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-trafico-3', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 571, '7:660a13feb5e688cf2df5a60f61da5e83', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-4::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp] ADD CONSTRAINT [traf_obse_dispostivo_ibfk_1] FOREIGN KEY ([id_observacion]) REFERENCES [schema_ciudadesAbiertas].[trafico_observacion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-trafico-4', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 572, '7:4a4e8ce3f6467ff01f38c626ebf57a5b', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-5::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_observacion_disp] ADD CONSTRAINT [traf_obse_dispostivo_ibfk_2] FOREIGN KEY ([made_by_sensor]) REFERENCES [schema_ciudadesAbiertas].[trafico_dispositivo_medicion] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-trafico-5', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 573, '7:a5a54b43c37ff3a5074afaa74a77735d', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-trafico-6::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[trafico_tramo_via] ADD CONSTRAINT [trafico_tramo_via_ibfk_1] FOREIGN KEY ([id_tramo]) REFERENCES [schema_ciudadesAbiertas].[trafico_tramo] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-trafico-6', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 574, '7:0cbadb331a2aab2199f8f54e1573a0f0', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-cont_acustica-1::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ADD CONSTRAINT [cont_acustica_ibfk_1] FOREIGN KEY ([observes]) REFERENCES [schema_ciudadesAbiertas].[cont_acus_propiedad] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-cont_acustica-1', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 575, '7:1ae48e8d650a03dedc110baadd43f819', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-cont_acustica-2::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] ADD CONSTRAINT [cont_acustica_ibfk_2] FOREIGN KEY ([made_by_sensor]) REFERENCES [schema_ciudadesAbiertas].[cont_acus_estacion_medida] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-cont_acustica-2', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 576, '7:729d3b35064107f88dd49edc6b028653', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-1.99-FOREIGNKEY.xml::fk-cont_acustica-3::Localidata
ALTER TABLE [schema_ciudadesAbiertas].[cont_acus_observacion] ADD CONSTRAINT [cont_acustica_ibfk_3] FOREIGN KEY ([observed_property]) REFERENCES [schema_ciudadesAbiertas].[cont_acus_propiedad] ([id])
GO

INSERT INTO [schema_ciudadesAbiertas].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('fk-cont_acustica-3', 'Localidata', 'liquibase/db-changelog-script-1.99-FOREIGNKEY.xml', GETDATE(), 577, '7:b324f93b62749bfcddf1a433a0854bf1', 'addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Release Database Lock
UPDATE [schema_ciudadesAbiertas].[DATABASECHANGELOGLOCK] SET [LOCKED] = 0, [LOCKEDBY] = NULL, [LOCKGRANTED] = NULL WHERE [ID] = 1
GO

