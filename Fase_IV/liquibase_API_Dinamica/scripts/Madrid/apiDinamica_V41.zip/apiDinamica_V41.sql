-- *********************************************************************
-- Update Database Script
-- *********************************************************************
-- Change Log: liquibase/db-changelog-master.xml
-- Ran at: 10/3/21 12:40
-- Against: apiDinamica@jdbc:sqlserver://localhost:1433;useBulkCopyForBatchInsert=false;cancelQueryTimeout=-1;sslProtocol=TLS;jaasConfigurationName=SQLJDBCDriver;statementPoolingCacheSize=0;serverPreparedStatementDiscardThreshold=10;enablePrepareOnFirstPreparedStatementCall=false;fips=false;socketTimeout=0;authentication=NotSpecified;authenticationScheme=nativeAuthentication;xopenStates=false;sendTimeAsDatetime=true;trustStoreType=JKS;trustServerCertificate=false;TransparentNetworkIPResolution=true;serverNameAsACE=false;sendStringParametersAsUnicode=true;selectMethod=direct;responseBuffering=adaptive;queryTimeout=-1;packetSize=8000;multiSubnetFailover=false;loginTimeout=15;lockTimeout=-1;lastUpdateCount=true;encrypt=false;disableStatementPooling=true;databaseName=apiDinamica;columnEncryptionSetting=Disabled;applicationName=Microsoft JDBC Driver for SQL Server;applicationIntent=readwrite;
-- Liquibase version: 3.4.2
-- *********************************************************************

USE [bbdd_ciudadesAbiertas];
GO

-- Lock Database
UPDATE [schema_apiDinamica].[DATABASECHANGELOGLOCK] SET [LOCKED] = 1, [LOCKEDBY] = 'DESKTOP-R1EU6J4 (172.18.64.1)', [LOCKGRANTED] = '2021-03-10T12:40:29.358' WHERE [ID] = 1 AND [LOCKED] = 0
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:bbfce268af0d2d9b0cd2a79fb056cd15' WHERE [ID] = 'empty-ciudades-abiertas' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-0.0-EMPTY.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:c6a7f0cec14432c3580ddb06f076665d' WHERE [ID] = 'table-estadistica' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:5b193f221ba44f8eb280b29fd59d4bd9' WHERE [ID] = 'table-oauth-access-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:62688a22372dd8f7c8eb59d9b73e5367' WHERE [ID] = 'table-oauth-approvals' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:9c97e2436866044a413f80a52588f6ec' WHERE [ID] = 'table-oauth-client-details' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:9f9984fff938a4d5116ef6eceef4b01a' WHERE [ID] = 'table-oauth-client-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:4c9bea4afc85cd184227f460427a2a36' WHERE [ID] = 'table-oauth-code' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:e3ff3683926345e15d014b7a28cc0854' WHERE [ID] = 'table-oauth-refresh-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:f97726314258c37899248c395df39665' WHERE [ID] = 'table-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:e652fd1e9b69e8738bf20613721ffd39' WHERE [ID] = 'table-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:c9f4157fb185eb137532c79cc89c175d' WHERE [ID] = 'table-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:b116abd678e2679558ff6031f31802de' WHERE [ID] = 'table-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:a1332aa076e0b118d770d2bae9b42838' WHERE [ID] = 'table-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:75f9711a6dc621c6635f22013af7334a' WHERE [ID] = 'entidadBase' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:b814949a382eba3f205c37cf4c15a835' WHERE [ID] = 'PK-table-base' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:cf7262df414fc451d07c883ea8427f7d' WHERE [ID] = 'PK-table-estadistica' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:991ead7eb536d8f74a80d5b90d218f04' WHERE [ID] = 'PK-table-oauth-access-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:886facdc9619f43493dd0a19e244603c' WHERE [ID] = 'PK-table-oauth-client-details' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:52ec1ab295b5e32febc60b64be33e9c3' WHERE [ID] = 'PK-table-oauth-client-token' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:7332d9c46f9bb3dbeeee064f3ccfd49c' WHERE [ID] = 'PK-table-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:01de5d6fb10427b23ef21c9989e6d46b' WHERE [ID] = 'PK-table-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:96f86e27cdb2422b854506bb1fa4c84a' WHERE [ID] = 'Unique-field-user_roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:fbac76edc3b9fbfbe0d64e954e5335e6' WHERE [ID] = 'Indice-username-table-user_roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:44ef8adbd3fafab5f1d6824c4c88608e' WHERE [ID] = 'test_table' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:4a23177cad197983d3a937a990208e17' WHERE [ID] = 'PK-test_table' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:cac64f75dd0e532ddf7ae8abde9b4618' WHERE [ID] = 'function-TRANSLAT' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-SQLSERVER-FUNCIONES.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:ac1092dcc0f09000fcf50228877d4e5a' WHERE [ID] = 'data-user-roles' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:510f8602fefea9b6edb555dafb672949' WHERE [ID] = 'data-users' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:7ca7bbea357ee7c45482cc9354d94296' WHERE [ID] = 'data-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:3f8747c4c08ac9ea4ed9ccc39fc62093' WHERE [ID] = 'data-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:c641227f106de85fffe90f7a50316206' WHERE [ID] = 'data-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:b2bdffd928b73d74955a633b6bcd021d' WHERE [ID] = 'Datos testTable' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:e1e0ad7e580044e3f6f7629dbee76df0' WHERE [ID] = 'PK-table-group-authorities' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:565c0dfcc407b9e477d41bc6ffd558af' WHERE [ID] = 'PK-table-group-members' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:d17293c9f0aacd1f652b0d5b64ec81d1' WHERE [ID] = 'PK-table-groups' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:76bd6afc490b2fed2aff27036df3791b' WHERE [ID] = 'FK-USER-ROLE-USERNAME' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:34873c68b5f685c58167c1cd4650afaf' WHERE [ID] = 'FK-GROUP-MEMBERS-USERS' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:8dcbba0717c053e81702277e406a4c9d' WHERE [ID] = 'FK-GROUP-MEMBERS-GROUP' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:553a44914ab92b994237f8e1b522c9da' WHERE [ID] = 'FK-GROUP-AUTHORI-GROUP' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:5560655641c5ef77bca6b90c5b234724' WHERE [ID] = 'DATA-CORE-tag-1.0' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-1.0-CORE-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:9ac4909b8f99a72e22cd7d30c627a50e' WHERE [ID] = 'table-query' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:4017d45c8ad67feae1ad9d46c2a70895' WHERE [ID] = 'table-param' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:c30d38323ac392afb4ccf1e974cd75ec' WHERE [ID] = 'table-swagger-def' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:a5a26e86150267669c42019d515dbd20' WHERE [ID] = 'PK-table-query' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:4491b7be30662cc062b2e313564f0eaa' WHERE [ID] = 'PK-table-param' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:71324acfced822683c74215ecb48bfad' WHERE [ID] = 'Index-code-param' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:5cb72b3b5092d5e82de3794c18ed473e' WHERE [ID] = 'Index-code-swagger' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:46c4b7abea340f35a139a595b6d32aae' WHERE [ID] = 'FK-param-query' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:aea2a994f82fdf3ace7794cc62e3a10f' WHERE [ID] = 'DATA-CORE-tag-2.0' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-2.0-DYNAMIC_SQL-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:e5685f4ec490308877695c57fd3f8dd3' WHERE [ID] = 'table-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.01-SUBVENCION-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:1d7fe923c9d768f86d6a0187fe32e247' WHERE [ID] = 'PK-table-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.01-SUBVENCION-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:8b3b76691e1516ec4c31c243e8716f18' WHERE [ID] = 'Index-on-id-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.01-SUBVENCION-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:6af91eaef29568c2e5dd2200262f55fe' WHERE [ID] = 'data-subvencion' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.01-SUBVENCION-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:c57ad01d974ce1d4d907f75b7e315b66' WHERE [ID] = 'queries' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.01-SUBVENCION-queries.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:9e952ee34812eca526acd74254197ea1' WHERE [ID] = 'params' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.01-SUBVENCION-queries.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:0cf6993727d7a7f998f01adf948d5beb' WHERE [ID] = 'DATA-CORE-tag-3.1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.01-SUBVENCION-queries.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:95bf5ed4167af3b28c867bb0267c0580' WHERE [ID] = 'table-territorioPais' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.02-TERRITORIO-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:dc32e35b4a6f48a98b6949b819022700' WHERE [ID] = 'PK-table-tPais' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.02-TERRITORIO-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:47d2b78b8f73023eb970ed2950c873fc' WHERE [ID] = 'Index-on-id-pais' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.02-TERRITORIO-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:ba26c586fb76835f6af13370c5e8aed4' WHERE [ID] = 'territorio_data-1' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.02-TERRITORIO-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:49be0d3e45f6e945789a7aa0a606772d' WHERE [ID] = 'queries' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.02-TERRITORIO-queries.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:f111a6ffc1870163d55be8f041cb5c13' WHERE [ID] = 'DATA-CORE-tag-3.2' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.02-TERRITORIO-queries.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:8df17fcf0caad4e587f0ccd282497beb' WHERE [ID] = 'table-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.03-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:02c1162b6e60b4fa0ee9a779830f3e63' WHERE [ID] = 'PK-table-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.03-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:1642ec6a87abb8d01df12019defa0e76' WHERE [ID] = 'Index-equipamiento-id' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.03-EQUIPAMIENTO-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:f334338408df0e5f910127cac7f173fc' WHERE [ID] = 'data-equipamiento' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.03-EQUIPAMIENTO-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:2bd11579c13f5101a2f3e7e7f449a5fa' WHERE [ID] = 'queries' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.03-EQUIPAMIENTO-queries.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:0219cf60922824e0a43eb28fb76340be' WHERE [ID] = 'DATA-CORE-tag-3.3' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-3.03-EQUIPAMIENTO-queries.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:1e85d0b9783ebbec6d23b463ce470e54' WHERE [ID] = 'table-semantic_field' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:6090001a9c1d90f7e6133c7d5f66feaf' WHERE [ID] = 'table-semantic_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:aabc2370f98fba3c16bc1bd29cf40958' WHERE [ID] = 'table-semantic_rel_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:ff007b9f9a61d988e0709b4d2ce698cd' WHERE [ID] = 'table-semantic_rml' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:3c87fdb899d417ce227a48ed685a683e' WHERE [ID] = 'PK-table-semantic_field' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:ae5f7018b3781d7d187ea7dab372c2c3' WHERE [ID] = 'PK-table-semantic_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:928177ea0123c752c7834ddc7fae3059' WHERE [ID] = 'PK-table-semantic_rel_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:432455a2ee4f4d2102684e88ba37d5fc' WHERE [ID] = 'PK-table-semantic_rml' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:1317230ad88dd38fd6b89b74f520e014' WHERE [ID] = 'index-prefix-semantic_rel_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:26750a44e42846548c5256d7ddc2eb94' WHERE [ID] = 'index-query-semantic_field' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:753965de0b2aa47f0af0d09efe61afec' WHERE [ID] = 'index-query-semantic_rel_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:a2fd4d920c0e3354c89995c9e596579f' WHERE [ID] = 'index-query-semantic_rml' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:b84804d82e5c849c0f82a4dd13abe75b' WHERE [ID] = 'FK-query-semantic_field' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:a6e0efdcbbbed2aab36daf8ab5d0356c' WHERE [ID] = 'FK-query-semantic_rel_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:ec7d98677ce86e7dadfd16ee694116c1' WHERE [ID] = 'FK-prefix-semantic_rel_prefix' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:f423dcac1f4cabf8946ad9195122ec44' WHERE [ID] = 'FK-query-semantic_rml' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-table.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:5a3c849aa53f36f57c83e7090fc0a641' WHERE [ID] = 'prefix-data' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-data.xml'
GO

UPDATE [schema_apiDinamica].[DATABASECHANGELOG] SET [MD5SUM] = '7:a3a719733f8e2252e3a1e46a7ea235b9' WHERE [ID] = 'DATA-CORE-tag-4.0' AND [AUTHOR] = 'Localidata' AND [FILENAME] = 'liquibase/db-changelog-script-4.0-SEMANTIC-data.xml'
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::dropNull::Localidata
ALTER TABLE [schema_apiDinamica].[semantic_field] ALTER COLUMN [object_type] [varchar](50) NULL
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('dropNull', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 87, '7:139c93f2e19234c6c70f33c2b2e29e87', 'dropNotNullConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::remove-double-quotes::Localidata
INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('remove-double-quotes', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 88, '7:8501bffbaef5413e2146e29a96d5bfbe', 'sql', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::remove-double-quotes-ms::Localidata
UPDATE [schema_apiDinamica].[subvencion] SET title = REPLACE(title, '"', '''') WHERE title LIKE '%"%'
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('remove-double-quotes-ms', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 89, '7:33a0f76d0c79cc7dd070d4b6b66984a0', 'sql', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::columns-blanknodes::Localidata
ALTER TABLE [schema_apiDinamica].[semantic_field] ADD [blank_node_type] [varchar](50)
GO

ALTER TABLE [schema_apiDinamica].[semantic_field] ADD [blank_node_id] [varchar](100)
GO

ALTER TABLE [schema_apiDinamica].[semantic_field] ADD [blank_property_id] [varchar](100)
GO

ALTER TABLE [schema_apiDinamica].[semantic_field] ADD [object_reference_type] [varchar](20)
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('columns-blanknodes', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 90, '7:68f00c0b3b031327ec80fefbdcd09f9c', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::pre_semantic_id_size::Localidata
ALTER TABLE [schema_apiDinamica].[semantic_field] DROP CONSTRAINT [pk_semantic_field]
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] DROP CONSTRAINT [pk_semantic_rel_prefix]
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] DROP CONSTRAINT [semantic_rel_prefix_ibfk_2]
GO

DROP INDEX [schema_apiDinamica].[semantic_rel_prefix].[prefix]
GO

ALTER TABLE [schema_apiDinamica].[semantic_prefix] DROP CONSTRAINT [pk_semantic_prefix]
GO

ALTER TABLE [schema_apiDinamica].[semantic_rml] DROP CONSTRAINT [pk_semantic_rml]
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('pre_semantic_id_size', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 91, '7:dba2549b78cc6b93bdda2d4afce76725', 'dropPrimaryKey (x2), dropForeignKeyConstraint, dropIndex, dropPrimaryKey (x2)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::semantic_id_size::Localidata
DELETE FROM [schema_apiDinamica].[semantic_prefix]
GO

ALTER TABLE [schema_apiDinamica].[semantic_field] ALTER COLUMN [id] [varchar](20) NOT NULL
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] ALTER COLUMN [prefix] [int]
GO

ALTER TABLE [schema_apiDinamica].[semantic_prefix] ALTER COLUMN [id] [int]
GO

ALTER TABLE [schema_apiDinamica].[semantic_prefix] ADD [code] [varchar](50) NOT NULL
GO

UPDATE [schema_apiDinamica].[semantic_prefix] SET [code] = id
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] ALTER COLUMN [id] [varchar](20) NOT NULL
GO

ALTER TABLE [schema_apiDinamica].[semantic_rml] ALTER COLUMN [id] [varchar](20) NOT NULL
GO

DELETE FROM [schema_apiDinamica].[semantic_prefix]
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (1, 'dcterms', 'http://purl.org/dc/terms/')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (2, 'esadm', 'http://vocab.linkeddata.es/datosabiertos/def/sector-publico/territorio#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (3, 'espresup', 'http://vocab.linkeddata.es/datosabiertos/def/hacienda/presupuesto#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (4, 'essubv', 'http://vocab.linkeddata.es/datosabiertos/def/sector-publico/subvencion#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (5, 'org', 'http://www.w3.org/ns/org#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (6, 'owl', 'http://www.w3.org/2002/07/owl#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (7, 'rdf', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (8, 'xsd', 'http://www.w3.org/2001/XMLSchema#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (9, 'schema', 'http://schema.org/')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (10, 'geo', 'http://www.w3.org/2003/01/geo/wgs84_pos#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (11, 'esequip', 'http://vocab.linkeddata.es/datosabiertos/def/urbanismo-infraestructuras/equipamiento-municipal#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (12, 'escjr', 'http://vocab.linkeddata.es/datosabiertos/def/urbanismo-infraestructuras/callejero#')
GO

INSERT INTO [schema_apiDinamica].[semantic_prefix] ([id], [code], [url]) VALUES (13, 'geo_core', 'http://datos.ign.es/def/geo_core#')
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('semantic_id_size', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 92, '7:8bf899a9165c7834d3bb4862869500aa', 'delete, modifyDataType (x3), addColumn, modifyDataType (x2), delete, insert (x13)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::post_semantic_id_size::Localidata
UPDATE [schema_apiDinamica].[semantic_prefix] SET [id] = '' WHERE [id] IS NULL
GO

ALTER TABLE [schema_apiDinamica].[semantic_prefix] ALTER COLUMN [id] [int] NOT NULL
GO

UPDATE [schema_apiDinamica].[semantic_rel_prefix] SET [prefix] = '' WHERE [prefix] IS NULL
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] ALTER COLUMN [prefix] [int] NOT NULL
GO

ALTER TABLE [schema_apiDinamica].[semantic_field] ADD CONSTRAINT [pk_semantic_field] PRIMARY KEY ([id])
GO

ALTER TABLE [schema_apiDinamica].[semantic_prefix] ADD CONSTRAINT [pk_semantic_prefix] PRIMARY KEY ([id])
GO

ALTER TABLE [schema_apiDinamica].[semantic_rml] ADD CONSTRAINT [pk_semantic_rml] PRIMARY KEY ([id])
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] ADD CONSTRAINT [pk_semantic_rel_prefix] PRIMARY KEY ([id])
GO

ALTER TABLE [schema_apiDinamica].[semantic_prefix] ADD CONSTRAINT [unique_code_index_prefix] UNIQUE ([code])
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] ADD CONSTRAINT [semantic_rel_prefix_ibfk_2] FOREIGN KEY ([prefix]) REFERENCES [schema_apiDinamica].[semantic_prefix] ([id])
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('post_semantic_id_size', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 93, '7:492628249593e4a7342774d456474191', 'addNotNullConstraint (x2), addPrimaryKey (x4), addUniqueConstraint, addForeignKeyConstraint', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::add_id_query_sqlserver::Localidata
ALTER TABLE [schema_apiDinamica].[query] ADD [idtemp] [int] IDENTITY (1, 1)
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('add_id_query_sqlserver', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 94, '7:b5d50eff57740ef785c2efe7a14bb45b', 'addColumn', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::add_id_query_2::Localidata
ALTER TABLE [schema_apiDinamica].[query] ADD [id] [int]
GO

UPDATE [schema_apiDinamica].[query] SET [id] = idtemp
GO

ALTER TABLE [schema_apiDinamica].[query] DROP COLUMN [idtemp]
GO

ALTER TABLE [schema_apiDinamica].[query] ALTER COLUMN [id] [int] NOT NULL
GO

ALTER TABLE [schema_apiDinamica].[param] DROP CONSTRAINT [param_ibfk_1]
GO

ALTER TABLE [schema_apiDinamica].[semantic_rml] DROP CONSTRAINT [semantic_rml_ibfk_1]
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] DROP CONSTRAINT [semantic_rel_prefix_ibfk_1]
GO

ALTER TABLE [schema_apiDinamica].[semantic_field] DROP CONSTRAINT [semantic_field_ibfk_1]
GO

ALTER TABLE [schema_apiDinamica].[query] DROP CONSTRAINT [query-pk]
GO

ALTER TABLE [schema_apiDinamica].[query] ADD CONSTRAINT [query-pk] PRIMARY KEY ([id])
GO

ALTER TABLE [schema_apiDinamica].[query] ADD CONSTRAINT [unique_code_index] UNIQUE ([code])
GO

ALTER TABLE [schema_apiDinamica].[param] ADD CONSTRAINT [param_ibfk_1] FOREIGN KEY ([query_code]) REFERENCES [schema_apiDinamica].[query] ([code])
GO

ALTER TABLE [schema_apiDinamica].[semantic_field] ADD CONSTRAINT [semantic_field_ibfk_1] FOREIGN KEY ([query]) REFERENCES [schema_apiDinamica].[query] ([code])
GO

ALTER TABLE [schema_apiDinamica].[semantic_rel_prefix] ADD CONSTRAINT [semantic_rel_prefix_ibfk_1] FOREIGN KEY ([query]) REFERENCES [schema_apiDinamica].[query] ([code])
GO

ALTER TABLE [schema_apiDinamica].[semantic_rml] ADD CONSTRAINT [semantic_rml_ibfk_1] FOREIGN KEY ([query]) REFERENCES [schema_apiDinamica].[query] ([code])
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('add_id_query_2', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 95, '7:9b6018203c7e24b5c53e4373ef55168f', 'addColumn, dropColumn, addNotNullConstraint, dropForeignKeyConstraint (x4), dropPrimaryKey, addPrimaryKey, addUniqueConstraint, addForeignKeyConstraint (x4)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::ejemplo-query-geo-y-rdf::Localidata
INSERT INTO [schema_apiDinamica].[query] ([code], [id], [texto], [database_con], [summary], [tags], [definition]) VALUES ('equipamiento-busqueda-geo', 4007, '
    select
        id,
        title,
        municipioId,
        xETRS89,
        yETRS89,
        distance       
    from
        (    select
            id,
            title,
            municipio_id as municipioId,
            x_etrs89 as xETRS89,
            y_etrs89 as yETRS89,
            SQRT((x_etrs89-xEtrs89P)*(x_etrs89-xEtrs89P)+(y_etrs89-yEtrs89P)*(y_etrs89-yEtrs89P)) as distance               
        from
            equipamiento  ) as consultaGeo         
    where
        distance<=metersP         
    order by
        distance asc', 'default', N'B�squeda geografica a partir de un punto (x e y) y un radio de b�squeda', '', 'Equipamiento-busqueda-geo')
GO

INSERT INTO [schema_apiDinamica].[param] ([id], [query_code], [name], [type], [description], [example]) VALUES (51, 'equipamiento-busqueda-geo', 'xEtrs89P', 'text', 'Coordenada X del punto (en formato ETRS89)', '446175.61012')
GO

INSERT INTO [schema_apiDinamica].[param] ([id], [query_code], [name], [type], [description], [example]) VALUES (52, 'equipamiento-busqueda-geo', 'yEtrs89P', 'text', 'Coordenada Y del punto (en formato ETRS89)', '4487376.65943')
GO

INSERT INTO [schema_apiDinamica].[param] ([id], [query_code], [name], [type], [description], [example]) VALUES (53, 'equipamiento-busqueda-geo', 'metersP', 'text', N'Radio de b�squeda en metros', '500')
GO

DELETE FROM [schema_apiDinamica].[query] WHERE code='equipamiento-xy'
GO

INSERT INTO [schema_apiDinamica].[query] ([code], [id], [texto], [database_con], [summary], [tags], [definition]) VALUES ('equipamiento-xy', 1271, '
    SELECT
        equipamiento.id ,
        equipamiento.title ,
        equipamiento.description ,
        equipamiento.tipo_equipamiento as tipoEquipamiento ,
        equipamiento.municipio_id as municipioId ,
        equipamiento.municipio_title as municipioTitle ,
        equipamiento.provincia_id as provinciaId ,
        equipamiento.autonomia_id as autonomiaId ,
        equipamiento.pais_id as paisId ,
        equipamiento.street_address as streetAddress ,
        equipamiento.postal_code as postalCode ,
        equipamiento.barrio_id as barrioId ,
        equipamiento.distrito_id as distritoId ,
        equipamiento.email ,
        equipamiento.telephone ,
        equipamiento.url ,
        equipamiento.opening_hours as openingHours ,
        equipamiento.x_etrs89 AS xETRS89 ,
        equipamiento.y_etrs89 AS yETRS89 
    FROM
        equipamiento 
    WHERE
        equipamiento.tipo_equipamiento LIKE ''equipamiento municipal''', 'default', 'Listado de equipamientos', 'equipamientos', NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000001726', 'equipamiento-xy', 'id', 'dcterms:identifier', 'id', NULL, 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000016295', 'equipamiento-xy', 'title', 'dcterms:title', 'title', NULL, 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000024436', 'equipamiento-xy', 'description', 'schema:description', 'description', NULL, 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000036231', 'equipamiento-xy', 'tipoEquipamiento', 'esequip:tipoEquipamiento', 'tipoEquipamiento', NULL, 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000041385', 'equipamiento-xy', 'municipioId', 'esadm:municipio', 'https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/municipio/{municipioId}', NULL, 'url', 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000052230', 'equipamiento-xy', 'provinciaId', 'esadm:provincia', 'https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/provincia/{provinciaId}', NULL, 'url', 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000061901', 'equipamiento-xy', 'autonomiaId', 'esadm:autonomia', 'https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/autonomia/{autonomiaId}', NULL, 'url', 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000077784', 'equipamiento-xy', 'paisId', 'esadm:pais', 'https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/pais/{paisId}', NULL, 'url', 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000087818', 'equipamiento-xy', 'barrioId', 'esadm:barrio', 'https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/barrio/{barrioId}', NULL, 'url', 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000091597', 'equipamiento-xy', 'distritoId', 'esadm:distrito', 'https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/distrito/{distritoId}', NULL, 'url', 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000101591', 'equipamiento-xy', 'email', 'schema:email', 'email', NULL, 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000113661', 'equipamiento-xy', 'telephone', 'schema:telephone', 'telephone', NULL, 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000128110', 'equipamiento-xy', 'url', 'schema:url', 'url', NULL, '{url}', 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000133035', 'equipamiento-xy', 'openingHours', 'schema:openingHours', 'openingHours', NULL, 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000147244', 'equipamiento-xy', 'xETRS89', 'geo_core:xETRS89', 'xETRS89', 'xsd:decimal', 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000155874', 'equipamiento-xy', 'yETRS89', 'geo_core:yETRS89', 'yETRS89', 'xsd:decimal', 'simple', 0, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_field] ([id], [query], [field], [predicate], [object_reference], [object_reference_type], [object_type], [object_uri], [blank_node_type], [blank_node_id], [blank_property_id]) VALUES ('020300000000165457', 'equipamiento-xy', 'type', 'esequip:Equipamiento', 'http://localhost:8080/dynamicAPI/API/query/equipamiento-xy/{id}', NULL, NULL, 1, NULL, NULL, NULL)
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000004340', 'equipamiento-xy', '1')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000011016', 'equipamiento-xy', '2')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000022606', 'equipamiento-xy', '12')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000037567', 'equipamiento-xy', '11')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000047189', 'equipamiento-xy', '10')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000056297', 'equipamiento-xy', '13')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000069380', 'equipamiento-xy', '7')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000072712', 'equipamiento-xy', '9')
GO

INSERT INTO [schema_apiDinamica].[semantic_rel_prefix] ([id], [query], [prefix]) VALUES ('020100000000089410', 'equipamiento-xy', '8')
GO

INSERT INTO [schema_apiDinamica].[semantic_rml] ([id], [query], [rml]) VALUES ('020300000000174329', 'equipamiento-xy', '@prefix rr: <http://www.w3.org/ns/r2rml#> .
@prefix ex: <http://example.com/> .
@prefix rml: <http://semweb.mmlab.be/ns/rml#> .
@prefix ql: <http://semweb.mmlab.be/ns/ql#> .
@base <http://example.com/base/> .
@prefix dcterms:   <http://purl.org/dc/terms/> .
@prefix esadm:   <http://vocab.linkeddata.es/datosabiertos/def/sector-publico/territorio#> .
@prefix escjr:   <http://vocab.linkeddata.es/datosabiertos/def/urbanismo-infraestructuras/callejero#> .
@prefix esequip:   <http://vocab.linkeddata.es/datosabiertos/def/urbanismo-infraestructuras/equipamiento-municipal#> .
@prefix geo:   <http://www.w3.org/2003/01/geo/wgs84_pos#> .
@prefix geo_core:   <http://datos.ign.es/def/geo_core#> .
@prefix rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix schema:   <http://schema.org/> .
@prefix xsd:   <http://www.w3.org/2001/XMLSchema#> .

<#TriplesMap1> a rr:TriplesMap;

rml:logicalSource [
  rml:source "nombreDinamico.csv";
  rml:referenceFormulation ql:CSV
  ];

rr:subjectMap [
 rr:template "http://localhost:8080/dynamicAPI/API/query/equipamiento-xy/{id}";
rr:class esequip:Equipamiento
];

rr:predicateObjectMap [
rr:predicate dcterms:identifier ;
rr:objectMap [ rml:reference "id" ]
 ];
rr:predicateObjectMap [
rr:predicate dcterms:title ;
rr:objectMap [ rml:reference "title" ]
 ];
rr:predicateObjectMap [
rr:predicate schema:description ;
rr:objectMap [ rml:reference "description" ]
 ];
rr:predicateObjectMap [
rr:predicate esequip:tipoEquipamiento ;
rr:objectMap [ rml:reference "tipoEquipamiento" ]
 ];
rr:predicateObjectMap [
rr:predicate esadm:municipio ;
rr:objectMap [ rr:template "https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/municipio/{municipioId}" ]
 ];
rr:predicateObjectMap [
rr:predicate esadm:provincia ;
rr:objectMap [ rr:template "https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/provincia/{provinciaId}" ]
 ];
rr:predicateObjectMap [
rr:predicate esadm:autonomia ;
rr:objectMap [ rr:template "https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/autonomia/{autonomiaId}" ]
 ];
rr:predicateObjectMap [
rr:predicate esadm:pais ;
rr:objectMap [ rr:template "https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/pais/{paisId}" ]
 ];
rr:predicateObjectMap [
rr:predicate esadm:barrio ;
rr:objectMap [ rr:template "https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/barrio/{barrioId}" ]
 ];
rr:predicateObjectMap [
rr:predicate esadm:distrito ;
rr:objectMap [ rr:template "https://alzir.dia.fi.upm.es/OpenCitiesAPI/territorio/distrito/{distritoId}" ]
 ];
rr:predicateObjectMap [
rr:predicate schema:email ;
rr:objectMap [ rml:reference "email" ]
 ];
rr:predicateObjectMap [
rr:predicate schema:telephone ;
rr:objectMap [ rml:reference "telephone" ]
 ];
rr:predicateObjectMap [
rr:predicate schema:url ;
rr:objectMap [ rr:template "url" ]
 ];
rr:predicateObjectMap [
rr:predicate schema:openingHours ;
rr:objectMap [ rml:reference "openingHours" ]
 ];
rr:predicateObjectMap [
rr:predicate geo_core:xETRS89 ;
rr:objectMap [ rml:reference "xETRS89"; rr:datatype xsd:decimal; ]
 ];
rr:predicateObjectMap [
rr:predicate geo_core:yETRS89 ;
rr:objectMap [ rml:reference "yETRS89"; rr:datatype xsd:decimal; ]
 ].
')
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('ejemplo-query-geo-y-rdf', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 96, '7:f84cf52567beeba8cef807d90aefccaf', 'insert (x4), delete, insert (x28)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::swagger-pk::Localidata
ALTER TABLE [schema_apiDinamica].[swagger_definition] ADD CONSTRAINT [swagger-pk] PRIMARY KEY ([code])
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('swagger-pk', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 97, '7:cd4fb85093ebbea1309a112859e01b48', 'addPrimaryKey', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::update-example::liquibase-docs
UPDATE [schema_apiDinamica].[query] SET [tags] = 'Subvenciones' WHERE code='subvencion-distinct'
GO

UPDATE [schema_apiDinamica].[query] SET [tags] = 'Subvenciones' WHERE code='subvencion'
GO

UPDATE [schema_apiDinamica].[query] SET [tags] = 'Subvenciones' WHERE code='subvencion-groupby'
GO

UPDATE [schema_apiDinamica].[query] SET [tags] = 'Equipamientos' WHERE code='equipamiento-xy'
GO

UPDATE [schema_apiDinamica].[query] SET [tags] = 'Equipamientos' WHERE code='equipamiento-busqueda-geo'
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('update-example', 'liquibase-docs', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 98, '7:419a85d63c2d3ec920dc56f28b26017f', 'update (x5)', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Changeset liquibase/db-changelog-script-4.01-SEMANTIC.xml::DATA-CORE-tag-4.01::Localidata
INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE], [TAG]) VALUES ('DATA-CORE-tag-4.01', 'Localidata', 'liquibase/db-changelog-script-4.01-SEMANTIC.xml', GETDATE(), 99, '7:8af28afed21c4838016bb21a88276d29', 'tagDatabase', '', 'EXECUTED', NULL, NULL, '3.4.2', '4.01')
GO

-- Changeset liquibase/db-changelog-script-99.01-CORRECCION-SUBVENCION.xml::alter-table-subvencion::Localidata
ALTER TABLE [schema_apiDinamica].[subvencion] ALTER COLUMN [municipio_id] [varchar](50)
GO

INSERT INTO [schema_apiDinamica].[DATABASECHANGELOG] ([ID], [AUTHOR], [FILENAME], [DATEEXECUTED], [ORDEREXECUTED], [MD5SUM], [DESCRIPTION], [COMMENTS], [EXECTYPE], [CONTEXTS], [LABELS], [LIQUIBASE]) VALUES ('alter-table-subvencion', 'Localidata', 'liquibase/db-changelog-script-99.01-CORRECCION-SUBVENCION.xml', GETDATE(), 100, '7:82d8fa214d568a2074fd11bea30feee4', 'modifyDataType', '', 'EXECUTED', NULL, NULL, '3.4.2')
GO

-- Release Database Lock
UPDATE [schema_apiDinamica].[DATABASECHANGELOGLOCK] SET [LOCKED] = 0, [LOCKEDBY] = NULL, [LOCKGRANTED] = NULL WHERE [ID] = 1
GO

